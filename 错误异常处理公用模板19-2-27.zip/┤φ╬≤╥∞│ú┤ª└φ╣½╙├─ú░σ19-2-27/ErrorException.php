<?php
    namespace framework;
    class ErrorException extends DaseException
{
       public  $message = "系统内部错误";
       public  $errCode = 404;
}