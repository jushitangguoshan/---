<?php
    namespace framework;
    class Error
    {
        public static function start()
        {
            set_error_handler([__CLASS__,"appError"]);
            set_exception_handler([__CLASS__,"appException"]);
            register_shutdown_function([__CLASS__,"appShutdown"]);
        }
        public static function appError($typeNum,$message,$file,$line)
        {
            self::recordLogs($typeNum,$message,$file,$line);
            throw new \framework\ErrorException();//【注意】  抛出时的命名空间
        }
        public static function appException( \framework\ErrorException $e)
        {
            if( !$e instanceof \Exception ){
                self::recordLogs($e->getCode(),$e->getMessage(),$e->getFile(),$e->getLine());
            }
            echo $e->JsonHandle();
        }
        public static function appShutdown()
        {
            if( ($error=error_get_last()) != null ){
                self::recordLogs($error['type'],$error['message'],$error['file'],$error['line']);
                self::appException( new \framework\ErrorException() );
            }
        }
        #记录日志
        protected static function recordLogs($type,$message,$file,$line)
        {
            $msg="时间：".date("Y-m-d H:i:S")."、错误类型：".$type."、错误信息：".$message."、错误文件：".$file."、错误行数：".$line.PHP_EOL;
            file_put_contents(dirname(__DIR__).DIRECTORY_SEPARATOR."err.log",$msg,FILE_APPEND);
        }
    }