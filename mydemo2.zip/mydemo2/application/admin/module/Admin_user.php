<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/5 0005
     * Time: 下午 9:31
     */

    namespace app\admin\module;
    use think\Model;

    class Admin_user extends Model
    {

    }