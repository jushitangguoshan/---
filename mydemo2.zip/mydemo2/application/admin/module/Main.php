<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/5 0005
     * Time: 下午 8:03
     */

    namespace app\admin\module;


    use think\Model;

    class Main extends Model
    {
        protected $update =['art_abs'];
        public function setArt_absAttr($value)
        {
            $daat=strtolower($value);
            return $daat;
        }
    }