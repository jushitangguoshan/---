<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/2 0002
     * Time: 下午 7:08
     */
    namespace app\admin\controller;
    class Home extends \think\Controller
    {
        public function login()
        {
            // login 会话初始化
            session([ 'prefix' => 'login', 'type' => '', 'auto_start' => true, ]);

            return $this->fetch();
        }
    }