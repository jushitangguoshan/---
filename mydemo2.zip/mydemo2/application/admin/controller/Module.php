<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/2 0002
     * Time: 下午 7:09
     */
    namespace  app\admin\controller;
    use app\admin\dateCheck\LoginCheck;
    use app\admin\includefile\Basedata;
    use app\admin\module\Main;
    use think\Controller;
    use think\Db;
    use think\exception\ErrorException;
    use think\Request;
    use think\Config;

    class Module extends Controller
    {
        #登录处理---判断用户身份
        public function loginHandle()
        {
            //判断是否是ajax请求
            if( !Request::instance()->isAjax() ){
                $this->error("非正常请求，无法访问");
            }
            //echo json_encode([$_GET,$_POST]);die;
            #获取提交过来的数据
            $data = Request::instance()->post();
            #数据校验--判断用户名、密码位数 and 验证码是否为空
            $validate=new LoginCheck();
            if( !$validate->check($data) ){
                $this->error("登录失败,".$validate->getError());
            }
            #数据库查询该用户信息
            $user = Db::name('admin_user')->where('user_name',$data['user_name'])->find();
            #判断用户是否存在
            if( !$user ){
                $this->error("用户名不存在");
            }
            //判断用户是否第一次登录
//            $isFrist=true;
//            if( !session('?login_name','','login') ){
//                //是第一次登录--设置登录标志---存储该用户会话
//                $isFrist=false;
//                session('login_name',$data['user_name'],'login');
//            }
            #判断验证码是否正确 if( !$isFrist && !captcha_check($data['yzm']) ){
            if(  !captcha_check($data['yzm']) ){
                $this->error("验证码不正确");
            }
            #判断账户密码是否匹配
            if( !(md5($data['user_pwd'])===$user['user_pwd']) ){
                $this->error("账户名或密码错误",'',true);
            }
            //设置当前用户 会话session
            session('current_user',$data['user_name'],'login');
            $this->success('登录成功','module/index');
        }
        #后台首页---登录界面
        public function index()
        {
            //判断是否正常登录
            if(!session('?current_user','','login')){
                $this->error("你未登录，3秒后跳转登录界面",'home/login');
            }
            #获取当前登录的用户
            $user_name=session('current_user','','login');
            #数据库查询当前用户的数据----判断权限
            $user = Db::name('admin_user')->where('user_name',$user_name)->find();
            //判断用户权限
            $root='admin';
            if( $user['user_root']===100 ){
                $root='superadmin';//超级管理员
            }

            return $this->fetch('index',[
                'user'=>$user['user_name'],
                'root'=>$root,
                'superAdmin'=>$this->getModule()
            ]);
        }




        #文章管理列表
        public function cp_article()
        {
//            $arr=main::where('id',">",0)->select();
//            dump($arr);die;
            //从数据库获取数据-
            $arr=$this->getMyArr();
            //从数据库获取数据----栏目列表
            $colList=Db::name('column')->field('id,col_name')->select();
            //数据模板赋值
            return $this->fetch('cp_article',['list'=>$arr[0],'page'=>$arr[1],'colList'=>$colList]);
        }
        //获取每页数据和分页显示
        private function getMyArr()
        {
            #动态修改 页码配置 本页面临时调用
            Config::set('paginate',[
                'type'      => 'mypage',
                'var_page'  => 'page',
                'list_rows' => 15]);
            //文章数组
            $art_arr = Db::name('main')
                ->field('id,art_title,art_author_id,art_classId,art_addtime')
                ->where('art_addtime','>',1)
                ->order('id asc')
                ->paginate(5)
                ->each(function($item,$v){
                    $item['col_id']= $item['art_classId'];//加入栏目id
                    $item['art_author_id'] = $this->getAuthorName($item['art_author_id']);//加入作者id
                    $item['art_classId'] = $this->getColName($item['art_classId']);//加入栏目数组
                    return $item;
            });
            // 获取分页显示
            $page = $art_arr->render();
            //dump($art_arr);die;
            return [$art_arr,$page];
        }
        //转换作者id为作者名字
        private function getAuthorName($id)
        {
            //用户数组
            $user_arr=Db::name('admin_user')->field('id,user_name')->select();
            foreach($user_arr as $k=>$v){
                if($id==$v['id']){
                    return $v['user_name'];
                }
            }
        }
        //转换栏目id为栏目名字
        private function getColName($id)
        {
            //栏目数组
            $arr=Db::name('column')->field('id,col_name')->select();
            $temp=[];
            //文章所属的数组
            $krr=explode(',',$id);
            foreach( $krr as $k=>$kv ){
                foreach($arr as $j=>$jv){
                    if($kv==$jv['id']){
                        $temp[$kv]=$jv['col_name'];

                    }
                }
            }
            //dump($temp);die;
           return $temp;//返回数组array( [1] => "新闻",[3] =>  "财经")

        }

        //功能一：栏目筛选
        public function screening()
        {
            //获取要查看的栏目id
            $id=input('art_classId');
            #动态修改 页码配置 本页面临时调用
            Config::set('paginate',[
                'type'      => 'mypage',
                'var_page'  => 'page',
                'list_rows' => 15]);
            //文章数组
            $art_arr = Db::name('main')
                ->field('id,art_title,art_author_id,art_classId,art_addtime')
                ->where('art_addtime','>',1)
                ->where('art_classId','like',"%".$id."%")
                ->order('id asc')
                ->paginate(5)
                ->each(function($item,$v){
                    $item['col_id']= $item['art_classId'];//加入栏目id
                    $item['art_author_id'] = $this->getAuthorName($item['art_author_id']);//加入作者id
                    $item['art_classId'] = $this->getColName($item['art_classId']);//加入栏目数组
                    return $item;
            });
            // 获取分页显示
            $page = $art_arr->render();
            //dump($art_arr);die;
            //从数据库获取数据----栏目列表
            $colList=Db::name('column')->field('id,col_name')->select();
            //数据模板赋值
            return $this->fetch('cp_article',['list'=>$art_arr,'page'=>$page,'colList'=>$colList]);
        }
        //功能二：时间筛选
        public function timeScreen()
        {
            //获取排序方式
            $order=input('order');
//            #动态修改 页码配置 本页面临时调用
//            Config::set('paginate',[
//                'type'      => 'mypage',
//                'var_page'  => 'page',
//                'list_rows' => 15]);
            switch ( $order ){
                case 'time-asc':
                   $order='art_addtime asc';
                    break;
                case 'time-desc':
                    $order='art_addtime desc';
                    break;
            }
            if( $order=='show-desc' ){
                $art_arr = Db::name('main')
                    ->field('id,art_title,art_author_id,art_classId,art_addtime')
                    ->where('art_addtime','>',0)
                    ->order('id asc')
                    ->paginate(5)
                    ->each(function($item,$v){
                        $item['col_id']= $item['art_classId'];//加入栏目id
                        $item['art_author_id'] = $this->getAuthorName($item['art_author_id']);//加入作者id
                        $item['art_classId'] = $this->getColName($item['art_classId']);//加入栏目数组
                        return $item;
                });
                //dump($art_arr);die;
            }else{
                $art_arr = Db::name('main')
                    ->field('id,art_title,art_author_id,art_classId,art_addtime')
                    ->where('art_addtime','>',1)
                    ->order($order)
                    ->paginate(5)
                    ->each(function($item,$v){
                        $item['col_id']= $item['art_classId'];//加入栏目id
                        $item['art_author_id'] = $this->getAuthorName($item['art_author_id']);//加入作者id
                        $item['art_classId'] = $this->getColName($item['art_classId']);//加入栏目数组
                        return $item;
                });
            }
            // 获取分页显示
            $page = $art_arr->render();
            //dump($art_arr);die;
            //从数据库获取数据----栏目列表
            $colList=Db::name('column')->field('id,col_name')->select();
            //数据模板赋值
            return $this->fetch('cp_article',['list'=>$art_arr,'page'=>$page,'colList'=>$colList]);
        }
        //功能三：关键查询模糊查询
        public function likeScreen()
        {

            //获取搜索的关键字
            $keywords=input('search');

            $main = new Main();
            $arr=$main->where("find_in_set(".$keywords.",`art_keywords`)")
                ->paginate()
                ->each(function($item,$v){
                    $item['col_id']= $item['art_classId'];//加入栏目id
                    $item['art_author_id'] = $this->getAuthorName($item['art_author_id']);//加入作者id
                    $item['art_classId'] = $this->getColName($item['art_classId']);//加入栏目数组
                    return $item;
                });
            //dump($arr);die;
            // 获取分页显示

            【未完。。。】
            //$page = $art_arr->render();
            //dump($art_arr);die;
            //从数据库获取数据----栏目列表
            $colList=Db::name('column')->field('id,col_name')->select();
            //数据模板赋值
            return $this->fetch('cp_article',['list'=>$art_arr,'page'=>$page,'colList'=>$colList]);
        }






        #删除文章处理
        public function delArticle()
        {
            //删除文章id
            $art_id=input('id');
            //把的发布时间为设为0
            $row= Db::name('main') ->where('id',$art_id)->setField('art_addtime', 0);
           if( !$row ){
                $this->error("删除失败");
           }
            $this->success("删除成功");
        }






        #编辑文章处理
        //初始化文章编辑页面----提交之前
        public function cp_article_edit_2()
        {
            //返回给前台的初始化界面数据
            $data=$this->getEditData();
            return  $this->fetch('cp_article_edit_2',['data'=>$data,'artId'=>input()['id']]);
        }
        //文章编辑页面数据提取----提交之前
        private function getEditData()
        {
            //获取修改文章的id
            $id=input()['id'];
            //查询数据库获取文章的信息---
            $data=Db::name('main')->where('id',$id)->find();
            if($data==null){
                $this->error("编辑失败");
            }
            //查询该文章内容
            $content=Db::name('content')->where('art_id',$data['id'])->find();
            //查询所有作者名字
            $art_author_name=Db::name('admin_user')->field('id,user_name')->select();
            //获取栏目id、name
            $colArr=Db::name('column')
                ->field('id,col_name')
                ->where('col_status','<>',0)
                ->select();
            //数据整理
            //加入作者名字数组
            $data['art_authorArr']=$art_author_name;
            //加入文章内容
            $data['art_content']=$content['art_content'];
            //栏目字符串转为数组
            $data['art_classId']=explode(',',$data['art_classId']);
            //加入栏目数组
            $data['colArr']=$colArr;
            //返回总数据数组
            return $data;
        }
        //文章编辑提交后数据处理----提交之后
        public function cp_article_edit_2Handle()
        {
            #数据处理
            //1、表单数据处理
            $data=$this->formUpload();
            //2、图片处理返回存储路径
            $imgPath=$this->imgUpload();
            //获取整合之后的数据，字段对应相应的值,方便插入数据库
            $data = $this->getData($imgPath,$data);
            //插入数据---事务操作
            $this->updateArticle($data[0],$data[1],'修改');
            $this->success('修改成功','module/cp_article');
        }

        #文章发布
        //初始化页面----提交之前
        public function cp_article_edit()
        {
            //获取栏目
            $arr=Db::name('column')
                ->field('id,col_name')
                ->where('col_status',1)
                ->select();
            //获取作者名字
            $author=Db::name('admin_user')
                ->field('id,user_name')
                ->where('user_root',1)
                ->select();
            //模板赋值
            $this->assign([
                'colList'=>$arr,
                'authorList'=>$author,
                'loginUser'=>session('current_user','','login'),
                ]);
            return $this->fetch();
        }
        //数据处理----提交之后
        public function addArticle()
        {
            #数据处理
            //1、表单数据处理
            $data=$this->formUpload();
            //2、图片处理返回存储路径
            $imgPath=$this->imgUpload('add');
            //获取整合之后的数据
            $data = $this->getData($imgPath,$data);
            //插入数据---事务操作
            $this->updateArticle($data[0],$data[1],'发布');
            $this->success('发布成功','module/cp_article');
        }



        #文章发布+编辑---提交后数据处理（【公用】函数）
        //数据提交到数据库
        private function updateArticle($data,$content,$ope){
            // 启动事务
            Db::startTrans();
            try{
                switch($ope){
                    case "发布":
                        $art_id=Db::name('main')->insertGetId($data);
                        if( !$art_id ){
                            throw new Exception();
                        }
                        //将文章id和内容插入内容表
                        $content['art_id']=$art_id;
                        $res=Db::name('content')->insert($content);
                        if( !$res ){
                            throw new ErrorException();
                        }
                        break;
                    case "修改":
                        $resOne=Db::name('main')->update($data);
                        $resTwo=Db::name('content')->where('art_id',$data['id'])->update($content);
                        //两个操作都失败--则抛出异常--[若只有一个，则只修改了一张表]
                        if( !$resOne && !$resTwo){
                            throw new Exception();
                        }
                        break;
                }
                // 提交事务
                Db::commit();
            } catch (\Exception $e) {
                // 回滚事务
                Db::rollback();
                $this->error($ope.'失败');
            }
        }
        //图片上传处理----返回图片保存路径
        private function imgUpload($ope='edit'){
            //获取表单上传的文件
            $file=request()->file('art_img');
            //判断是否上传文件
            if($ope=='add' &&  empty($file) ){//发布文章
                $this->error('请上传封面图片');
            }
            //如果修改时没有上传图片----直接返回false----否则返回处理后的图片路径
            if( $ope=='edit' && empty($file) ){
                return "";
            }
            //判断是否是图片
            $checkImg = $file->validate(['imgRule'=>'jpg,png,gif,jpeg'])->check();
            if( !$checkImg ){
                $this->error('请上传封面图片,包含格式jpg,png,gif,jpeg');
            }
            //移动到框架应用根目录/public/static/admin/uploads/ 目录下
            $path=ROOT_PATH.'public'.DS.'static'.DS.'admin'.DS.'uploads';
            //$path.$info->getSaveName()
            $info= $file->move($path);
            //判断是否上传成功
            if( $info==false ){
                exit($file->getError());
            }
           // '/public' . DS . 'uploads'.$info->getSaveName();
            $path=DS.$info->getSaveName();
            //返回储存路径
            return $path;
        }
        //表单数据处理----返回完整数据
        private function formUpload()
        {
            //获取表单数据
            $data=Request::instance()->post();
            //处理栏目---存在多个或者一个
            $colStr=$this->colHandle([$data['art_classId_one'],$data['art_classId_two'],$data['art_classId_three']]);
            $data['art_classId']=$colStr;
            //如果是修改，则去除editSubmit
            if(isset($data['editSubmit']) && !empty($data['editSubmit'])){
                unset($data['editSubmit']);
            }
            //移除 art_classId one->three
            unset($data['art_classId_one']);
            unset($data['art_classId_two']);
            unset($data['art_classId_three']);
            //判断是否存在空数据字段
            foreach($data as $key => $val){
                if( $key==='art_abs') continue;
                if( empty($val) ){
                    $this->error("数据不能为空");
                }
            }
            //单独判断文章摘要是否为空---为空则自动从`正文`中取30个字符充当
            if( empty($data['art_abs']) ){
                $len=strlen(trim($data['content']));//取出内容长度
                $data['art_abs']=($len<30) ? mb_substr($data['content'],3,($len-7),'UTF-8') :
                    mb_substr($data['content'],3,37,'UTF-8') ;
            }
            return $data;
        }
        //整合数据---方便对数据增加、修改操作
        private function getData($imgPath,$data)
        {
            //将图片加入数据组中
            if($imgPath!=''){//如果有图片就加入图片路径
                $data['art_img']=$imgPath;
            }
            //将时间加入数据组中
            $data['art_addtime']=time();
            //从$data数据中取出【作者文章内容】-作为一个新数组--方便把数据插入内容表
            $content=['art_content'=>$data['content']];
            //移除data里面的内容--方便把数据插入文章表
            unset($data['content']);//移除content
            unset($data['add']);//移除add
            return [$data,$content];
        }
        //多个栏目处理---返回栏目id通过，连接的字符串
        private function colHandle(array $arr)
        {
            $temp=[];
            $cont=0;
            foreach($arr as $k=>$v ){
                if($v==0)$cont++;
                   $temp[]=$v;
            }
            if($cont==3){
                $this->error("栏目不能为空");
            }
            return implode(',',$temp);

        }





        #用户管理列表
        public function cp_user()
        {
            //从数据库获取数据----用户列表
            $arr=Db::name('admin_user')->select();
            //数据模板赋值
            $this->assign(['list'=>$arr]);
            return $this->fetch();
        }









        # 数据字典
        public function dataDictionary()
        {
            $config = [
                // 服务器地址
                'hostname'        => '127.0.0.1',
                // 数据库名
                'database'        => 'thinkphp',
                // 用户名
                'username'        => 'root',
                // 密码
                'password'        => 'root',
            ];
            $UtilDbdic = new Basedata();
            return $UtilDbdic->export_dict($config)->table()->html();
        }


        //获取超级管理员模块
        private function getModule()
        {
            return '<a target="panel" href="/index.php/admin/module/cp_user.html" class="jq-nav super User-management">用户管理</a>
				<a target="panel" href="/index.php/admin/module/cp_category.html" class="jq-nav super Recycling-management">回收站管理</a>
				<a target="panel" href="/index.php/admin/module/dataDictionary.html" class="jq-nav super Recycling-management">数据库字典</a>';
        }
        #文章栏目
        public function cp_category()
        {
            //从数据库获取数据----栏目列表
            $arr=Db::name('column')->select();
            //数据模板赋值
            $this->assign(['list'=>$arr]);
            return $this->fetch();
        }
        #文章栏目修改
        public function cp_category_edit()
        {
            return $this->fetch();
        }

        #后台底部信息
        public function cp_index()
        {
            // var_dump($_POST,$_GET);die;
            return $this->fetch();
        }
    }