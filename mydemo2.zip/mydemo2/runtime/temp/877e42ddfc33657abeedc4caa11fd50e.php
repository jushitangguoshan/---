<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:81:"D:\thinkphp5\mydemo2\public/../application/admin\view\module\cp_article_edit.html";i:1551752517;}*/ ?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>后台</title>
	<link rel="stylesheet" href="/static/admin/css/style.css">
	<script src="/static/admin/js/ckeditor/ckeditor.js"></script>
	<script src="/static/admin/js/jquery.js"></script>
</head>
<body>

<div class="wrap wrap-article-edit">
	<h1>文章管理</h1>
	<div class="tips"></div>
	<div class="box">
		<div class="box-title">添加/编辑文章</div>
		<div class="box-body">
			<form method="post" id='form' enctype="multipart/form-data" action="<?php echo url('module/addArticle'); ?>">
				<table>
					<tr><th width="80">标题：</th><td>
						<input type="text" name="art_title" value="" placeholder="必填">
					</td></tr>
					<tr><th>栏目：</th>
						<td>
						<select name="art_classId_one" class="art_col">
							<option value="0">选择一</option>
							<?php if(is_array($colList) || $colList instanceof \think\Collection || $colList instanceof \think\Paginator): $key = 0; $__LIST__ = $colList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$value): $mod = ($key % 2 );++$key;?>
								<option value="<?php echo $value['id']; ?>"><?php echo $value['col_name']; ?></option>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</select>
						<select name="art_classId_two" class="art_col">
							<option value="0">选择二</option>
							<?php if(is_array($colList) || $colList instanceof \think\Collection || $colList instanceof \think\Paginator): $key = 0; $__LIST__ = $colList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$value): $mod = ($key % 2 );++$key;?>
								<option value="<?php echo $value['id']; ?>"><?php echo $value['col_name']; ?></option>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</select>
						<select name="art_classId_three" class="art_col">
							<option value="0">选择三</option>
							<?php if(is_array($colList) || $colList instanceof \think\Collection || $colList instanceof \think\Paginator): $key = 0; $__LIST__ = $colList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$value): $mod = ($key % 2 );++$key;?>
								<option value="<?php echo $value['id']; ?>"><?php echo $value['col_name']; ?></option>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</select>(至少选择一项)
						</td>
					</tr>

					<tr class="s-author"><th>作者：</th><td>
						<select name="art_author_id">
							<option value="<?php echo $loginUser; ?>">选择作者</option>
							<?php if(is_array($authorList) || $authorList instanceof \think\Collection || $authorList instanceof \think\Paginator): $key = 0; $__LIST__ = $authorList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$value): $mod = ($key % 2 );++$key;?>
								<option value="<?php echo $value['id']; ?>"><?php echo $value['user_name']; ?></option>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</select>(默认当前登录用户)</td>
					</td></tr>
					<tr class="s-keywords"><th>关键字：</th>
						<td><input type="text" name="art_keywords" value=""><span>多个关键字 请用英文逗号（,）分开</span></td>
					</tr>
					<tr class="s-description"><th>内容提要：</th><td>
						<textarea name="art_abs"></textarea><span>（内容提要请在 200 个字以内）</span>
					</td></tr>
					<tr class="s-thumb"><th>封面图片：</th><td>
						<input type="file" name="art_img"><span>（超过 780*220 图片将被缩小）</span>
					</td></tr>
					<tr class="s-editor"><th>编辑内容：</th><td>
						<textarea  id="content" name="content"></textarea>
					</td></tr>
					<tr class="s-act"><th></th><td>
						<input type="submit" value="立即发布" name="add">
						<input type="submit" value="保存草稿" name="save">
					</td></tr>
				</table>
			</form>
		</div>
	</div>
	<script>
		// $(function(){
		//     $('[name="add"]').click(function(){
		//         if ( !checkData() ){
		//             alert("文章标题、栏目、作者、内容不能为空");return;
		// 	   }
		//         //获取数据
          //         var   content = CKEDITOR.instances.content.getData();
          //         var format=new FormData(document.querySelector("form"));
          //         format.append("art_content",content);
		//         $.ajax({
		// 		  url:"<?php echo url('admin/module/addArticle'); ?>",
		// 		  type:'post',
		// 		  data:format,
		// 		  dataType:'json',
          //             contentType: false,
		// 		  processData: false,
		// 		  success:function(res){
          //                 console.log(res);
          //                 if(res.code){
          //                     if(confirm(res.msg+"点击确定跳转至【文章管理界面】")){
          //                         window.location.href=res.url;
		// 				}
		// 			 }
          //             }
		// 	   })
		//     });
		// })
		// //数据初处理
		// function checkData(){
		//
		//     if( $('[name="art_title"]').val=='' || CKEDITOR.instances.content.getData()==''){
		// 		return false;
		//     }
		//     var mark=false;
		//     $('.art_col').each(function(i,obj){
		//         if($(obj).val()!=''){
		// 		mark=true;
		// 	   }
		//     });
		//     if( !mark ){
		//         return false;
		//     }
		//     return true;
		// }
	</script>
</div>
<script src="/static/admin/js/article.config.js"></script>
<script>
    CKEDITOR.config.height = 400;
    CKEDITOR.config.width = "100%";
    CKEDITOR.replace("content");
</script>
</body>
</html>