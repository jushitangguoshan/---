<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"D:\thinkphp5\mydemo2\public/../application/back\view\home\index.html";i:1540606073;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="keywords" content="PHP,内容,管理">
		<meta name="description" content="PHP内容管理系统">
		<title>首页 - 内容管理系统</title>
		<link rel="stylesheet" href="./css/style.css">
		<script src="./js/jquery.min.js"></script>
		<script src="./js/common.js"></script>
	</head>
	<body>
		<!--页面顶部-->
		<div class="top">
			<div class="top-container">
				<div class="top-logo">
					<a href="./"><img src="./image/logo.png" alt="内容管理系统"></a>
				</div>
				<div class="top-nav">
					<a href="./" class="curr">首页</a>
					<a href="list.php?cid=1" class="">生活</a>
					<a href="list.php?cid=2" class="">资讯</a>
					<a href="list.php?cid=3" class="">编程</a>
					<a href="list.php?cid=4" class="">互联网</a>
					<a href="about.php" class="">联系我们</a>
				</div>
				<div class="top-toggle jq-toggle-btn"><i></i><i></i><i></i></div>
			</div>
		</div>
		<!--页面内容-->
		<div class="main">
			<!-- 幻灯片模块 -->
			<div class="slide">
				<div class="slide-wrap">
					<ul>
						<li><a href="#"><img src="./image/20.jpg" alt="点击查看"></a></li>
						<li><a href="#"><img src="./image/21.jpg" alt="点击查看"></a></li>
						<li><a href="#"><img src="./image/22.jpg" alt="点击查看"></a></li>
					</ul>
				</div>
				<ul class="slide-circle">
					<li class="on"></li>
					<li></li>
					<li></li>
				</ul>
			</div>	<!-- 文章列表模块 -->
			<div class="main-body">
				<div class="main-wrap">
					<div class="main-left">
						<div class="al">
							<div class="al-each">
								<div class="al-info"><a href="show.php?id=6">PHP学科：MySQL手册免费分享</a></div>
								<div class="al-desc"></div>
								<div class="al-more">
									<span>作者：博学谷 | 发表于：2016-05-31 14:50:07</span>
									<a href="show.php?id=6">查看原文</a>
								</div>
							</div>
							<div class="al-each">
								<div class="al-info"><a href="show.php?id=5">前端必学框架Bootstrap，3天带你从入门到精通，免费分享！</a></div>
								<div class="al-desc"></div>
								<div class="al-more">
									<span>作者：博学谷 | 发表于：2016-05-31 14:50:07</span>
									<a href="show.php?id=5">查看原文</a>
								</div>
							</div>
							<div class="al-each">
								<div class="al-info"><a href="show.php?id=4">想少走弯路，就看看这个贴：PHPer职业发展规划与技能需求！</a></div>
								<div class="al-desc"></div>
								<div class="al-more">
									<span>作者：博学谷 | 发表于：2016-05-31 14:50:07</span>
									<a href="show.php?id=4">查看原文</a>
								</div>
							</div>
							<div class="al-each">
								<div class="al-info"><a href="show.php?id=3">PHP进阶：要想提高PHP的编程效率，你必须知道的49个要点</a></div>
								<div class="al-desc"></div>
								<div class="al-more">
									<span>作者：博学谷 | 发表于：2016-05-31 14:50:07</span>
									<a href="show.php?id=3">查看原文</a>
								</div>
							</div>
							<div class="al-each">
								<div class="al-info"><a href="show.php?id=2">最涨薪PHP项目—PHP微信公众平台开发</a></div>
								<div class="al-desc">在“智能手机”时代，没有人不识微信！</div>
								<div class="al-img"><a href="show.php?id=2"><img src="./upload/2016-05/16/ed27a1ba3b93801cde7a4d0f2ff26958.png" alt="点击阅读文章"></a></div>
								<div class="al-more">
									<span>作者：博学谷 | 发表于：2016-05-31 14:50:07</span>
									<a href="show.php?id=2">查看原文</a>
								</div>
							</div>
							<div class="pagelist"><span>首页</span><span>上一页</span><a href="?page=1" class="curr">1</a><a href="?page=2">2</a><a href="?page=2">下一页</a><a href="?page=2">尾页</a></div>
						</div>							</div>
					<div class="main-right">
						<div class="si">
							<!-- 栏目列表 -->
							<div class="si-each">
								<div class="si-title">内容栏目</div>
								<div class="si-p1">
									<a href="list.php?cid=1" title="生活">生活</a>
									<a href="list.php?cid=2" title="资讯">资讯</a>
									<a href="list.php?cid=3" title="编程">编程</a>
									<a href="list.php?cid=4" title="互联网">互联网</a>
									<a href="list.php?cid=5" title="科技">科技</a>
								</div>
							</div>
							<!-- 浏览历史 -->
							<div class="si-each">
								<div class="si-title">浏览历史</div>
								<div class="si-p2">
									<p><a href="show.php?id=6">PHP学科：MySQL手册免费分享</a></p>
									<p><a href="show.php?id=5">前端必学框架Bootstrap，3天带你从入门到精通，免费分享！</a></p>
									<p><a href="show.php?id=3">PHP进阶：要想提高PHP的编程效率，你必须知道的49个要点</a></p>
									<p><a href="show.php?id=1">这是第一篇文章</a></p>
									<p><a href="show.php?id=4">想少走弯路，就看看这个贴：PHPer职业发展规划与技能需求！</a></p>
									<p><a href="show.php?id=2">最涨薪PHP项目—PHP微信公众平台开发</a></p>
								</div>
							</div>
							<!-- 最热文章 -->
							<div class="si-each">
								<div class="si-title"><span class="si-p3-top">TOP 10</span> 热门文章</div>
								<div class="si-p3">
									<p><a href="show.php?id=6">PHP学科：MySQL手册免费分享</a></p>
									<p><a href="show.php?id=1">这是第一篇文章</a></p>
									<p><a href="show.php?id=4">想少走弯路，就看看这个贴：PHPer职业发展规划与技能需求！</a></p>
									<p><a href="show.php?id=5">前端必学框架Bootstrap，3天带你从入门到精通，免费分享！</a></p>
									<p><a href="show.php?id=3">PHP进阶：要想提高PHP的编程效率，你必须知道的49个要点</a></p>
									<p><a href="show.php?id=2">最涨薪PHP项目—PHP微信公众平台开发</a></p>
								</div>
							</div>
						</div>			</div>
				</div>
			</div>
		</div>
		<!--页面尾部-->
		<div class="footer">PHP内容管理系统　本系统仅供参考和学习</div>
	</body>
</html>