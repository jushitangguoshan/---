<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/2 0002
     * Time: 下午 3:08
     */

    namespace think\paginator\driver;
    #自定义类 -------  通过修改动态配置Config::set('paginate',[....]) 模仿原本目录文件bootstrap 中的调用方式构造函数
    class Mypage extends \think\Paginator
    {
        public function render(){
            $frist='<a href="?page=1">[首页]</a>';
            if( $this->currentPage() <= 1){
                $frist="[首页]";
            }
            $end='<a href="?page='.$this->lastPage().'">[尾页]</a>';
            if( !$this->hasMore ){
                $end="[尾页]";
            }
            $str="当前为 %s/%s  %s  %s  %s  %s";
            return sprintf($str,
                $this->currentPage(),
                $this->lastPage,
                $frist,
                $this->getPreviousButton(),
                $this->getNextButton(),
                $end
            );
        }
        /**
         * 首页按钮
         * @param string $text
         * @return string
         */
        protected function getFristButton($text = "[尾页]")
        {
            if ($this->currentPage() <= 1) {
                return $text;
            }
            $url = $this->url($this->currentPage() - 1);
            return "<a href='". htmlentities($url) . "'>". $text ."</a>";
        }
        /**
         * 上一页按钮
         * @param string $text
         * @return string
         */
        protected function getPreviousButton($text = "[上一页]")
        {
            if ($this->currentPage() <= 1) {
                return $text;
            }
            $url = $this->url($this->currentPage() - 1);
            return "<a href='". htmlentities($url) . "'>". $text ."</a>";
        }
        /**
         * 下一页按钮
         * @param string $text
         * @return string
         */
        protected function getNextButton($text = '[下一页]')
        {
            if (!$this->hasMore) {
                return $text;
            }
            $url = $this->url($this->currentPage() + 1);
            return "<a href='". htmlentities($url) . "'>". $text ."</a>";
        }


    }