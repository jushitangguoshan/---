/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 5.6.17 : Database - article_one
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`uZVZRQAaEbNHAesVVUwd` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `uZVZRQAaEbNHAesVVUwd`;

/*Table structure for table `column` */

DROP TABLE IF EXISTS `column`;

CREATE TABLE `column` (
  `name` varchar(10) NOT NULL COMMENT '栏目名称',
  `p_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '父栏目id',
  `creater` varchar(10) NOT NULL COMMENT '创建栏目用户',
  `amen_time` int(11) DEFAULT NULL COMMENT '修改时间',
  `article_count` int(11) DEFAULT NULL COMMENT '栏目中文章总数',
  `state` int(11) NOT NULL DEFAULT '1' COMMENT '栏目状态(0已删除)',
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT COMMENT '栏目id',
  `show_sort` int(11) DEFAULT NULL COMMENT '显示顺序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

/*Data for the table `column` */

insert  into `column`(`name`,`p_id`,`creater`,`amen_time`,`article_count`,`state`,`id`,`show_sort`) values ('生活',0,'',1545315956,NULL,1,1,1),('国内实时',0,'',1545352837,NULL,1,2,2),('编程',0,'',1545352905,NULL,1,3,3),('互联网',0,'',1545352913,NULL,1,4,4),('科技',0,'',1545314231,NULL,1,5,5),('厨艺',1,'',1545228146,NULL,1,6,4),('时装',1,'',1545197401,NULL,1,7,9),('新闻资讯',2,'',1545352835,NULL,1,8,1),('学术观点',2,'',1545352832,NULL,1,10,2),('实事点评',2,'',1545352774,NULL,1,11,3),('PHP',3,'',1545352903,NULL,1,12,1),('Java1',3,'',1545395449,NULL,1,13,2),('Android',3,'',1545384826,NULL,0,14,3),('网络理财',4,'',1545352910,NULL,1,15,1),('硬件',5,'',1545315091,NULL,1,16,1),('财经',0,'',1545315983,NULL,1,17,6),('泡沫经济',17,'',1545186046,NULL,1,18,1),('城市之声',2,'',1545352772,NULL,1,19,4),('政治执法',2,'',1545352769,NULL,1,20,5),('test',5,'',1545315089,NULL,1,21,2),('testaa',0,'',NULL,NULL,1,23,7),('test51',5,'',1545315086,NULL,1,24,3),('test61',17,'',NULL,NULL,1,25,2),('test62',17,'',NULL,NULL,1,26,3),('teataa1',0,'',1545186671,NULL,1,27,8),('生活选项1234',1,'',1545395562,NULL,1,29,3),('test63',17,'',1545315628,NULL,1,36,NULL),('testaa==',0,'',NULL,NULL,1,37,NULL),('testbb==',0,'',1545314776,NULL,1,38,NULL),('test66',0,'',1545316059,NULL,1,39,NULL),('testbbb+1',38,'',1545271200,NULL,1,40,NULL),('testbbb+2',38,'',1545308442,NULL,1,41,NULL),('tesbb+3',38,'',1545271337,NULL,1,42,NULL),('tesbb+4',38,'',1545271191,NULL,1,43,NULL),('tes66+1',39,'',1545308445,NULL,1,44,NULL),('tes66+2',39,'',1545271246,NULL,1,45,NULL),('tes66+3',39,'',1545271297,NULL,1,46,NULL),('test11',0,'',NULL,NULL,1,47,NULL),('厨艺2',1,'',1545384856,NULL,0,48,NULL),('厨艺5',1,'',1545384823,NULL,0,49,NULL),('厨艺6',1,'',1545384819,NULL,0,50,NULL),('厨艺7',1,'',1545384817,NULL,0,52,7),('美文片段',0,'',NULL,NULL,1,53,110),('生活选项2',1,'',1545385506,NULL,0,54,2),('生活选项5',1,'',1545385504,NULL,0,55,5);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
