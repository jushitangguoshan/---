<?php
    // header("location:cms/index.php");
   header("location:cms/");
