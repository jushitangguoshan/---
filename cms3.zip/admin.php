<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/26 0026
     * Time: 上午 10:03
     */
    header("location:cms/module\login\login.html");