<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/26 0026
     * Time: 上午 11:09
     */
    header("location:module\qtPage\php\index.php");