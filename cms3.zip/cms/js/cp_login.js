var mark=1;//判断验证码标志
$(function(){
    dl_ope();
    changeYzm();
});
//登录判断
function dl_ope(){
    $('#dl_login').click(function(){
        if(  $("[name='dl_username']").val() == '' || $("[name='dl_pwd']").val() == '' ){
            layer.msg("账户密码不能为空");
            return;
        }
        //$.param({'importYzm':$('#dl_yzm').val()})+"&"+ $('form').serialize()
        //在序列化后的表单追加属性字段
        var data =$('form').serialize()+"&"+
            $.param({'importYzm':$('#dl_yzm').val()})+"&"+$.param({'mark':mark}) ;
        $.ajax({
            url:"login.php?ope=dl",
            type:'post',
            data: data,
            cache:false,
            dataType:'json',
            success:function(res){
                console.log(res);
                if( res.statu === 0 ) {  //  用户名不存+账户已冻结+证码输入错误
                    layer.msg(res.message);
                }else if( res.statu === -1){ //用户名或密码错误
                    $('.dl_yzm').show();
                    layer.msg(res.message);
                }else{
                    window.location.href=("../bgfile/html/index.html");
                }
            }
        });
        mark++;
    })
}

//阻止表单提交
function exitSubmit(){
    return false;
}
//验证码点击函数
function changeYzm(){
    $('#yzm').click(function(){
        $(this).attr('src','../gd/yzm.php?'+Math.random(0,100));
    });
}
