<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="PHP,内容,管理">
<meta name="description" content="PHP内容管理系统">
<title>首页 - 内容管理系统</title>
<link rel="stylesheet" href="../../../css/style.css">

</head>
<body>
<!--页面顶部-->
<div class="top">
	<div class="top-container">
		<div class="top-logo">
			<a href="./"><img src="../../../image/logo.png" alt="内容管理系统"></a>
		</div>
		<div class="top-nav">
			<a href="./" class="curr">首页</a>
               <a href="../html/list.html?cid=2" class="">资讯</a>
               <a href="../html/list.html?cid=3" class="">编程</a>
               <a href="../html/list.html?cid=4" class="">互联网</a>
               <a href="../html/list.html?cid=5" class="">科技</a>
                <a href="about.php" class="">联系我们</a>
		</div>
		<div class="top-toggle jq-toggle-btn"><i></i><i></i><i></i></div>
	</div>
</div>
