<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/12 0012
     * Time: 上午 10:41
     */
    $link=mysqli_connect("sqld-gz.bcehost.com","ca3a0c72c0d14d02960577145c3d0afc","fd11bb6cd7a44fbb9715029b7b66687b","uZVZRQAaEbNHAesVVUwd");
    if( !$link ){
        file_put_contents("../log/mysql_error.log",date("Y-m-d H:i:s")."文件：" .__FILE__.",第". __LINE__ ."行附近"."\n"."报错内容：".mysqli_connect_error(),FILE_APPEND);
        die;
    }
    if(!mysqli_set_charset($link,"utf8")){//检查 ——设置字符集
        file_put_contents('../log/mysql_error.log',date('Y/m/d H:i:s').'文件：'. __FILE__ .'，第'. __LINE__ .'行附近'."\n".'报错内容：'.mysqli_error($link),FILE_APPEND);
        die;
    }




