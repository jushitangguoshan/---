<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/25 0025
     * Time: 下午 7:54
     */
    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志
    if( !isset($_GET['ope']) )die;

    if( $_GET['ope']=='init' ){

        $cid=$_POST['id'];
        $sql="select *from `column` where id={$cid}";
        $nowArr=getMysqlArr($sql);//--------当前栏目

        $sql="select *from `column` where p_id={$cid}";
        $arr=getMysqlArr($sql);//------------当前栏目中所有子栏目

        $sql="select *From `articles` where belongto_column={$cid}";
        $arrCont=getMysqlArr($sql);//---------当前栏目中所有文章内容

        $sql="select article_id,title From articles where belongto_column={$cid} order by click_num desc limit 0,10";
        $arrHistory=getMysqlArr($sql);//热门文章--数组


        if( isset( $_COOKIE['hist'] ) ) {//------取出浏览历史
            $url = $_COOKIE['hist'];//读取cookie
            $krr = unserialize($url);//将字符串内容转为数组
            $histArr= getHistArr($krr);
        }else{
            $histArr =[];
        }
        $sql="select *from `column`";
        $arrCol=getMysqlArr($sql);//------------当前栏目中所有子栏目
        $colArrs=getcols($arrCol,$cid);
        echo json_encode(['arr'=>$arr,
            'allSon'=>$arrCont,
            'hot'=>$arrHistory,
            'nowArr'=>$nowArr,
            'hist'=>$histArr,
            'col'=>$colArrs]
            );
    }


    function getcols($arrCol,$cid){
        $c=[];
        foreach( $arrCol as $k=>$val ){
            if( $cid == $val['id'] ){
                $c[]=$val['name'];
                return $c;
            }
        }

    }