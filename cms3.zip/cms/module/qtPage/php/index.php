<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="PHP,内容,管理">
<meta name="description" content="PHP内容管理系统">
<title>首页 - 内容管理系统</title>
<link rel="stylesheet" href="../../../css/style.css">
<script src="../js/jquery_all.js"></script>
<!--<script src="../js/common.js"></script>-->
        <link rel = "stylesheet" href = "../../../js/layui/css/layui.css">
   <script src="../../../js/layui/layui.all.js"></script>
<script src="../js/indexHeadle.js"></script>

</head>
<body>
    <!--顶部导航栏-->
    <?php include "../../../public/header.php";
    ?>
    <!--页面内容-->
<div class="main">
	<!-- 幻灯片模块 -->

     <div class="layui-carousel" id="test10">
          <div carousel-item="">
               <div><img src="../../../image/20.jpg"></div>
               <div><img src="../../../image/21.jpg"></div>
               <div><img src="../../../image/22.jpg"></div>
          </div>
</div>

<!--     <div class="slide">-->
<!--          <div class="slide-wrap">-->
<!--               <ul>-->
<!--                    <li><a href="#"><img src="../../../image/20.jpg" alt="点击查看"></a></li>-->
<!--                    <li><a href="#"><img src="../../../image/21.jpg" alt="点击查看"></a></li>-->
<!--                    <li><a href="#"><img src="../../../image/22.jpg" alt="点击查看"></a></li>-->
<!--               </ul>-->
<!--          </div>-->
<!--          <ul class="slide-circle">-->
<!--               <li class="on"></li>-->
<!--               <li></li>-->
<!--               <li></li>-->
<!--          </ul>-->
<!--     </div>	-->
     <!-- 文章列表模块 -->
     <div class="main-body">
          <div class="main-wrap">
               <div class="main-left">
                    <div class="al"> </div>
                    <div class="pagelist">  </div>
               </div>
               <div class="main-right">
                    <div class="si">
                         <!-- 栏目列表 -->
                         <div class="si-each">
                              <div class="si-title">内容栏目</div>
                              <div class="si-p1">
                              </div>
                         </div>
                         <div class="si-each">
                              <div class="si-title"><span class="si-p3-top">TOP 10</span> 热门文章</div>
                              <div class="si-p3">
                              </div>
                         </div>
                    </div>
               </div>
          </div>
     </div>
</div>
    <!--页面尾部-->
    <div class="footer">PHP内容管理系统　本系统仅供参考和学习</div>
</body>

</html>