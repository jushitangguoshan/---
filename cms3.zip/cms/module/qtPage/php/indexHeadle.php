<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/25 0025
     * Time: 上午 9:57
     */
    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志
    if( !isset($_GET['ope']) )die;

    switch( $_GET['ope'] ){
        case 'init':
            echo json_encode( init() );
            break;

    }
    function init(){
        //var_dump($_POST,$_GET);
        $sql="select *from `column` where state<>0 and p_id=0 ";
        $arrOne=getMysqlArr($sql);//所有文章数组
        $page=$_GET['page'];//获取当前页码
        $limit=$_GET['limit'];//获取每页限制行数
        $str="limit ".(($page-1)*$limit).",".$limit;//从(($page-1)*5)开始取limit长度的数组

        $sql="select article_id,title,author_name,create_time,img_path from articles where state=1 {$str}";  //echo $sql;die;
        $arrTwo=getMysqlArr($sql);//---------取当前页面所有文章数组

        $sql="select count(*) as num from articles where state=1";
        $krr=getMysqlArr($sql);//-------------取所有已发布文章总数
        $sumPage=ceil($krr[0]['num']/$limit);

        $sql="select article_id,title From articles order by click_num desc limit 0,10";
        $arrHistory=getMysqlArr($sql);//热门文章--数组

        return ['arrOne'=>$arrOne,'arrTwo'=>$arrTwo,'sumPage'=>$sumPage,'hot'=>$arrHistory];
    }
