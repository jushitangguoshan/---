<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/25 0025
     * Time: 上午 10:43
     */
    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志
    if( !isset($_GET['ope']) )die;
    switch( $_GET['ope'] ){
        case 'init':
            echo json_encode( init() );
            break;
    }
    //保存浏览历史记录
//    function saveRecord(){
//        if( isset( $_COOKIE['hist'] ) ){
//            $url=$_COOKIE['hist'];//读取cookie
//            $arr=unserialize($url);//将字符串内容转为数组
//            $arr[]= $id=$_POST['id'];;//获取当前url放到数组中
//            $arr=array_unique($arr);//数组去重
//            if( count($arr)>3 ){
//                array_shift($arr);//移除数组第一个值
//            }
//            $krr=$arr;//-----------------临时存放数组--------------
//            $url=serialize($arr);
//            setcookie('hist',$url);
//        }else{
//            $url= $id=$_POST['id'];;//将字符串内容转为数组
//            $arr[]=$url;//获取当前url放到数组中
//            $krr=$arr;//-----------------临时存放数组-----------------
//            $url=serialize($arr);
//            setcookie('hist',$url);
//        }
//        if( count($krr)<2 ){
//            $sql="select article_id,title from articles where article_id={$krr[0]}";
//        }else if( count($krr)<3 ){
//            $sql="select article_id,title from articles where article_id={$krr[0]} or article_id={$krr[1]}";
//        }else{
//            $sql="select article_id,title from articles where article_id={$krr[0]} or article_id={$krr[1]} or article_id={$krr[2]}";
//        }
//        $mkk=getMysqlArr($sql);
//        return $mkk;
//    }
    //初始化
    function init(){
        $id=$_POST['id'];//----------取得文章id
        $sql="select *from articles where article_id={$id}";
        $arr=getMysqlArr($sql);//本页文章--
        if( $arr ){
            $sql="select *from `column` where state<>0 and p_id=0 ";
            $colArr=getMysqlArr($sql);//主栏目--数组

            $sql="select article_id,title From articles order by click_num desc limit 0,10";
            $hotArr=getMysqlArr($sql);//热门文章--数组

            $sql="select *from `column` where id={$arr[0]['belongto_column']}";
            $nowCol=getMysqlArr($sql);//--------当前栏目

            $num=$arr[0]['click_num']+1;
            $sql="update articles set click_num={$num} where article_id={$id}";
            addDelAlt($sql);//执行sql语句

            $sql="SELECT * FROM `articles` WHERE article_id<{$id} and state=1 ORDER BY article_id DESC LIMIT 1";
            $prev=getMysqlArr($sql);
            $sql="SELECT * FROM `articles` WHERE article_id>{$id} and state=1 ORDER BY article_id ASC LIMIT 1";
            $next=getMysqlArr($sql);
           $histArr= getHistArr( saveRecord() );//--------------保存cookie;
            return [
                'arr'=>$arr,//所有文章
                'arrOne'=>$colArr,//所有栏目
                'hot'=>$hotArr,//热门文章
                'nowArr'=>$nowCol,//当前文章
                'next'=>$next,//下一篇文章
                'prev'=>$prev,//上一篇文章
                'hist'=>$histArr//历史记录
            ];
        }
    }