$(function(){
    layui.use(['carousel'], function() {
        var carousel = layui.carousel;
        //图片轮播
      var ins=  carousel.render({
            elem: '#test10'
            , width: '100%'     //设置容器宽度
            , arrow: 'always'    //始终显示箭头，可选hover,none
            //,anim: 'updown'    //切换动画方式，可选fade,default
            , full: false        //全屏
            , autoplay: true     //自动切换
            , interval: 1000     //自动切换的时间间隔
            , index: 3           //初始化时item索引,默认时0
            , indicator:'inside' //指示器位置，可选outside,none
            ,arrow: 'always'
        });
        //**************************监听轮播切换事件
        carousel.on('change(carofilter)', function (obj) { //test1来源于对应HTML容器的 lay-filter="test1" 属性值
            console.log(obj.index);     //当前条目的索引
            console.log(obj.prevIndex); //上一个条目的索引
            console.log(obj.item);      //当前条目的元素对象
        });
        ins.reload({arrow:'hover'});//将arror从alway变成hover
    })
    init();
    //页码点击事件
    $('body').on('click','.pagelist a',function(){
        var page=$(this).data('page');
        callAjax(page,5,5);
    })

})
function init(){
    callAjax(1,5,5);//（当前页数，显示按钮个数，显示名单个数）
}
//分页ajax
function callAjax(page,btn,limit){
    $.ajax({
        url:'../php/indexHeadle.php?ope=init&page='+page+'&limit='+limit,
        dataType:'json',
        success:function(res){
            console.log(res);
            var html="";
            //显示文章列表
            for(var i=0; i<res.arrTwo.length; i++){
             html +='<div class="al-each">' +
                    '<div class="al-info"><a href="../html/show.html?id='+res.arrTwo[i]['article_id']+'">'+res.arrTwo[i]['title']+'</a></div>' +
                    '<div class="al-desc"></div>';
             if( res.arrTwo[i]['img_path'] !== null){
                 html+= '<div class="al-img">' +
                     '<a href="../html/show.html?id='+res.arrTwo[i]['article_id']+'"><img src="'+res.arrTwo[i]['img_path']+'" alt="点击阅读文章"></a>' +
                     '</div>'
             }else {
                 html+= '<span>未上传封面图片</span>';
             }

             html+='<div class="al-more">' +
                    '<span>作者：'+res.arrTwo[i]['author_name']+' | 发表于：'+getLocalTime(res.arrTwo[i]['create_time'])+'</span>' +
                    '<a href="../html/show.html?id='+res.arrTwo[i]['article_id']+'">查看原文</a>' +
                    '</div>' +
                    '</div>';
            }
            $('.al').html(html);
            //显示内容栏目
            var htmls="";
            for( var j=0;j<res.arrOne.length; j++ ){
                   htmls +='<a href="../html/list.html?cid='+res.arrOne[j]['id']+'" title="'+res.arrOne[j]["name"]+'">'+res.arrOne[j]["name"]+'</a>' ;
            }
            $('.si-p1').html(htmls);

           showPage(page,btn,res.sumPage);
            //显示热门文章
            var html="";
            for( var i=0; i<res.hot.length; i++){
                html += '<p><a href="../html/show.html?id='+res.hot[i]['article_id']+'">'+res.hot[i]['title']+'</a></p>';
            }
            $('.si-p3').html(html);
        }
    })
}

function showPage(page,btn,sumpage){
    var html="";
    var start=page;//当前页;
   if(page<=1){
       html +="<span>首页</span> <span>上一页</span>";
   }else {
       html +=" <a href='#page=1' data-page=1>首页</a> <a href='#page="+(page-1)+"' data-page="+(page-1)+">上一页</a> ";
   }
   // cms/module/login/login.html
   var end=start+btn;
   if(end >= sumpage){
       end=sumpage;
       start=end-btn;
   }
   if(start<1){
       start=1;
   }
    if(page>1 && end<=sumpage && end>btn){///////////
        html +="<span>....</span>";
    }
   for( var i=start; i<=end; i++ ){
       if(page==i){
           html +=' <a href="#page='+i+'" class="curr" data-page='+i+'>'+i+'</a>';
       }else{
           html +=' <a href="#page='+i+'" data-page='+i+'>'+i+'</a>';
       }
   }
    if(end<sumpage){///////////
        html +="<span>....</span>";
    }
    if(page>=sumpage){
        html +="<span>下一页</span> <span>尾页</span>";
    }else {
        html +=" <a href='#page="+(page+1)+"' data-page="+(page+1)+">下一页</a> <a href='#page="+sumpage+"' data-page="+sumpage+">尾页</a> ";
    }

    $('.pagelist').html(html);
}
//-----------------------转换时间显示
function getLocalTime(nS) {
    return new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
}