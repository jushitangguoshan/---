var cols=[];
$(function(){
    layui.use('element', function(){
        var element = layui.element;
        element.init();
        //一些事件监听
        element.on('tab(demo)', function(data){
            console.log(data);
        });
    });
    init();
    getColId();
})
/////初始化
function init(){
    var id=getColId();
    $.ajax({
        url:'../php/list.php?ope=init',
        type:'post',
        dataType:'json',
        data:{id:id},
        success:function(res){
            console.log(res);
            // cols.push(res.col);
            giveValue(res.nowArr[0]);
            var html="";
            //显示文章列表
            for(var i=0; i<res.allSon.length; i++){
                html +='<div class="al-each">' +
                    '<div class="al-info"><a href="./show.html?id='+res.allSon[i]['article_id']+'">'+res.allSon[i]['title']+'</a></div>' +
                    '<div class="al-desc"></div>';
                if( res.allSon[i]['img_path'] !== null){
                    html+= '<div class="al-img">' +
                        '<a href="./show.html?id='+res.allSon[i]['article_id']+'"><img src="'+res.allSon[i]['img_path']+'" alt="点击阅读文章"></a>' +
                        '</div>'
                }else {
                    html+= '<span>未上传封面图片</span>';
                }
                html+='<div class="al-more">' +
                    '<span>作者：'+res.allSon[i]['author_name']+' | 发表于：'+getLocalTime(res.allSon[i]['create_time'])+'</span>' +
                    '<a href="./show.html?id='+res.allSon[i]['article_id']+'">查看原文</a>' +
                    '</div>' +
                    '</div>';
            }
            $('.al-title').append(html);
            //显示内容栏目
            var htmls="";
            if(res.arr.length<1){//--------判断有没有子栏目
                htmls +='<span>无子栏目</span>';
            }else {
                for (var j = 0; j < res.arr.length; j++) {
                    htmls += '<a href="./list.html?cid=' + res.arr[j]['id'] + '" title="' + res.arr[j]["name"] + '">' + res.arr[j]["name"] + '</a>';
                }
            }
            $('.si-p1').html(htmls);


            //显示热门文章
            var html="";
            if( res.hot.length>1){
                for( var i=0; i<res.hot.length; i++){
                    html += '<p><a href="./show.html?id='+res.hot[i]['article_id']+'">'+res.hot[i]['title']+'</a></p>';
                }
            }else{
                html += '<p>当前栏目没有热门文章</p>';
            }
            $('.si-p3').html(html);


            //显示历史记录
            var html="";
            if( res.hist.length>0 ){//--------判断有没有浏览历史
                for( var i=0; i<res.hist.length; i++){
                    html += '<p><a href="./show.html?id='+res.hist[i]['article_id']+'">'+res.hist[i]['title']+'</a></p>';
                }
            }else{
                html +='<span>无浏览历史</span>';
            }
            $('.si-p2').html(html);
        }
    });

}
function giveValue(arr){
    $('.al-title h1').append( arr['name'] );
}



////////获取栏目id
function getColId(){
    var str=window.location.search;
    var str=str.split("=");
   return str[1];
}
//-----------------------转换时间显示
function getLocalTime(nS) {
    return new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
}