$(function(){
   init();
 //  $.cookie('hist',getParam('id'),{path:'/'});
})
function init(){
    var id=getParam('id');
    $.ajax({
        url:'../php/show.php?ope=init',
        type:'post',
        dataType:'json',
        data:{id:id},
        success:function(res) {
            console.log(res);
            giveValue(res.arr[0], res.nowArr[0], res.next[0], res.prev[0]);
            //显示内容栏目
            var htmls = "";
            for (var j = 0; j < res.arrOne.length; j++) {
                htmls += '<a href="./list.html?cid=' + res.arrOne[j]['id'] + '" title="' + res.arrOne[j]["name"] + '">' + res.arrOne[j]["name"] + '</a>';
            }
            $('.si-p1').html(htmls);


            //显示热门文章
            var html="";
            if( res.hot.length>1) {
                for (var i = 0; i < res.hot.length; i++) {
                    html += '<p><a href="./show.html?id=' + res.hot[i]['article_id'] + '">' + res.hot[i]['title'] + '</a></p>';
                }
            }else{
                html += '<p>当前栏目没有热门文章</p>';
            }
            $('.si-p3').html(html);


            //显示历史记录
            if (res.hist.length > 0) {
                var html = "";
                for (var i = 0; i < res.hist.length; i++) {
                    html += '<p><a href="./show.html?id=' + res.hist[i]['article_id'] + '">' + res.hist[i]['title'] + '</a></p>';
                }
                $('.si-p2').html(html);
            }
        }
    });
}
//显示内容
function giveValue(obj,col,nextObj,prevObj){

    $('#as-title').html( obj['title'] );
    $('#author').html( obj['author_name'] );
    $('#create-time').html( getLocalTime(obj['create_time']) );
    $('#count-read').html( obj['click_num'] );
    $('#content').html( obj['content'] );
    if(nextObj){
        $("#next").html(nextObj.title );
        $('#next').attr('href',"?id="+nextObj.article_id);
    }else{
        $("#next").html("无" );
        $('#next').attr('href',"#");
    }
    if(prevObj){
        $("#prev").html(prevObj.title );
        $('#prev').attr('href',"?id="+prevObj.article_id);
    }else{
        $("#prev").html("无" );
        $('#prev').attr('href',"#");
    }


}

//获取url参数
function getParam(paramName) {
    paramValue = "", isFound = !1;
    if (this.location.search.indexOf("?") == 0 && this.location.search.indexOf("=") > 1){
        arrSource = unescape(this.location.search).substring(1, this.location.search.length).split("&"),i = 0;
        while (i < arrSource.length && !isFound) arrSource[i].indexOf("=") > 0 && arrSource[i].split("=")[0].toLowerCase() == paramName.toLowerCase() && (paramValue = arrSource[i].split("=")[1], isFound = !0), i++
    }
    return paramValue == "" && (paramValue = null), paramValue;
}
//转换时间
function getLocalTime(nS) {
    return new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
}
