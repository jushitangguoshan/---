<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/12 0012
     * Time: 上午 10:31
     */
    session_start();
    header('Content-Type:application/json; charset=utf-8');
    include_once "../../public/connect.php";//引入数据库
    include_once "../resource/function.php";//引入函数
//var_dump($_POST);die;
    $yzm=$_SESSION['yzm'];//取得验证码
    $time=time();//获取创建时间
    $ip=$_SERVER['SERVER_ADDR'];//获取登录用户ip
    //------------------------登录判断
if( $_GET['ope'] == 'dl' ){
    //var_dump($_POST,$_GET);die;
    $name= returnStr($_POST['dl_username'],'m');
    $pwd= returnStr($_POST['dl_pwd'],'m');
    /*--------------------数据校验--------------*/
   //sql查询该用户名是否存在
   $sql = "select * from user where name='{$name}'";
   $res=mysqli_query($link,$sql);
   //获取账户密码查询结果
    $arr=mysqli_fetch_all($res,MYSQLI_ASSOC);
    $id=$arr[0]['id'];//获取当前用户id
   // var_dump($name,$sql,$arr);die;
    //判断账户密码是否错误
    if( !$arr ){
        echo json_encode(['statu'=>0,'message'=>'用户名不存在']);
    }else if( md5($pwd+123) !== $arr[0]['pwd']){
       echo json_encode(['statu'=>-1,'message'=>'用户名或密码错误']);
   }else if( $arr[0]['state']<1 ){
       echo json_encode(['statu'=>0,'message'=>'账户已冻结']);
   }else if( $_POST['mark'] !=1 && $yzm !== $_POST['importYzm']){
        echo json_encode(['statu'=>0,'message'=>'验证码输入错误']);
   }else{
       $ope="登录成功";
       $putLogSql=putLogs($name,$id,$ope);  //记录日志
       //设置登陆者时间:
       $upStateSql="update user set login_time='{$time}' where name='{$name}'";
       addDelAlt($upStateSql,$putLogSql);//记录事务日志
       mysqli_query($link,"commit");//提交事务
       //查询登录者的权限
       $sql = "select id,roots  from user where name='{$name}'";
       $arr=getMysqlArr($sql);
       //设置session

       $_SESSION['yzm']='';
       $_SESSION['username']=$name;//保存用户名
       $_SESSION['dl_id']=$arr[0]['id'];//保存用户id
       $_SESSION['root']=$arr[0]['roots'];//保存权限
       $_SESSION['mark']='isLogin';
       echo json_encode(['statu'=>1,'message'=>'登录成功！']);
   }
}
