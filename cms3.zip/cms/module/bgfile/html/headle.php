<?php
//    /**
//     * Created by PhpStorm.
//     * User: Administrator
//     * Date: 2018/12/12 0012
//     * Time: 下午 4:45
//     */
//header("content-type:application/json;charset=utf-8");
//include_once "../../public/connect.php";
//include_once "../../public/function.php";//引入函数--存日志
////获取当前登录用户的信息--去id
//
//session_start();
//$dl_name=returnStr($_SESSION['username'],'m');
//$arr=getMysqlArr("select *from user where name='{$dl_name}'");
//$login_id=returnStr($arr[0]['id'],'m');//当前登录的用户id
//$time=time();//获取创建时间
//$ip=$_SERVER['SERVER_ADDR'];//获取登录用户ip
//
//
//
//
//
///*-----------------------------------栏目管理*/
//    //-------删除部分
//    if($_GET['ope']=='delCol'){
//       // var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//       $del_id=$_POST['delId'];
//       $sql="update `column` set state=0 where id={$del_id}";
//       if( addDelAlt($sql) ){//返回执行sql 语句结果
//           $ope="删除栏目成功";
//           $putLogs=putLogs($dl_name,$login_id,$ope);
//           $upStateSql="update `column` set amen_time={$time} where id={$del_id}";
//           addDelAlt($putLogs,$upStateSql);
//           mysqli_query($link,"commit");//提交事务
//           $arr=getMysqlArr("select *from `column` where state=1");
//           echo json_encode(['statu'=>1,'arr'=>$arr,'message'=>$ope]);
//       }else{
//           echo json_encode(['statu'=>0,'message'=>"删除失败"]);
//       }
//    }
//    //----修改栏目
//    else if($_GET['ope']=='editCol'){//顺序未完
//      //  var_dump($_POST);die;
//    $altId=returnStr($_POST['altid'],'m')+0;//查询条件
//    $colName=returnStr($_POST['name'],'m');
//    $colPId=returnStr($_POST['pid'],'m');
//    $show_srot=returnStr($_POST['sort'],'m');
//
//    $sql="update `column` set `name`='{$colName}',show_sort={$show_srot},p_id={$colPId} where id={$altId}";
//    //echo $sql;die;
//        if( addDelAlt($sql) ){//返回执行sql 语句结果
//            $ope="修改栏目成功";
//            $putLogs=putLogs($dl_name,$login_id,$ope);
//            $upStateSql="update `column` set amen_time={$time} where id={$altId}";
//            addDelAlt($putLogs,$upStateSql);
//            mysqli_query($link,"commit");//提交事务
//            echo json_encode(['statu'=>1,'arr'=>$arr,'message'=>$ope]);
//        }else{
//            echo json_encode(['statu'=>0,'message'=>"修改栏目失败"]);
//        }
//    }
//    //-------增加栏目部分
//    else if($_GET['ope']=='addCol'){
//        // var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//        $arr=$_POST['arr'];
//        $leng=count($arr);                 //         .returnStr($value[2],'m').
//        mysqli_query($link,"begin");
//        $sql="insert into `column` (`name`,p_id,show_sort) values";
//        foreach($arr as $key=>$value){
//            if($key==$leng-1) {
//                $sql.="('".returnStr($value[1],'m')."','".returnStr($value[2],'m')."','".returnStr($value[0],'m')."');";
//            }else{
//                $sql.="('".returnStr($value[1],'m')."','".returnStr($value[2],'m')."','".returnStr($value[0],'m')."'),";
//            }
//        }
//       // echo $sql;die;
//        if( !addDelAlt($sql) ){
//            mysqli_query($link,"collback");
//            echo json_encode(['statu'=>0,'message'=>"增加失败"]);
//        }else{
//            $ope="增加栏目成功";
//            $putLogs=putLogs($dl_name,$login_id,$ope);
//            addDelAlt($putLogs);
//            mysqli_query($link,"commit");
//            echo json_encode(['statu'=>1,'message'=>$ope]);
//        }
//    }
//
//
//
//
//
//
///*-----------------------------------文章管理*/
//
//    //-------------csv操作
//else if($_GET['ope']=="importCsvArticle"){//导入
//    //var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//        $filename = $_FILES['file']['tmp_name'];
//        if (empty ($filename)) {
//            echo json_encode(['statu'=>0,'message'=>'请选择要导入的CSV文件！']);
//            exit;
//        }
//        $handle = fopen($filename, 'r');
//        $result = input_csv($handle); //解析csv
//        $len_result = count($result);
//        if($len_result==0){
//            echo json_encode(['statu'=>0,'message'=>'没有任何数据！']);
//            exit;
//        }
//        for ($i = 0; $i < $len_result; $i++) { //循环获取各字段值
//            $author_name = iconv('gb2312', 'utf-8', $result[$i][0]); //中文转码
//            $title = iconv('gb2312', 'utf-8', $result[$i][1]);
//            $description = iconv('gb2312', 'utf-8', $result[$i][2]);
//            $data_values .= "('$author_name','$title','$description'),";
//        }
//        $data_values = substr($data_values,0,-1); //去掉最后一个逗号
//        fclose($handle); //关闭指针
//        $query = mysqli_query($link,"insert into articles (author_name,title,description) values $data_values");//批量插入数据表中
//        if($query){
//            echo json_encode(['statu'=>1,'message'=>'导入成功！']);
//        }else{
//            echo json_encode(['statu'=>0,'message'=>'导入失败！']);
//        }
//}
//else if($_GET['ope']=="exportLogCsv"){
//    //var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//    $result = mysqli_query($link,"select * from logs order by id asc");
//    $str = "信息,时间,当前登录用户,操作内容,本地ip\n";
//    $str = iconv('utf-8','gb2312',$str);
//    while($row=mysqli_fetch_array($result)){
//        $message = iconv('utf-8','gb2312',$row['message']); //中文转码
//        $opeTime = iconv('utf-8','gb2312',$row['time']);
//        $user_id = iconv('utf-8','gb2312',$row['user_id']);
//        $opeteat = iconv('utf-8','gb2312',$row['opeteat']);
//        $opeIp = iconv('utf-8','gb2312',$row['ip']);
//        $str .= $message.",".$opeTime.",".$user_id.",".$opeteat.",".$opeIp."\n"; //用引文逗号分开
//    }
//    $filename = date('Ymd').'.csv'; //设置文件名
//    export_csv($filename,$str); //导出
//
//}
//
//        //-------------筛选操作
//else if($_GET['ope']=="screening"){
//     //var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//    $colId=$_POST['colId'];
//    $sql="select *from articles where belongto_column= ";
//    if($colId==""){
//        $sql="select *from articles where state<>-1 ";
//    }else{
//        $sql .=$colId;
//    }
//    $arr=getMysqlArr($sql);
//    echo json_encode(['statu'=>1,'arr'=>$arr]);
//}
//         //-------------删除操作
//else if($_GET['ope']=="del_article"){
//   // var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//    $id=returnStr($_POST['id'],'m');
//    $sql="update articles set state=-1 where article_id={$id}";
//    if( !addDelAlt($sql) ){
//        echo json_encode(['statu'=>0,'message'=>"删除失败"]);
//    }else{
//        $ope="删除文章成功";
//        $putLogs=putLogs($dl_name,$login_id,$ope);
//        $upStateSql="update articles set amend_time='{$time}',amend_content='{$ope}' where article_id={$id}";
//        addDelAlt($putLogs,$upStateSql);
//
//        $arr=getMysqlArr("select *from articles where state <> -1");
//        echo json_encode(['statu'=>1,'arr'=>$arr,'message'=>$ope]);
//    }
//}
//         //---------------编辑文章模块
//else if($_GET['ope']=='edit'){
//    //var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//    //判断必填项不能为空---
//    if( isExistEmpty($_POST['author'],$_POST['title'],$_POST['cid']) ){
//        echo json_encode(['statu'=>0,'message'=>'必填项不能为空']);die;
//    }
//    //获取文章信息
//    $author=returnStr($_POST['author'],'m');
//    $title=returnStr($_POST['title'],'m');
//    $cid=returnStr($_POST['cid'],'m');
//    $keywords=returnStr($_POST['keywords'],'m');
//    $description=returnStr($_POST['description'],'m');
//    $content=returnStr($_POST['content'],'m');
//    $articleId=returnStr($_POST['id'],'m');
//
//    //判断图片存在
//    if( !$_FILES['thumb']['name']=="" ){//已修改封面图片
//        if(! isImgArticle($_FILES['thumb']) ){
//            echo json_encode(['statu'=>0,'message'=>'图片上传格式错误，仅支持jpg/png']);die;
//        }
//        //图片处理----得到图片的存储全路径
//        $imgPath=returnStr( headleImgArticle($_FILES['thumb']),'m' );
//        $sql=<<<EDIT
//        update articles set author_name='{$author}',title='{$title}',belongto_column='{$cid}',keywords='{$keywords}',
//        description='{$description}',content='{$content}',amend_time={$time},up_user='{$dl_name}',img_path='{$imgPath}'
//        where article_id = '{$articleId}'
//EDIT;
//     }else{//未修改封面图片
//        $sql=<<<DE
//        update articles set author_name='{$author}',title='{$title}',belongto_column='{$cid}',keywords='{$keywords}',
//        description='{$description}',content='{$content}',up_user='{$dl_name}'
//        where article_id = '{$articleId}'
//DE;
//    }
//    //获取保存的文章状态
//    $articleState='';
//    if($_GET['state']==0){
//        $articleState="保存草稿";
//        $state=2;
//        $container="state={$state},amend_time={$time},amend_content='{$articleState}'";
//    }else{
//        $articleState="修改文章";
//        $state=1;
//        $container="state={$state},amend_time={$time},amend_content='{$articleState}'";
//    }
//    if( !addDelAlt($sql) ){
//        echo json_encode(['statu'=>1,'message'=>$articleState."失败，你未修改"]);
//    }else {
//        $ope=$articleState."成功";
//        $putLogs=putLogs($dl_name,$login_id,$ope);
//        $upStateSql="update articles set $container where article_id={$articleId}";
//      // echo $putLogs;die;
//       //var_dump(addDelAlt($putLogs,$upStateSql)) ;die;
//        addDelAlt($putLogs,$upStateSql);
//        echo json_encode(['statu'=>2,'message'=>$articleState."成功"]);
//    }
//}
//
//            //排序操作
//else if( $_GET['ope']=="sorting" ){
//   // var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//    $method="";
//    if($_GET['method']=="time-asc")  $method="create_time asc";
//    else if($_GET['method']=="show-desc")  $method="state";
//    else if($_GET['method']=="time-desc") $method="create_time desc";
//    $sql="select *from articles order by  ".$method;
//    $res=mysqli_query($link,$sql);
//    $arr=mysqli_fetch_all($res,MYSQLI_ASSOC);
//   // var_dump($arr);die;
//    if(!$res ){
//        echo json_encode(['statu'=>0,'arr'=>"查询失败"]);die;
//    }else{
//        echo json_encode(['statu'=>1,'arr'=>$arr]);die;
//    }
//
//}
//                //搜索操作
//else if( $_GET['ope']=="search" ){
//   // var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//    $content=returnStr($_POST['content'],'m');
//    //var_dump($content);
//    $sql="select *from articles where `author_name` like '%{$content}%' or `keywords` like '%{$content}%' or `create_time` like '%{$content}%' ";
//   //echo $sql;die;
//    $res=mysqli_query($link,$sql);
//    $arr=mysqli_fetch_all($res,MYSQLI_ASSOC);
//    // var_dump($arr);die;
//    if(!$res || empty($arr)){
//        echo json_encode(['statu'=>0,'arr'=>"查询为空"]);
//    }else{
//        echo json_encode(['statu'=>1,'arr'=>$arr]);
//    }
//}
//
//
//
//
//
//
//
//
//
///*------------------------------------------发布文章模块*/
//else if($_GET['ope']=='publish'){
//   // var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//    //判断必填项不能为空---
//    if( isExistEmpty($_POST['author'],$_POST['title'],$_POST['cid']) ){
//        echo json_encode(['statu'=>0,'message'=>'必填项不能为空']);die;
//    }
//    //判断图片格式
//    if(! isImgArticle($_FILES['thumb']) ){
//        echo json_encode(['statu'=>0,'message'=>'图片上传格式错误，仅支持jpg/png']);die;
//    }
//    //获取文章信息
//    $author=returnStr( $_POST['author'],'m' );
//    $title=returnStr ($_POST['title'],'m' );
//    $cid=returnStr( $_POST['cid'],'m' );
//    $keywords=returnStr( $_POST['keywords'],'m' );
//    $description=returnStr( $_POST['description'],'m' );
//    $content=returnStr( $_POST['content'],'m' );
//    //图片处理----得到图片的存储全路径
//    $imgPath=returnStr( headleImgArticle($_FILES['thumb']),'m' );
//    //获取文章状态
//    if($_GET['state']==0){
//        $articleState="保存草稿";
//        $state=2;
//    }else{
//        $articleState="发布文章";
//        $state=1;
//    }
//    $mark=mt_rand(0,999);//给文章临时标志
//    $sql=<<<ADD
//    insert into articles (author_name,title,belongto_column,keywords,description,
//    content,create_time,up_user,temp_mark,img_path)
//    values('{$author}','{$title}','{$cid}','{$keywords}','{$description}','{$content}',{$time},'{$dl_name}',{$mark},'{$imgPath}' )
//ADD;
//    if( !addDelAlt($sql) ){
//        echo json_encode(['statu'=>1,'message'=>$articleState."失败"]);
//    }else {
//        $ope=$articleState."成功";
//        $putLogs=putLogs($dl_name,$login_id,$ope);
//        $upStateSql="update articles set state={$state} where temp_mark={$mark}";
//        addDelAlt($putLogs,$upStateSql);
//
//        echo json_encode(['statu'=>2,'message'=>$articleState."成功"]);
//    }
//}
//
//
//
//
///*-----------------------------------------回收站模块*/
////还原文章
//else if( $_GET['ope']=='recycArticle' ){
//   // var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//    $mark=$_POST['mark'];
//    $str="update articles set state=2 where article_id={$mark}";
//    if( !addDelAlt($str) ){
//        echo json_encode(['statu'=>0,'message'=>'null']);//还原失败---数据库操作
//    }else{
//        $ope="还原文章成功";
//        $putLogs=putLogs($dl_name,$login_id,$ope);
//        $upTimeSql="update articles set amend_time='{$time}' where article_id='{$mark}'";
//        addDelAlt($putLogs,$upTimeSql);
//
//        echo json_encode(['statu'=>1]);//还原成功---
//    }
//}
////改变回收站内容
//else if( $_GET['ope']=='changeRecycCont' ){
//    echo json_encode(['statu'=>$_POST['mark']]);
//}
////还原用户
//else if( $_GET['ope']=='recycUser' ){
//    //var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//    //修改用户状态------数据库
//    $recId=returnStr($_GET['id'],'m');
//    $str="update user set state=1 where id={$recId}";
//    if( !addDelAlt($str) ){
//        echo json_encode(['statu'=>0,'message'=>'null']);//还原失败---数据库操作
//    }else{
//        $ope="还原用户成功";
//        $putLogs=putLogs($dl_name,$login_id,$ope);
//        $upTimeSql="update user set amend_time='{$time}' where id='{$recId}'";
//        addDelAlt($putLogs,$upTimeSql);
//
//        echo json_encode(['statu'=>1]);//还原成功---
//    }
//}
//
//
//
//
/////*----------------------------------------------修改用户模块
//
//
//
//
//    //获取图片信息
//    //         $imgName=$_FILES['thumb']['name'];
//    //         $imgType =$_FILES['thumb']['type'];
//    //         $imgSize=$_FILES['thumb']['size'];
//    //        $tempPath=$_FILES['thumb']['tmp_name'];
//    //        $picter=$_FILES['tx'];
//    //        $txCont=imagecreatefromstring(file_get_contents($picter['tmp_name']));
//    //        $txInfo=getimagesize($picter['tmp_name']);
//    //        $w=$txInfo[0];
//    //        $h=$txInfo[1];
//    //        $img=imagecreatetruecolor(30,30);
//    //        imagecopyresampled($img,$txCont,0,0,0,0,30,30,$w,$h);
//    //        //图片储存路径
//    //        $dir='../../images';
//    //        if(!file_exists($dir)){
//    //            mkdir($dir);
//    //        }
//    //        $imgPath=$dir.'/'.$_POST['userName'].'.jpg';
//    //        imagejpeg($img,$imgPath);
//    //        //存到数据库的路径-------主页显示的路径
//    //        $showPath='images/'.$_POST['userName'].'.jpg';
//
//
//
//    /*
//     article_id   author_name keywords title  description  belongto_column
//    img_path content  create_time  num  amend_time amend_content state up_user temp_mark
//
//    array (size=1)
//      'thumb' =>
//        array (size=5)
//          'name' => string '1.jpg' (length=5)
//          'type' => string 'image/jpeg' (length=10)
//          'tmp_name' => string 'D:\wamp\tmp\phpE9BC.tmp' (length=23)
//          'error' => int 0
//          'size' => int 826052
//     */