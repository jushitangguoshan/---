<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/22 0022
     * Time: 下午 9:46
     */
    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志
    if( !isset($_GET['ope']) )die;

//    if( !isAjax() ){
//        header("location:../../resource/error_show.html");
//    }

    session_start();
  //  var_dump($_SESSION,$_POST,$_GET);die;
switch( $_GET['ope'] ){
    case 'init':
        echo init();
        break;
    case 'amend':
        echo json_encode( amend() );
        break;
}
/*-----------------修改用户信息-----------------------------*/
function amend(){
   // var_dump($_POST,$_GET,$_FILES);die;
    global $time;
    $dl_id=$_SESSION['dl_id'];
    $dl_user=returnStr( $_POST['username'],'m' );
    $phone=returnStr( $_POST['phone'],'m' );
    $pwd=$_POST['password'];
    $email=returnStr($_POST['email'],'m');
    if( isNull([$dl_id,$phone,$pwd,$email]) ){
        return ['statu'=>0,'message'=>"所有项不能为空"];die;
    }

    $sql="select pwd from user where id='{$dl_id}'";
    $res=getMysqlArr($sql);
    if( !$res[0]['pwd']==$pwd){//比较密码是否改变
        $pwd=md5($pwd);
    }
    //更新数据库
    $opeCont="修改个人信息";
    $sql="update user set phone='{$phone}',pwd='{$pwd}',email='{$email}' where id='{$dl_id}'";
    $logSql=putLogs($dl_user,$dl_id,$opeCont);
    $sqlTwo="update user set amend_time='{$time}', amend_user='{$dl_user}', ope_content='{$opeCont}' where id='{$dl_id}'";
    $res=addDelAlt($sql,$logSql,$sqlTwo);
    if( !$res ){
        return ['statu'=>0,'message'=>"更改失败"];
    }
    return ['statu'=>1,'message'=>"更改成功"];
}
/*---------------获取用户信息--------------------------*/
function init(){
    $dl_id=$_SESSION['dl_id'];
   // var_dump($_SESSION,$_POST,$_GET);die;
    $sql="select `name`,phone,pwd,state,email,roots from user where id={$dl_id}";
  //  echo $sql;
    $arr=getMysqlArr($sql);
   // var_dump($arr);die;
    $arr[0]['state']=queryUserState( $arr[0]['state'] );
    $arr[0]['roots']=queryUserRoot( $arr[0]['state'] );
    echo json_encode(['arr'=>$arr]);
}
/*-----------------判断是否提交空值----------------------*/
function isNull($arr){
    foreach( $arr as $value ){
        if($value==''){
            return true;
        }
    }
    return false;
}











//    $sql="select * from user where name= '{$_SESSION[username]}'";
//    $res=mysqli_query($link,$sql);
//    $arr=mysqli_fetch_all($res,MYSQLI_ASSOC);
//    // var_dump($arr);
//    $html="用户名：<input type='text' name='name' value={$arr[0][name]}> <br>
//                      电话：<input type='text' name='phone' value={$arr[0][phone]}>  <br>
//                     邮箱：<input type='text' name='email' value={$arr[0][email]}> <br>
//                     权限：<input type='text' name='roots' value={$arr[0][roots]}> <br>
//                     注册时间：<input type='text' name='create_time' value={$arr[0][create_time]}> <br>
//                     登录时间：<input type='text' name='login_time' value={$arr[0][login_time]}>
//                   ";
//    echo $html;