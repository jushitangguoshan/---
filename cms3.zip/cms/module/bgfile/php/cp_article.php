<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/21 0021
     * Time: 下午 8:41
     */

//    getListName(getColumnTree($mrr));
    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志
    if( !isset($_GET['ope']) )die;
    //
//    if( !isAjax() ){
//        header("location:../../resource/error_show.html");
//    }
    $page=$_GET['page'];
    $limit=$_GET['limit'];
    $str=(($page-1)*10).",10";
    $sql="select *from `articles` where state<>-1";
    $arr=getMysqlArr($sql);



    switch( $_GET['ope'] ){
        case 'init':
            init_layui();
            break;
        case 'del_article':
            del_article_lay();
            //del_article();
            break;
         case 'img':
            echo json_encode(['code'=>0]);
            break;
        case 'screening':
         screening();
        break;
//        case 'sorting':
//            //sorting();
//            //break;
        case 'search':
                serch_lay();
                //search();
                break;
        case 'importCsvArticle':
           importCsvArticle();
            break;
//        case 'exportLogCsv':
//            //exportLogCsv();
//            break;
        case 'getCol':
            getColumn();
            break;
    }

    Function screening(){
        global $str;
        //var_dump($_POST,$_GET);die;
        $colId=$_GET['colID'];
        $sql="select *from articles where belongto_column= ";
        if($colId==""){
            $sql="select *from articles where state<>-1 ";
        }else{
            $sql .=$colId;
        }
        $arr1=getMysqlArr($sql);
        $sql=$sql." limit ".$str;
        $arr=getMysqlArr($sql);
        $arr=returnNewArr($arr);
        echo json_encode(['code'=>0,'count'=>count($arr1),'statu'=>1,'data'=>$arr]);
    }
    function serch_lay(){
        global $str;
        global $arr;
       // var_dump($_POST,$_GET);die;
        $content=returnStr($_GET['content'],'m');
        //var_dump($content);
        $sql="select *from articles where `author_name` like '%{$content}%' or `keywords` like '%{$content}%' or `create_time` like '%{$content}%' limit ".$str;
        //echo $sql;die;
        $arr1=getMysqlArr($sql);
         //var_dump($arr);die;
        if( empty($arr1) ){
            echo json_encode(['code'=>0,'message'=>"查询为空"]);die;
        }
        echo json_encode(['code'=>0,'count'=>count($arr1),'data'=>$arr1]);
    }
    function init_layui(){
        global $str;
        global $arr;
        $sql="select *from `articles` where state<>-1 limit ".$str;

        $arrC=getMysqlArr($sql);
        $arrC=returnNewArr($arrC);
        echo json_encode( ['data'=>$arrC,'code'=>0,'count'=>count($arr)]);die;//文章总数
    }
    function del_article_lay(){
        global $dl_name;
        global $login_id;
        global $time;
      //  var_dump($_POST,$_GET);die;
        $id=$_POST['id'];
        $sql="update articles set state=-1 where article_id={$id}";
        //echo $sql;die;
        if( !addDelAlt($sql) ){
            echo json_encode(['statu'=>0,'message'=>"删除失败"]);die;
        }
        $ope="删除文章成功";

        $putLogs=putLogs($dl_name,$login_id,$ope);
        $upStateSql="update articles set amend_time='{$time}',amend_content='{$ope}' where article_id={$id}";
        addDelAlt($putLogs,$upStateSql);
//        $arr=getMysqlArr("select *from articles where state <> -1 limit ".$str);
//        echo json_encode(['statu'=>1,'message'=>"删除成功"]);

    }
    //转换栏目
    function returnNewArr($arr){
        $sql="select *from `column` where state=1";
        $arrCol=getMysqlArr($sql);
        foreach($arr as $k=>$value){
            foreach($arrCol as $i=>$val ){
                if($value['belongto_column']==$val['id']){
                    $arr[$k]['belongto_column']=&$val['name'];
                }
            }
        }
        return $arr;
    }
    //编辑
    function edit_article_lay(){
        global $dl_name;
        global $login_id;
        global $time;
        //var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
        if( isExistEmpty($_POST['author'],$_POST['title'],$_POST['cid']) ){
            echo json_encode(['statu'=>0,'message'=>'必填项不能为空']);die;
        }
        //获取文章信息
        $author=returnStr($_POST['author'],'m');
        $title=returnStr($_POST['title'],'m');
        $cid=returnStr($_POST['cidList'],'m');
        $keywords=returnStr($_POST['keywords'],'m');
        $description=returnStr($_POST['description'],'m');
        $content=returnStr($_POST['content'],'m');
        $articleId=returnStr($_POST['id'],'m');

        //判断图片存在
        if( !$_FILES['thumb']['name']=="" ){//已修改封面图片
            if(! isImgArticle($_FILES['thumb']) ){
                echo json_encode(['statu'=>0,'message'=>'图片上传格式错误，仅支持jpg/png']);die;
            }
            //图片处理----得到图片的存储全路径
            $imgPath=returnStr( headleImgArticle($_FILES['thumb']),'m' );
            $sql=<<<EDIT
        update articles set author_name='{$author}',title='{$title}',belongto_column='{$cid}',keywords='{$keywords}',
        description='{$description}',content='{$content}',amend_time={$time},up_user='{$dl_name}',img_path='{$imgPath}' 
        where article_id = '{$articleId}'
EDIT;
        }else{//未修改封面图片
            $sql=<<<DE
        update articles set author_name='{$author}',title='{$title}',belongto_column='{$cid}',keywords='{$keywords}',
        description='{$description}',content='{$content}',up_user='{$dl_name}'
        where article_id = '{$articleId}'
DE;
        }
        // echo $sql;die;
        //获取保存的文章状态
        $articleState='';
        if($_GET['state']==0){
            $articleState="保存草稿";
            $state=2;
            $container="state={$state},amend_time={$time},amend_content='{$articleState}'";
        }else{
            $articleState="修改文章";
            $state=1;
            $container="state={$state},amend_time={$time},amend_content='{$articleState}'";
        }
        echo $sql;die;
        if( !addDelAlt($sql) ){
            echo json_encode(['statu'=>0,'message'=>$articleState."失败，你未修改"]);die;
        }
        $ope=$articleState."成功";
        $putLogs=putLogs($dl_name,$login_id,$ope);
        $upStateSql="update articles set $container where article_id={$articleId}";
       //  echo $putLogs;die;
        var_dump(addDelAlt($putLogs,$upStateSql)) ;//die;
        addDelAlt($putLogs,$upStateSql);
        echo json_encode(['statu'=>1,'message'=>$articleState."成功"]);
    }
/*
    switch( $_GET['ope'] ){
        case 'init':
            init();
            break;
        case 'del_article':
            del_article();
            break;
        case 'screening':
            screening();
            break;
        case 'sorting':
            sorting();
            break;
        case 'search':
            search();
            break;
        case 'importCsvArticle':
            importCsvArticle();
            break;
        case 'exportLogCsv':
            exportLogCsv();
            break;
    }
*/
    function getColumn(){
        $colSql2="select *from `column` where state=1";
        $arr2=getColumnTree(getMysqlArr($colSql2));
        $colSql1="select *from `column`";
        $arr1=getMysqlArr($colSql1);
        echo json_encode( ['colArr2'=>$arr2,'colArr1'=>$arr1]);die;//文章总
    }

    //if( $_GET['ope']=='init' ){//------初始化
    function init(){
        $sql="select *from `articles` where state<>-1";
        $arr=getMysqlArr($sql);
        $colSql2="select *from `column` where state=1";
        $arr2=getColumnTree(getMysqlArr($colSql2));
        $colSql1="select *from `column`";
        $arr1=getMysqlArr($colSql1);
        $arr=returnNewArr($arr);
        //var_dump($arr,$arr2,$arr1);die;
        echo json_encode( ['arr'=>$arr,'colArr2'=>$arr2,'colArr1'=>$arr1]);die;//文章总数
    }
    //else if( $_GET['ope']=='del_article' ){//-------删除
//    function del_article(){
//        global $dl_name;
//        global $login_id;
//        global $time;
//        //var_dump($_POST,$_GET);die;
//        $id=returnStr($_POST['id'],'m');
//        $sql="update articles set state=-1 where article_id={$id}";
//        if( !addDelAlt($sql) ){
//            echo json_encode(['statu'=>0,'message'=>"删除失败"]);die;
//        }
//        $ope="删除文章成功";
//        $putLogs=putLogs($dl_name,$login_id,$ope);
//        $upStateSql="update articles set amend_time='{$time}',amend_content='{$ope}' where article_id={$id}";
//        addDelAlt($putLogs,$upStateSql);
//        $arr=getMysqlArr("select *from articles where state <> -1");
//        echo json_encode(['statu'=>1,'arr'=>$arr]);
//
//    }
//   // else if( $_GET['ope']=='screening' ){//-------筛选
//    function screening(){
//        //var_dump($_POST,$_GET);die;
//        $colId=$_POST['colId'];
//        $sql="select *from articles where belongto_column= ";
//        if($colId==""){
//            $sql="select *from articles where state<>-1 ";
//        }else{
//            $sql .=$colId;
//        }
//        $arr=getMysqlArr($sql);
//        $colSql="select *from `column` where state=1";
//        echo json_encode(['statu'=>1,'arr'=>$arr,'colArr'=>getMysqlArr($colSql)]);
//    }
//    function sorting(){//-----------排序
//        // else if( $_GET['ope']=='sorting' ){
//        global $link;
//        //var_dump($_POST,$_GET);die;
//        if($_POST['method']=="time-asc")  $method="create_time desc";
//        else if($_POST['method']=="show-desc")  $method="state";
//        else if($_POST['method']=="time-desc") $method="create_time asc";
//        $sql="select *from articles where state<>-1 order by  ".$method;
//        $res=mysqli_query($link,$sql);
//        $arr=mysqli_fetch_all($res,MYSQLI_ASSOC);
//        // var_dump($arr);die;
//        if(!$res ){
//            echo json_encode(['statu'=>0,'arr'=>"查询失败"]);die;
//        }
//        echo json_encode(['statu'=>1,'arr'=>$arr]);die;
//    }
//    function search(){//-------------搜索
//        // else if( $_GET['ope']=="search" ){
//       // var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//        $content=returnStr($_POST['content'],'m');
//        //var_dump($content);
//        $sql="select *from articles where `author_name` like '%{$content}%' or `keywords` like '%{$content}%' or `create_time` like '%{$content}%' ";
//        //echo $sql;die;
//        $arr=getMysqlArr($sql);
//         //var_dump($arr);die;
//        if( empty($arr) ){
//            echo json_encode(['statu'=>0,'message'=>"查询为空"]);die;
//        }
//        echo json_encode(['statu'=>1,'arr'=>$arr]);
//    }
    function importCsvArticle(){//CSV批量导入
       /// var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
        //else if( $_GET['ope']=='importCsvArticle' ){
        global $link;
        global $data_values;
        $filename = $_FILES['file']['tmp_name'];
        if (empty ($filename)) {
            echo json_encode(['statu'=>0,'message'=>'请选择要导入的CSV文件！']);
            exit;
        }
        $handle = fopen($filename, 'r');
        $result = input_csv($handle); //解析csv
        $len_result = count($result);
        if($len_result==0){
            echo json_encode(['statu'=>0,'message'=>'没有任何数据！']); exit;
        }
        //循环获取各字段值
        for ($i = 0; $i < $len_result; $i++) {
            $author_name = iconv('gb2312', 'utf-8', $result[$i][0]); //中文转码
            $title = iconv('gb2312', 'utf-8', $result[$i][1]);
            $description = iconv('gb2312', 'utf-8', $result[$i][2]);
            $data_values .= "('$author_name','$title','$description'),";
        }
        $data_values = substr($data_values,0,-1); //去掉最后一个逗号
        fclose($handle); //关闭指针
        $query = mysqli_query($link,"insert into articles (author_name,title,description) values $data_values");//批量插入数据表中
        if($query){
            echo json_encode(['statu'=>1,'message'=>'导入成功！']);die;
        }
        echo json_encode(['statu'=>0,'message'=>'导入失败！']);
    }
//    function exportLogCsv(){//导出csv错误日志
//        //else if($_GET['ope']=="exportLogCsv"){
//        global $link;
//        //var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//        $result = mysqli_query($link,"select * from logs order by id asc");
//        $str = "信息,时间,当前登录用户,操作内容,本地ip\n";
//        $str = iconv('utf-8','gb2312',$str);
//        while($row=mysqli_fetch_array($result)){
//            $message = iconv('utf-8','gb2312',$row['message']); //中文转码
//            $opeTime = iconv('utf-8','gb2312',$row['time']);
//            $user_id = iconv('utf-8','gb2312',$row['user_id']);
//            $opeteat = iconv('utf-8','gb2312',$row['opeteat']);
//            $opeIp = iconv('utf-8','gb2312',$row['ip']);
//            $str .= $message.",".$opeTime.",".$user_id.",".$opeteat.",".$opeIp."\n"; //用引文逗号分开
//        }
//        $filename = date('Ymd').'.csv'; //设置文件名
//        export_csv($filename,$str); //导出
//    }




//
//         date_default_timezone_set('PRC');
//
//         session_start();
//
//         //获取所有文章数组(未发布+发布)
//         $sql="select *from `articles` ";
//         $articleSum=count(getMysqlArr($sql));//文章总数
//         $showListNum=5;//每页显示文章个数
//         $arr=showList(articles,$showListNum); //showList(表名,显示个数)
//         //获取所有没有删除的栏目数组栏目数组
//         $sql="select *from `column` where state=1";
//         $mrr=getMysqlArr($sql);
//          //var_dump(getColumnTree($mrr));
//         $mjarr=json_encode($mrr);//json化数组，














//
//
//                                  foreach ($arr as $value){
//                                        if($value['state']==1) $state="已发布";
//                                        else  if($value['state']==-1) $state="已删除";
//                                        else  $state="未发布";}

//                              <tr>
////							<td class="s-show"><i class="icon-yes"><?=$state<!--</i></td>-->
//<!--							<td class="s-title"><a href="../show.php" target="_blank">//=$value['title']<!--</a></td>-->
//<!--							<td><a href="#">-->//=getArticBelongName($mrr,$value['belongto_column'])<!--</a></td>-->
//<!--							<td>--><?//=$value['author_name']<!--</td>-->
//<!--							<td>--><?//=date("Y/m/d H:i:s",$value['create_time'])<!--</td>-->
//<!--							<td class="s-act">-->
//<!--                                        <a href="#" class="alt_article">编辑</a>-->
//<!--                                      -->
//<!--                                      -->
//<!--                                        if($_SESSION['root']>100) { -->
//<!--                                        <a href="#" class="jq-del">删除</a>-->
//<!--                                    }-->
