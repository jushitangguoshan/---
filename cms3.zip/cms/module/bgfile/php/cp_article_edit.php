<?php
    /*------------------------------------------发布文章模块*/
    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志
    if( !isset($_GET['ope']) )die;

//    if( !isAjax() ){
//        header("location:../../resource/error_show.html");
//    }

    switch( $_GET['ope'] ){
        case 'img':
            echo json_encode(['code'=>0,'message'=>'ok']);
            break;
        case 'init':
            $sql="select *from `column` where state=1";
            $mrr=getColumnTree( getMysqlArr($sql) );
            echo json_encode(['arr'=>$mrr]);
            break;
        case 'publish':
            //var_dump($_POST,$_GET,$_FILES);die;
            //判断必填项不能为空---
            if( isExistEmpty($_POST['author'],$_POST['title'],$_POST['cidList']) ){
                echo json_encode(['statu'=>0,'message'=>'必填项不能为空']);die;
            }

            if($_POST['mark']==""){ addFuc(); }
            else if(edit_article_lay() );
            break;
    }




function addFuc(){
    global $dl_name;
    global $login_id;
    global $time;
    //获取文章信息
    $author=returnStr( $_POST['author'],'m' );
    $title=returnStr ($_POST['title'],'m' );
    $cid=returnStr( $_POST['cidList'],'m' );
    $keywords=returnStr( $_POST['keywords'],'m' );
    $description=returnStr( $_POST['description'],'m' );
    $content=returnStr( $_POST['content'],'m' );
    //图片处理----得到图片的存储全路径
    $imgPath=returnStr( headleImgArticle($_FILES['thumb']),'m' );

    //获取文章状态
    if($_GET['state']==0){
        $articleState="保存草稿";
        $state=2;
    }else{
        $articleState="发布文章";
        $state=1;
    }
    /*---------------开启事务----------------*/
    $sql=<<<ADD
   insert into articles (author_name,title,belongto_column,keywords,description,content,create_time,up_user,img_path,state) 
    values('{$author}','{$title}','{$cid}','{$keywords}','{$description}','{$content}',{$time},'{$dl_name}','{$imgPath}','{$state}' )
ADD;
    //echo $sql;die;
    if( !addDelAlt($sql) ){
        echo json_encode(['statu'=>0,'message'=>$articleState."失败"]);
    }else {
        $ope=$articleState."成功";
        $putLogs=putLogs($dl_name,$login_id,$ope);
        addDelAlt($putLogs);
        echo json_encode(['statu'=>1,'message'=>$articleState."成功",'mark'=>'add']);
    }
}
    function edit_article_lay(){
        global $dl_name;
        global $login_id;
        global $time;
        //获取文章信息
        $author=returnStr($_POST['author'],'m');
        $title=returnStr($_POST['title'],'m');
        $cid=returnStr($_POST['cidList'],'m');
        $keywords=returnStr($_POST['keywords'],'m');
        $description=returnStr($_POST['description'],'m');
        $content=returnStr($_POST['content'],'m');
        $articleId=returnStr($_POST['id'],'m');
        //判断图片存在
        if( !$_FILES['thumb']['name']=="" ){//已修改封面图片
            if(! isImgArticle($_FILES['thumb']) ){
                echo json_encode(['statu'=>0,'message'=>'图片上传格式错误，仅支持jpg/png']);die;
            }
            //图片处理----得到图片的存储全路径
        $imgPath=returnStr( headleImgArticle($_FILES['thumb']),'m' );
        $sql=<<<EDIT
        update articles set author_name='{$author}',title='{$title}',belongto_column='{$cid}',keywords='{$keywords}',
        description='{$description}',content='{$content}',amend_time={$time},up_user='{$dl_name}',img_path='{$imgPath}' 
        where article_id = '{$articleId}'
EDIT;
        }else{//未修改封面图片
            $sql=<<<DE
        update articles set author_name='{$author}',title='{$title}',belongto_column='{$cid}',keywords='{$keywords}',
        description='{$description}',content='{$content}',up_user='{$dl_name}'
        where article_id = '{$articleId}'
DE;
        }
        // echo $sql;die;
        //获取保存的文章状态
        if($_GET['state']==0){
            $articleState="保存草稿";
            $state=2;
            $container="state={$state},amend_time={$time},amend_content='{$articleState}'";
        }else{
            $articleState="修改文章";
            $state=1;
            $container="state={$state},amend_time={$time},amend_content='{$articleState}'";
        }
        //echo $sql;die;
        if( !addDelAlt($sql) ){
            echo json_encode(['statu'=>0,'message'=>$articleState."失败，你未修改"]);die;
        }
        $ope=$articleState."成功";
        $putLogs=putLogs($dl_name,$login_id,$ope);
        $upStateSql="update articles set $container where article_id={$articleId}";
        // echo $putLogs;die;
        //var_dump(addDelAlt($putLogs,$upStateSql)) ;die;
        addDelAlt($putLogs,$upStateSql);
        echo json_encode(['statu'=>1,'message'=>$articleState."成功",'mark'=>'amend']);
    }











//    if($_GET['ope']=='img' ){
//        echo json_encode(['code'=>0,'message'=>'ok']);
//      //  var_dump($_POST,$_GET,$_FILES);die;
//    }
//    if( $_GET['ope']=='init' ){//初始化数据
//        $sql="select *from `column` where state=1";
//        $mrr=getColumnTree( getMysqlArr($sql) );
//        echo json_encode(['arr'=>$mrr]);
//    }else
//        if( $_GET['ope']=='publish' ){
//        var_dump($_POST,$_GET,$_FILES);die;
//        /*----------------数据判断-----------*/
//        //判断必填项不能为空---
//        if( isExistEmpty($_POST['author'],$_POST['title'],$_POST['cidList']) ){
//            echo json_encode(['statu'=>0,'message'=>'必填项不能为空']);die;
//        }
////        //判断图片格式
////        if(! isImgArticle($_FILES['thumb']) ){
////            echo json_encode(['statu'=>0,'message'=>'图片上传格式错误，仅支持jpg/png']);die;
////        }
//        //获取文章信息
//        $author=returnStr( $_POST['author'],'m' );
//        $title=returnStr ($_POST['title'],'m' );
//        $cid=returnStr( $_POST['cidList'],'m' );
//        $keywords=returnStr( $_POST['keywords'],'m' );
//        $description=returnStr( $_POST['description'],'m' );
//        $content=returnStr( $_POST['content'],'m' );
//        //图片处理----得到图片的存储全路径
//        //$imgPath=returnStr( headleImgArticle($_FILES['thumb']),'m' );
//        $imgPath="";
//        //获取文章状态
//        if($_GET['state']==0){
//            $articleState="保存草稿";
//            $state=2;
//        }else{
//            $articleState="发布文章";
//            $state=1;
//        }
//        /*---------------开启事务----------------*/
//        mysqli_query($link,"begin");
//        $sql=<<<ADD
//   insert into articles (author_name,title,belongto_column,keywords,description,
//    content,create_time,up_user,img_path,state)
//    values('{$author}','{$title}','{$cid}','{$keywords}','{$description}','{$content}',{$time},
//    '{$dl_name}','{$imgPath}','{$state}' )
//ADD;
//        //echo $sql;die;
//        if( !addDelAlt($sql) ){
//            mysqli_query($link,"collback");
//            echo json_encode(['statu'=>0,'message'=>$articleState."失败"]);
//        }else {
//            $ope=$articleState."成功";
//            $putLogs=putLogs($dl_name,$login_id,$ope);
//            addDelAlt($putLogs);
//            mysqli_query($link,"commit");
//            echo json_encode(['statu'=>1,'message'=>$articleState."成功"]);
//        }
//    }
//
