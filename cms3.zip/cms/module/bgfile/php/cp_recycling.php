<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/21 0021
     * Time: 上午 11:15
     */


    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志
    if( !isset($_GET['ope']) )die;

//    if( !isAjax() ){
//        header("location:../../resource/error_show.html");
//    }
  // var_dump($_POST,$_GET);die;

    $sql="select *from `column`"; //获取所有栏目数组
    $colArr=getMysqlArr($sql);
    $page=$_GET['page'];
    $limit=$_GET['limit'];
    $str=(($page-1)*10).",10";
    switch( $_GET['ope'] ){
        case 'article':
            $sql="select *from articles where state=-1";//获取已经被冻结的文章
            $arrA=getMysqlArr($sql);
            $sql="select *from `articles` where state=-1  limit ".$str;//获取所有文章数组(已删除)
           // echo $sql;die;
            $articleArr=getMysqlArr($sql);
            echo json_encode(['code'=>0,'msg'=>"文章",'count'=>count($arrA),'data'=>$articleArr]);
            break;
        case 'user':
            $sql="select *from user where state=-1";//获取已经被冻结的
            $arrU=getMysqlArr($sql);
            $sql="select *from user where state='-1' limit ".$str;
            $userArr=getMysqlArr($sql);
            echo json_encode(['code'=>0,'msg'=>"用户",'count'=>count($arrU),'data'=>$userArr]);
            break;
        case 'recycUser':
            //var_dump($_GET,$_POST);die;
            $recId=$_POST['id'];
            $ope="还原用户成功";
            $putLogs=putLogs($dl_name,$login_id,$ope);
            $upTimeSql="update `user` set state=1,amend_time='{$time}' where id='{$recId}'";
            addDelAlt($putLogs,$upTimeSql);
            echo json_encode(['statu'=>'成功']);
            break;
        case 'recycArticle':
            $mark=$_POST['id'];
            $ope="还原文章成功";
            $putLogs=putLogs($dl_name,$login_id,$ope);
            $upTimeSql="update articles set state=2,amend_time='{$time}' where article_id='{$mark}'";
            addDelAlt($putLogs,$upTimeSql);
            echo json_encode(['statu'=>'成功']);
            break;
    }

//        if( $_GET['ope']=='changeRecycCont' ){//----------改变内容
//        if( $_POST['mark']==1 ){
//            echo json_encode(['statu'=>1,'arr'=>$userArr]);
//        }else if( $_POST['mark']==2 ){
//            echo json_encode(['statu'=>2,'arr'=>$articleArr]);
//        }
//    }else if( $_GET['ope']=='recycUser' ){//--------------------还原用户
//        //var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
//        //修改用户状态------数据库
//        $recId=$_POST['id'];
//        $str="update user set state=1 where id={$recId}";
//        if( !addDelAlt($str) ){
//            echo json_encode(['statu'=>0,'message'=>'null']);//还原失败---数据库操作
//        }else{
//            $ope="还原用户成功";
//            $putLogs=putLogs($dl_name,$login_id,$ope);
//            $upTimeSql="update user set amend_time='{$time}' where id='{$recId}'";
//            addDelAlt($putLogs,$upTimeSql);
//            echo json_encode(['statu'=>1]);//还原成功---
//        }
//    }else if( $_GET['ope']=='recycArticle' ){//--------------------还原文章
//       // var_dump($_POST); var_dump($_GET); var_dump($_FILES);
//        $mark=$_POST['id'];
//        $str="update articles set state=2 where article_id={$mark}";
//        if( !addDelAlt($str) ){
//            echo json_encode(['statu'=>0,'message'=>'null']);//还原失败---数据库操作
//        }else{
//            $ope="还原文章成功";
//            $putLogs=putLogs($dl_name,$login_id,$ope);
//            $upTimeSql="update articles set amend_time='{$time}' where article_id='{$mark}'";
//            addDelAlt($putLogs,$upTimeSql);
//            echo json_encode(['statu'=>1]);//还原成功---
//        }
//    }


    /*   <?php
                                           foreach($userArr as $key => $value){
                                               if( $value['state']==1)continue;
                                               else $temp_s="冻结";
                                               if( $value['roots']==1)  $temp_r='普通用户';
                                               else if( $value['roots']>100) $temp_r='超级管理员';
                                               $html .=" <tr>
                                                            <td>$value[id]</td>
                                                            <td>$value[name]</td>
                                                            <td>$value[pwd]</td>
                                                            <td>$temp_s</td>
                                                            <td>$temp_r</td>

                                                            <td>".date('Y-m-d H:i:s',$value['login_time'])."</td>
                                                            <td>".date('Y-m-d H:i:s',$value['create_time'])."</td>
                                                            <td><button class='userBack'>还原</button></td>
                                                        </tr>
                                                  ";
                                           }
                                           echo $html;
                                       ?>*/













    /*
     *
     *   <?php
                                 foreach ($articleArr as $value){
                                     ?>
                                           <tr>
                                                  <td class='s-show'><i class='icon-yes'>已删除</i></td>
                                                  <td class='s-title'><a href='../show.php' target='_blank'><?=$value['title']?></a></td>
                                                  <td><a href=''><?=getArticBelongName($mrr,$value['belongto_column'])?></a></td>
                                                  <td><?=$value['author_name']?></td>
                                                  <td><?=date('Y-m-d H:i:s',$value['create_time'])?></td>
                                                  <td class='s-act'>
                                                      <a href='#' class='articleBack'>还原</a>
                                                  </td>
                                                  <td style='display:none '><?=$value['article_id']?></td>
                                             </tr>
                                 <?php }?>
     *
     * */