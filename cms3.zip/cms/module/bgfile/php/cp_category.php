<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/21 0021
     * Time: 下午 4:49
     */

    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志
//    if( !isAjax() ){
//        header("location:../../resource/error_show.html");
//    }


    if( !isset($_GET['ope']) )die;
       date_default_timezone_set('PRC');
       session_start();
       $sql="select *from `column` where state=1";
       $arr=getMysqlArr($sql);
      // var_dump(getColumnTree($arr));die;
       //var_dump($arr);

    if( $_GET['ope']=="init" ){
        echo json_encode(['arr'=>getColumnTree($arr)]);die;
    }else if( $_GET['ope']=="delCol" ){
        // var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
        $del_id=$_POST['delId'];
        $sql="update `column` set state=0 where id={$del_id}";
        if( addDelAlt($sql) ){//返回执行sql 语句结果
            $ope="删除栏目成功";
            $putLogs=putLogs($dl_name,$login_id,$ope);
            $upStateSql="update `column` set amen_time={$time} where id={$del_id}";
            addDelAlt($putLogs,$upStateSql);
            $arr=getMysqlArr("select *from `column` where state=1");
            echo json_encode(['statu'=>1,'arr'=>$arr,'message'=>$ope]);
        }else{
            echo json_encode(['statu'=>0,'message'=>"删除失败"]);
        }
    }else if( $_GET['ope']=='addCol' ){
        // var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
        $arr=$_POST['arr'];
        $leng=count($arr);                 //         .returnStr($value[2],'m').
        mysqli_query($link,"begin");
        $sql="insert into `column` (`name`,p_id,show_sort) values";
        foreach($arr as $key=>$value){
            if($key==$leng-1) {
                $sql.="('".returnStr($value[1],'m')."','".returnStr($value[2],'m')."','".returnStr($value[0],'m')."');";
            }else{
                $sql.="('".returnStr($value[1],'m')."','".returnStr($value[2],'m')."','".returnStr($value[0],'m')."'),";
            }
        }
        // echo $sql;die;
        if( !addDelAlt($sql) ){
            mysqli_query($link,"collback");
            echo json_encode(['statu'=>0,'message'=>"增加失败"]);
        }else{
            $ope="增加栏目成功";
            $putLogs=putLogs($dl_name,$login_id,$ope);
            addDelAlt($putLogs);
            mysqli_query($link,"commit");
            echo json_encode(['statu'=>1,'message'=>$ope]);
        }
    }









//echo getList(getColumnTree($arr));


















