<?php
    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志
    if( !isset($_GET['ope']) )die;

//    if( !isAjax() ){
//        header("location:../../resource/error_show.html");
//    }

    $sql="select *from `column` where p_id=0";
    $p_list=getMysqlArr($sql);  //所有父级栏目
    if( $_GET['ope']=='init' ){//初始化
        $getId=$_POST['colId'];
        $sql= "select * from `column` where id={$getId}";
        $arr=getMysqlArr($sql);//当前编辑的栏目
        echo json_encode(['arr'=>$arr,'colArr'=>$p_list]);die;
    }else if(  $_GET['ope']=='editCol' ){//提交更改内容
        //var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
        $altId=$_COOKIE['editColId'];//查询条件
        $colName=returnStr($_POST['name'],'m');
        $colPId=returnStr($_POST['pid'],'m');
        $show_srot=returnStr($_POST['sort'],'m');
        $sql="update `column` set `name`='{$colName}',show_sort={$show_srot},p_id={$colPId} where id={$altId}";
        // echo $sql;die;
        if( addDelAlt($sql) ){//返回执行sql 语句结果
            $ope="修改栏目成功";
            $putLogs=putLogs($dl_name,$login_id,$ope);
            $upStateSql="update `column` set amen_time={$time} where id={$altId}";
            addDelAlt($putLogs,$upStateSql);
            echo json_encode(['statu'=>1,'arr'=>$arr,'message'=>$ope]);
        }else{
            echo json_encode(['statu'=>0,'message'=>"修改栏目失败"]);
        }

    }


