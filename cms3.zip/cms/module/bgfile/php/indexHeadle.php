<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/23 0023
     * Time: 上午 11:38
     */
    session_start();
    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志

    //var_dump($_SESSION);die;
//    if( !isAjax() ){
//        header("location:../../resource/error_show.html");
//    }


    if( $_SESSION['mark'] !== "isLogin" ){
        header("location:http://www.xxx.com/cms/module/login/login.html");die;
    }
    if( !isset($_GET['ope']) )die;
    switch( $_GET['ope'] ){
        case "init":
            echo json_encode( init() );
            break;
        case 'exitLogin':
            echo  json_encode(  exitLogin()  );
            break;
        case 'isLogin':
            echo  json_encode(  isLogin()  );
            break;
    }
    /*---------------判断是否登录-------------*/
    function isLogin(){
        if ( $_SESSION['mark']==='' ){
            return ['state'=>1];
        }
        return ['state'=>0];
    }
    /*------------------退出---------------------*/
    function exitLogin(){
       $_SESSION['mark']='';
       return ['state'=>1];
    }
    /*-------------------------初始化------------*/
    function init(){
        $dl_user=$_SESSION['username'];
        $root=$_SESSION['root'];
        return ['user'=>$dl_user,'root'=>getRoots($root)];
    }

    /*-------------------------得到权限string------------*/
    function getRoots($temp){
        if( $temp<100 ){
            return "普通用户";
        }else if( $temp>100 ){
            return "超级管理员";
        }
    }