<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/21 0021
     * Time: 下午 3:15
     */
    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志
    if( !isset($_GET['ope']) )die;
//
//    if( !isAjax() ){
//        header("location:../../resource/error_show.html");
//    }

    if( $_GET['ope']=='getCount'){
       // var_dump($_POST,$_GET);die;
        $sql="select * from user where state <> '-1'";
        $arr=getMysqlArr($sql);
        $sum=count($arr);
        $page=$_GET['page'];
        $limit=$_GET['limit'];
        $str=(($page-1)*10).",10";
        $sql="select *from user where state <> '-1' limit ".$str;
        $arr=getMysqlArr($sql);
        echo json_encode(['data'=>$arr,'code'=>0,'count'=>$sum,'msg'=>'']);
    }
    else if( $_GET['ope']=='amend' ){//----------------修改用户模块
        //var_dump($_POST,$_GET);die;
        //判断是否存在空值
        if( isExistEmpty($_POST['name'],$_POST['phone'],$_POST['pwd'],$_POST['state'],$_POST['root'],$_POST['email'],$_POST['id'] )){
            echo json_encode(['statu' => 0,'message'=>"所有项不能为空"]);
            die;
        }
        //  var_dump($_GET['name']);
        //向数据库插入值
        $altName=returnStr($_POST['name'],'m');
        $altState=returnStr($_POST['state'],'m');
        $altRoot=returnStr($_POST['root'],'m');
        $altPhone=returnStr($_POST['phone'],'m');
        $altEmail=returnStr($_POST['email'],'m');
        $altUserId=returnStr($_POST['id'],'m');
        $sql="select pwd from user where id='{$altUserId}'";
        $oldPwd=getMysqlArr($sql)[0]['pwd'];//获取旧密码
        if( md5($_POST['pwd']+123)===$oldPwd ){//密码未改变
            $str="`name`='{$altName}',state='{$altState}',roots='{$altRoot}',phone='{$altPhone}',email='{$altEmail}'";
        }else{
            $pwd=md5($_POST['pwd']+123);
            $str="`name`='{$altName}',pwd='{$pwd}',state='{$altState}',roots='{$altRoot}',phone='{$altPhone}',email='{$altEmail}'";
        }
        $altSql="update user set $str where id='{$altUserId}'";
        if( !addDelAlt($altSql) ){//判断修改是否成功--值是否有改变
            echo json_encode(['statu'=>0,'message'=>"修改失败,你未更改内容"]);//修改失败---sql添加过程出错
        }else{
            $ope="修改用户成功";
            $putLogSql=putLogs($dl_name,$login_id,$ope);
            $upTimeSql="update user set amend_time='{$time}' where id='{$altUserId}'";
            addDelAlt($putLogSql,$upTimeSql);
            echo json_encode(['statu'=>1,'message'=>"修改成功"]);//修改成功---
        }
    }
    else if( $_GET['ope']=='add' ) {//----------------增加用户模块
        //var_dump($_POST,$_GET);die;
        //判断是否存在空值
        if( isExistEmpty($_POST['name'],$_POST['phone'],$_POST['pwd'],$_POST['state'],$_POST['root'],$_POST['email'] )){
            echo json_encode(['statu' => 0,'message'=>"所有项不能为空"]);
            die;
        }
        //先判断用户名是否重复
        $addName = returnStr($_POST['name'], 'm');
        $arr = getMysqlArr("select count(*) as num from user where name='{$addName}'");
        if ($arr[0]['num'] > 0) {
            echo json_encode(['statu' =>0,'message'=>'用户名已存在']);//添加失败---用户名存在
        } else {
            $ope = "增加用户成功";
            $putLogSql = putLogs($dl_name, $login_id, $ope);
            //向数据库插入值
            $addPhone = returnStr($_POST['phone'], 'm');
            $addState = returnStr($_POST['state'], 'm');
            $addroot = returnStr($_POST['root'], 'm');
            $addEmail = returnStr($_POST['email'], 'm');
            $pwd = md5($_POST['pwd']);
            $str = "'{$addName}','{$addPhone}','{$pwd}','{$addState}','{$addroot}','{$addEmail}','{$time}'";
            $updateSql = "insert into user(`name`,phone,pwd,state,roots,email,create_time) values($str)";
            addDelAlt($putLogSql, $updateSql);//记录日志事务
            echo json_encode(['statu' => 1,'message'=>"添加成功"]);//添加成功---

        }

    }

























//
//
//
//
//    foreach($userArr as $key => $value){
//                                     if( $value['state']==1) $temp_s='正常';
//                                     else if( $value['state']==-1) $temp_s='冻结';
//                                     if( $value['roots']==1)  $temp_r='普通用户';
//                                     else if( $value['roots']>100) $temp_r='超级管理员';
//                                     $html .=" <tr>
//                                                  <td>$value[id]</td>
//                                                  <td>$value[name]</td>
//                                                  <td>$value[pwd]</td>
//                                                  <td>$value[phone]</td>
//                                                  <td>$temp_s</td>
//                                                  <td>$temp_r</td>
//                                                  <td>".date('Y-m-d H:i:s',$value['login_time'])."</td>
//                                                  <td>".date('Y-m-d H:i:s',$value['create_time'])."</td>
//                                                 <td>
//                                                       <button class='manageAdd'>增加</button>
//                                                       <button class='manageAmend'>修改</button>
//                                                  </td>
//                                              </tr>
//                                        ";
//                                 }
//                                 echo $html;
//
//
//
//                        //showPage(总数，每页显示列表个数,显示的页码个数)
//                        showPage($userSum,$showListNum,3);
//
