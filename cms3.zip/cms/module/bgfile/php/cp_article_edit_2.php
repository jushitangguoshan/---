<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/22 0022
     * Time: 下午 7:21
     */
    include_once "../../resource/mysql_connect.php";
    include_once "../../resource/function.php";//引入函数--存日志
    if( !isset($_GET['ope']) )die;

//    if( !isAjax() ){
//        header("location:../../resource/error_show.html");
//    }

  //  var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
    date_default_timezone_set('PRC');
    if( $_GET['ope']=='init' ){//----------------------编辑内容初始化
        $id=$_POST['id'];
        $sql="select *from articles where article_id={$id}";
        $arr=getMysqlArr($sql);
        ///var_dump($arr);die;
        $sql="select *from `column` where state=1";
        $mrr=getColumnTree( getMysqlArr($sql) );
        echo json_encode(['arr'=>$arr,'colArr'=>$mrr]);
    }else if( $_GET['ope']=='edit_2'){//----------------------保存编辑
       // var_dump($_POST); var_dump($_GET); var_dump($_FILES);die;
        if( isExistEmpty($_POST['author'],$_POST['title'],$_POST['cid']) ){
            echo json_encode(['statu'=>0,'message'=>'必填项不能为空']);die;
        }
        //获取文章信息
        $author=returnStr($_POST['author'],'m');
        $title=returnStr($_POST['title'],'m');
        $cid=returnStr($_POST['cid'],'m');
        $keywords=returnStr($_POST['keywords'],'m');
        $description=returnStr($_POST['description'],'m');
        $content=returnStr($_POST['content'],'m');
        $articleId=returnStr($_POST['id'],'m');

        //判断图片存在
        if( !$_FILES['thumb']['name']=="" ){//已修改封面图片
            if(! isImgArticle($_FILES['thumb']) ){
                echo json_encode(['statu'=>0,'message'=>'图片上传格式错误，仅支持jpg/png']);die;
            }
            //图片处理----得到图片的存储全路径
            $imgPath=returnStr( headleImgArticle($_FILES['thumb']),'m' );
            $sql=<<<EDIT
        update articles set author_name='{$author}',title='{$title}',belongto_column='{$cid}',keywords='{$keywords}',
        description='{$description}',content='{$content}',amend_time={$time},up_user='{$dl_name}',img_path='{$imgPath}' 
        where article_id = '{$articleId}'
EDIT;
        }else{//未修改封面图片
            $sql=<<<DE
        update articles set author_name='{$author}',title='{$title}',belongto_column='{$cid}',keywords='{$keywords}',
        description='{$description}',content='{$content}',up_user='{$dl_name}'
        where article_id = '{$articleId}'
DE;
        }
       // echo $sql;die;
        //获取保存的文章状态
        $articleState='';
        if($_GET['state']==0){
            $articleState="保存草稿";
            $state=2;
            $container="state={$state},amend_time={$time},amend_content='{$articleState}'";
        }else{
            $articleState="修改文章";
            $state=1;
            $container="state={$state},amend_time={$time},amend_content='{$articleState}'";
        }
        if( !addDelAlt($sql) ){
            echo json_encode(['statu'=>0,'message'=>$articleState."失败，你未修改"]);die;
        }
        $ope=$articleState."成功";
        $putLogs=putLogs($dl_name,$login_id,$ope);
        $upStateSql="update articles set $container where article_id={$articleId}";
        // echo $putLogs;die;
        //var_dump(addDelAlt($putLogs,$upStateSql)) ;die;
        addDelAlt($putLogs,$upStateSql);
        echo json_encode(['statu'=>1,'message'=>$articleState."成功"]);
    }

