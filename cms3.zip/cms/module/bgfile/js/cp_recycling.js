$(function(){
    cpBackUser();//初始化+还原用户
    cpArticleUser();//初始化+还原文章
});
//还原已删除文章
function cpArticleUser(){
    layui.use('table', function(){
        var table = layui.table;
        table.render({
            elem: '#articleTable',
            url:'../php/cp_recycling.php?ope=article',
            toolbar: '#toolbarDemo',
            title: '用户数据表',
            totalRow: true,
            cols: [[
                {field:'article_id', title:'文章ID', width:80, fixed: 'left', unresize: true, sort: true},
                {field:'author_name', title:'作者名字', width:120, edit: 'text'},
                {field:'title', title:'标题', width:150,align:"center", sort: false,edit: 'text'},
                {field:'belongto_column', title:'所属栏目id', width:120, edit: 'text'},
                {field:'click_num', title:'浏览次数', width:120},
                {field:'create_time', title:'创建时间', width:120,templet:"<div>{{layui.util.toDateString(d.userRegisterTime,'yyyy-MM-dd HH:mm:ss')}}</div>"},
                {field:'amend_time', title:'修改时间', width:120, templet:"<div>{{layui.util.toDateString(d.userRegisterTime,'yyyy-MM-dd HH:mm:ss')}}</div>"},
                {fixed: 'right', title:'操作', toolbar: '#barDemo', width:150,fixed: 'right',}
            ]]
            ,page: true
        });
        //监听行工具事件
        table.on('tool(recycArticle)', function(obj){
            console.log(obj)
            if(obj.event === 'del'){
                layer.confirm('确定从回收站删除这一行吗？', function(index){
                    obj.del();
                    layer.close(index);
                    var id=obj['data']['article_id'];//取文章id
                    $.ajax({
                        url:"../php/cp_recycling.php?ope=recycArticle",
                        type:'post',
                        dataType:'json',
                        data:{id:id},
                        success:function(res){
                            console.log(res);
                            layer.msg('还原文章成功');
                        }
                    });
                });
            }
        });
    });
}
//还原已删除用户
function cpBackUser(){
    layui.use('table', function(){
        var table = layui.table;
        table.render({
            elem: '#userTable',
            url:'../php/cp_recycling.php?ope=user',
            toolbar: '#toolbarDemo',
            title: '用户数据表',
            totalRow: true,
            cols: [[
                {field:'id', title:'用户ID', width:80, fixed: 'left', unresize: true, sort: true},
                {field:'name', title:'用户名字', width:120, edit: 'text'},
                {field:'email', title:'用户邮箱', width:150,align:"center", sort: false,edit: 'text'},
                {field:'phone', title:'电话', width:120},
                {field:'login_time', title:'最后登录时间', width:120,templet:"<div>{{layui.util.toDateString(d.userRegisterTime,'yyyy-MM-dd HH:mm:ss')}}</div>"},
                {field:'roots', title:'权限', width:120, templet:function(res){
                    if(res.roots>99) return "超级管理员";
                    else if(res.roots>0) return "普通用户";
                 }},
                {field:'create_time', title:'注册时间', width:120, templet:"<div>{{layui.util.toDateString(d.userRegisterTime,'yyyy-MM-dd HH:mm:ss')}}</div>"},
                {fixed: 'right', title:'操作', toolbar: '#barDemo', width:150,fixed: 'right',}
            ]]
            ,page: true
        });
        table.on('tool(recycUser)', function(obj){
            console.log(obj)
            if(obj.event === 'del'){
                layer.confirm('确定从回收站删除这一行吗？', function(index){
                    obj.del();
                    layer.close(index);
                    var id=obj['data']['id'];//取文章id
                    $.ajax({
                        url:"../php/cp_recycling.php?ope=recycUser",
                        type:'post',
                        dataType:'json',
                        data:{id:id},
                        success:function(res){
                            console.log(res);
                            layer.msg('还原用户成功');
                        }
                    });
                });
            }
        });

    });
}


// //----------------------获取文章对应得栏目名字
// function getColName(colArr,id){
//     for( var i=0; i< colArr.length; i++ ){
//         if(colArr[i].id==id){
//             return colArr[i].name;
//         }
//     }
//     return "无";
// }
// //转换时间
// function getLocalTime(nS) {
//     return new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
// }