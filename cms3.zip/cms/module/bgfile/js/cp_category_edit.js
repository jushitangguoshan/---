$(function(){
    init();//初始化界面
    editCol();  //编辑栏目
})
//初始化界面
function init(){
    var colId=$.cookie("editColId");
    $.ajax({
        url:"./php/cp_category_edit.php?ope=init",
        type:"post",
        dataType:"json",
        data:"colId="+colId,
        cache:false,
        success:function(res){
           // console.log(res);
            $('[name="name"]').val(res.arr[0]['name']);
            $('[name="sort"]').val(res.arr[0]['show_sort']);
            var html="";
            for(var i=0; i<res.colArr.length; i++){
                if( res.colArr[i]['id']==res.arr[0]['p_id'] ){
                    html+="<option value="+res.colArr[i]['id']+" selected>"+res.colArr[i]['name']+"</option>";
                }else{
                    html+="<option value="+res.colArr[i]['id']+">"+res.colArr[i]['name']+"</option>";
                }
            }
            $('[name="pid"]').html(html);
        }
    });
}
//编辑栏目
function editCol(){

    $('.cp-alt-column').click(function(){
        var format=new FormData($('#editFormCol')[0]);
        $.ajax({
            url: './php/cp_category_edit.php?ope=editCol',
            type: 'POST',
            cache: false,
            data: format,
            dataType:"json",
            processData: false,
            contentType: false,
            success: function (res) {
               // console.log(res);
                if( res.statu==0 ){//失败
                    alert(res.message);
                }else if(res.statu==1){
                    alert(res.message);
                    window.location.href="./cp_category.html";
                }
            }
        });
    });
}