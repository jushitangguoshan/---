
$(function(){
    //点击提示
    init();
    $('[name="root"]').click(function(){
        layer.tips('你无权修改','[name="root"]');
    });
    $('[name="state"]').click(function(){
        layer.tips('你无权修改','[name="state"]');
    });
    $('[name="username"]').click(function(){
        layer.tips('你无权修改','[name="username"]');
    });
    $('.layui-btn').click(function(){
        $.ajax({
        url:'../php/cp_personal.php?ope=amend',
        type:'post',
        dataType:'json',
        data:$('form').serialize(),
        success:function(res){
            console.log(res);
            if(res.statu===0){
                layer.msg(res.message);
            }else if( res.statu===1 ){
                layer.msg(res.message);
            }
        }
    });
    });
})

//表单初始赋值
function init(){
    $.ajax({
        url:'../php/cp_personal.php?ope=init',
        dataType:'json',
        success:function(res){
            console.log(res);
            var user=res.arr[0]; console.log(user);
            layui.use(['form', 'layedit', 'laydate'], function() {
                var form = layui.form
                form.val('example', {
                    "username": user.name,
                    "password": user.pwd,
                    "email":user.email,
                    "phone" : user.phone,
                    "state":user.state,
                    "root":user.roots,
                });
            });
        }
    });
}
