var COLARR1=[]//栏目列表数组一维
 var COLARR2=[];//栏目列表数组二维

$(function() {
    // layui.use('upload', function(){
    //     var $ = layui.jquery,
    //     upload = layui.upload;
    //     upload.render({
    //         elem: '#test3'
    //         ,url: '../php/cp_article.php?ope=importCsvArticle'
    //         ,accept: 'file' //普通文件
    //         ,done: function(res){
    //             console.log(res);
    //           layer.msg(res.message);
    //         }
    //     });
    // });
    init_la();
    // init();//初始化界面
    // /*---------------删除*/
    // $('body').on("click",".jq-del",function(){ delArticle(this);  });
    // /*--------------筛选*/
    $('#screening').click(function(){   screenFuc();  });
    // /*--------------排序*/
    // $('#sorting').click(function(){  orderBy(); });
    // /*--------------搜索*/
    $('#search').click(function(){ searchFuc();  });
    // /*-------------导入*/
    //$(".import").click(function(){ importCsvFuc();  });
    $("#import").click(function(){ importCsvFuc();  });

    // /*-------------编辑*/
    // $('body').on("click",".alt_article",function(){ editFuc(this); });
});
//--------------------搜索模块
//searchFuc();

function getListName(arr,level = 0){
    var html="";
    for (var i=0; i<arr.length; i++) {
        if ( arr[i].hasOwnProperty("_child") ) {
            html +="<option value='"+ arr[i]['id']+"'>"+ arr[i]['name']+"</option>";
            html += getListName( arr[i]['_child'],level+1);
        }else{
            for ($i=0;$i<level;$i++){
                html +="<option value='"+ arr[i]['id']+"'>------"+ arr[i]['name']+"</option>";
            }
            if(level==0 && !arr[i].hasOwnProperty("_child")) {
                html += "<option value='" + arr[i]['id'] + "'>" + arr[i]['name'] + "</option>";
            }
        }
    }
    return html;
}
function screenFuc(){
    var id=$('[name="cid"]').val();
    layui.use('table', function(){
        var table = layui.table;
        showTab(table,'screening',"&colID="+id);
        $('body').on('click','#search',function(){
            table.reload('test', {
                method: 'post',
                page: {
                    curr: 1 //重新从第 1 页开始
                }
                ,where: {
                    key: {
                        colId:id
                    }
                }
            });
        });
    });
}
function showTab(table,method,content=''){
    table.render({
        elem: '#myTable',
        url:'../php/cp_article.php?ope='+method+content,
        toolbar: '#toolbarDemo',
        title: '文章数据表',
        totalRow:true,
        cols: [[
            {field:'article_id', title:'文章ID', width:80,  sort: true,align:'center'}
            ,{field:'author_name', title:'作者名', width:80,align:'center' }
            ,{field:'title', title:'标题', width:200}
            ,{field:'state', title:'状态', width:100, sort: true,align:'center'}
            ,{field:'keywords', title:'关键字', width:80,align:'center'}
            ,{field:'belongto_column', title:'所属栏目', width:93,align:'center'}
            ,{field:'click_num', title:'浏览量',width:106, sort: true,align:'center'}
            ,{field:'create_time', title:'上传时间', width:120, templet:"<div>{{layui.util.toDateString(d.userRegisterTime,'yyyy-MM-dd HH:mm:ss')}}</div>",sort: true}
            ,{field:'amend_time', title:'最近修改时间', width:120,templet:"<div>{{layui.util.toDateString(d.userRegisterTime,'yyyy-MM-dd HH:mm:ss')}}</div>", sort: true}
            ,{fixed: 'right', title:'操作', toolbar: '#barDemo', width:150,align:'center'}
        ]],
        page: true
    });
}
function searchFuc(){
    layui.use('table', function(){
    var table = layui.table;
    var cont=$('[name="do_search"]').val();
        showTab(table,'search',"&content="+cont);
        $('body').on('click','#search',function(){
            table.reload('test', {
                method: 'post',
                page: {
                    curr: 1 //重新从第 1 页开始
                }
                ,where: {
                    key: {
                        cont: cont
                    }
                }
            });
        });
    });
}

function init_la(){
    layui.use('table', function(){
        var table = layui.table;
        table.render({
            elem: '#myTable',
            url:'../php/cp_article.php?ope=init',
            toolbar: '#toolbarDemo',
            title: '文章数据表',
            totalRow:true,
            cols: [[
                {field:'article_id', title:'文章ID', width:80,  sort: true,align:'center'}
                ,{field:'author_name', title:'作者名', width:80,align:'center' }
                ,{field:'title', title:'标题', width:200}
                ,{field:'state', title:'状态', width:100, sort: true,align:'center'}
                ,{field:'keywords', title:'关键字', width:80,align:'center'}
                ,{field:'belongto_column', title:'所属栏目', width:93,align:'center'}
                ,{field:'click_num', title:'浏览量',width:106, sort: true,align:'center'}
                ,{field:'create_time', title:'上传时间', width:120, templet:"<div>{{layui.util.toDateString(d.userRegisterTime,'yyyy-MM-dd HH:mm:ss')}}</div>",sort: true}
                ,{field:'amend_time', title:'最近修改时间', width:120,templet:"<div>{{layui.util.toDateString(d.userRegisterTime,'yyyy-MM-dd HH:mm:ss')}}</div>", sort: true}
                ,{fixed: 'right', title:'操作', toolbar: '#barDemo', width:150,align:'center'}
            ]],
            page: true
        });

        //栏目
        $.ajax({
            url:'../php/cp_article.php?ope=getCol',
            type:"post",
            dataType:"json",
            success:function(res){
                console.log(res);
                COLARR2=res.colArr2;
               var html= getListName(COLARR2,level = 0);
                $('[name="cid"]').append(html);
            }
        });
       // 监听行工具事件
        table.on('tool(test)', function(obj){
            var data = obj.data;
            //console.log(obj)
            if(obj.event === 'del'){
                layer.confirm('真的删除行么', function(index){
                    obj.del();
                    layer.close(index);
                    delAjax_lay(data.article_id);
                });
            } else if(obj.event === 'edit'){
                editFuc( obj.data);

            }
        });
    });


}
function editFuc(data){
    //console.log(obj);
    layui.use(['form'],function(){
        layui.layer.open({
            title:"修改文章",
            type:2,
            content:'../html/cp_article_edit.html',
            shadeClose:true,
            shade:0.5,
            area:['850px','580px'],
            btn:['关闭修改页面'],
            yes:function(){
                layer.closeAll();
                location.reload('table');
            },
            success: function(layero, index){
                console.log(layero, index);
                var body = layer.getChildFrame('body', index);
                body.find('[name="title"]').val( data.title );
                body.find('[name="cidList"]').val( data.belongto_column );
                body.find('[name="author"]').val( data.author_name );
                body.find('[name="keywords"]').val( data.keywords );
                body.find('[name="description"]').val( data.description );
                body.find('[name="content"]').val( data.content );
                body.find('[name="id"]').val( data.article_id );
                body.find('[name="mark"]').val( "amend" );
                //form.render('select');
            }
        });

   });
}

// //--------------------导入
function importCsvFuc(){
    var format=new FormData($('#csvForm')[0]);
    $.ajax({
        url:"../php/cp_article.php?ope=importCsvArticle",
        type:'post',
        dataType:'json',
        cache:false,
        data:format,
        processData: false,
        contentType: false,
        success:function(res){
            console.log(res);
            if(res.statu==1){
                alert(res.message);
            }else if(res.statu==0){
                alert(res.message);
            }
        }
    });
}
//删除
function delAjax_lay(id){
    $.ajax({
        url:'../php/cp_article.php?ope=del_article',
        type:"post",
        cache: false,
        data:'id='+id,
        dataType:"json",
        success:function(res){
            console.log(res);
            if( res.statu===1 ){
                layer.alert(res.message, {icon: 1});
            }else if( res.statu===0 ){
                layer.alert(res.message, {icon: 5});
            }
        }
    });
}
// function editAjax_lay(mark){
//    $.ajax({
//        url:"../php/cp_article.php?ope=edit_article&state="+mark,
//        type:'post',
//        cache:false,
//        dataType:'json',
//        data:new FormData( $('form')[0] ),
//        contentType: false,
//        processData: false,
//        success:function(res){
//            console.log(res);
//            if( res.statu==0 ){
//                layer.alert(res.message, {icon: 5});
//             }else if(res.statu==1){
//                layer.alert(res.message, {icon: 1});
//             }
//            location.reload();//重载页面
//        }
//    });
// }


/*
//----------------------初始化
function init(){
    $.ajax({
        url:'../php/cp_article.php?ope=init',
        type:"post",
        dataType:"json",
        cache:false,
        success:function(res){
            console.log(res);
            COLARR1=res.colArr1;//----------存储所有列表
            COLARR2=res.colArr2;//----------存储所有列表
            $('[name="cid"]').append(getListName(COLARR2,level = 0));
            reShowArticle(res.arr,COLARR1);
        }
    });
}

//-----------------编辑(页面跳转)
function editFuc(obj){
    var mark=$(obj).parents('tr').find("td:last").text();
    $.cookie("editArticleId",mark);
    window.location.href=("./cp_article_edit_2.html");
}



// //--------------------导入
csv
function importCsvFuc(){
    var format=new FormData($('#csv')[0]);
    $.ajax({
        url:"../php/cp_article.php?ope=importCsvArticle",
        type:'post',
        dataType:'json',
        cache:false,
        data:format,
        processData: false,
        contentType: false,
        success:function(res){
            console.log(res);
            if(res.statu==1){
                alert(res.message);
            }else if(res.statu==0){
                alert(res.message);
            }
        }
    });
}

//--------------------搜索模块
function searchFuc(){
    if( $('[name="searContent"]').val()=="" ){
        alert("请输入搜索内容");return;
    }
    var content=$('[name="searContent"]').val();
    $.ajax({
        url:'../php/cp_article.php?ope=search',
        type:'post',
        cache:false,
        data:{content:content},
        dataType:'json',
        success:function(res){
            console.log(res);
            if(res.statu==0){
                alert(res.message);return;
            }else if(res.statu==1){
                reShowArticle(res.arr,COLARR1);
            }
        }
    });
}
//---------------------排序
function orderBy(){
    var method=$('[name="order"]').val();
    $.ajax({
        url: '../php/cp_article.php?ope=sorting',
        type:'post',
        cache: false,
        data:'method='+method,
        dataType:"json",
        success: function (res) {
            console.log(res);
            if(res.statu==0){
                alert(res.arr);return;
            }else if(res.statu==1){
                reShowArticle(res.arr,COLARR1);
            }
        }
    });

}
//----------------------筛选模块
function screenFuc(){
        var id=$('[name="cid"]').val();
        $.ajax({
            url:"../php/cp_article.php?ope=screening",
            type:'post',
            cache:false,
            data:"colId="+id,
            dataType:"json",
            success:function(res){
                console.log(res);
                if(res.statu==1){
                    reShowArticle(res.arr,COLARR1);
                }else{
                    alert('查询失败！');return;
                }
            }
        });
}
//----------------------删除模块
function delArticle(obj){
        if( !confirm("您确定要删除此文章？") ){
            return;
        }
        var mark=$(obj).parents('tr').find("td:last").text();
        $.ajax({
            url:'../php/cp_article.php?ope=del_article',
            type:"post",
            cache: false,
            data:'id='+mark,
            dataType:"json",
            success:function(res){
                console.log(res);
                if(res.statu==1){
                    reShowArticle(res.arr,COLARR2);
                }else{
                    alert("删除失败");
                }
            }
        });
}




//---------------------再次刷新表格
function reShowArticle(arr,colArr){
    var html="";
    for(var i=0; i<arr.length;i++){
        html+="<tr>"+
            "<td class='s-show'><i class='icon-yes'>"+getState_reShow( arr[i] )+"</i></td>"+
            "<td class='s-title'><a href='../show.php' target='_blank'>"+arr[i].title+"</a></td>"+
            "<td><a href='#'>"+getColName(colArr,arr[i].belongto_column)+"</a></td>"+
            "<td>"+arr[i].author_name+"</td>"+
            "<td>"+getLocalTime(arr[i].create_time)+"</td>"+
            "<td class='s-act'>"+
            "<a href='#' class='alt_article'>"+"编辑</a>"+
            "<a href='#' class='jq-del'>"+"删除</a>"+
            "</td>"+
            "<td style='display: none'>"+arr[i].article_id+"</td>"+
            "</tr>";
    }
    $('#article_tbody').html(html);
    // $('.pagelist').hide();
}
//----------------------获取栏目
function getListName(arr,level = 0){
    var html="";
    for (var i=0; i<arr.length; i++) {
        if ( arr[i].hasOwnProperty("_child") ) {
            html +="<option value='"+ arr[i]['id']+"'>"+ arr[i]['name']+"</option>";
            html += getListName( arr[i]['_child'],level+1);
        }else{
            for ($i=0;$i<level;$i++){
                html +="<option value='"+ arr[i]['id']+"'>------"+ arr[i]['name']+"</option>";
            }
            if(level==0 && !arr[i].hasOwnProperty("_child")) {
                html += "<option value='" + arr[i]['id'] + "'>" + arr[i]['name'] + "</option>";
            }
        }
    }
    return html;
}
//----------------------获取文章对应得栏目名字
function getColName(colArr,id){
    for( var i=0; i< colArr.length; i++ ){
        if(colArr[i].id==id){
            return colArr[i].name;
        }
    }
    return "无";
}
//------------------------转换文章状态
function getState_reShow(obj){
    if(obj.state==1)return "已发布";
    else if(obj.state==2)return "未发布";
    else if(obj.state==-1)return "已删除";
}
//-----------------------转换时间显示
function getLocalTime(nS) {
    return new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
}


    // CSV 模块


//     //导入
//     $(".import").click(function(){
//         var format=new FormData($('#csv')[0]);
//         $.ajax({
//             url:"headle.php?ope=importCsvArticle",
//             type:'post',
//             dataType:'json',
//             cache:false,
//             data:format,
//             processData: false,
//             contentType: false,
//             success:function(res){
//                 console.log(res);
//                 if(res.statu==1){
//                     alert(res.message);
//                 }else if(res.statu==0){
//                     alert(res.message);
//                 }
//             }
//         });
//     });
//
//
//     //删除模块
//     $('body').on("click",".jq-del",function(){
//         var obj=this;
//         if( !confirm("您确定要删除此文章？") ){
//             return;
//         }else{
//             var mark=$(this).parents('tr').find("td:last").text();
//             $.ajax({
//                 url:"headle.php?ope=del_article",
//                 type:"post",
//                 cache: false,
//                 data:'id='+mark,
//                 dataType:"json",
//                 success:function(res){
//                     console.log(res);
//                     if(res.statu==1){
//                         $(obj).parents('tr').remove();
//                     }else{
//                         alert("删除失败");
//                     }
//                 }
//             });
//         }
//     });
//     //编辑模块
//     $('body').on("click",".alt_article",function(){
//         var mark=$(this).parents('tr').find("td:last").text();
//         window.location.href=("cp_article_edit_2.php?id="+mark);
//     });
//     //筛选栏目
//     $('#screening').click(function(){
//         var id=$('[name="cid"]').val();
//         $.ajax({
//             url:"headle.php?ope=screening",
//             type:'post',
//             cache:false,
//             data:"colId="+id,
//             dataType:"json",
//             success:function(res){
//                 console.log(res);
//                 if(res.statu==1){
//                     reShowArticle(res.arr);
//                 }
//             }
//         });
//     });
//     //搜索模块
//     $('#search').click(function(){
//         if( $('[name="searContent"]').val()=="" ){
//             alert("请输入搜索内容");return;
//         }
//         var content=$('[name="searContent"]').val();
//         $.ajax({
//             url:'headle.php?ope=search',
//             type:'post',
//             cache:false,
//             data:{content:content},
//             dataType:'json',
//             success:function(res){
//                 console.log(res);
//                 if(res.statu==0){
//                     alert(res.arr);return;
//                 }else if(res.statu==1){
//                     reShowArticle(res.arr);
//                 }
//             }
//         });
//     });
//     //排序
//     $('#sorting').click(function(){
//         var method=$('[name="order"]').val();
//         $.ajax({
//             url: 'headle.php?ope=sorting&method='+method,
//             type:'post',
//             cache: false,
//             dataType:"json",
//             success: function (res) {
//                 //console.log(res);
//                 if(res.statu==0){
//                     alert(res.arr);return;
//                 }else if(res.statu==1){
//                     reShowArticle(res.arr);
//                 }
//             }
//         });
//     });
// });
// //局部刷新（ 搜索+排序 ）
*/