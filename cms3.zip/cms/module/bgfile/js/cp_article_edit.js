/*
*
* <select  id="cidList" name="modules" lay-verify="required" lay-search="">
                                                  </select>
* */

$(function() {
    CKEDITOR.config.height = 400;
    CKEDITOR.config.width = "100%";
    CKEDITOR.replace("content");
    var ckEditor = CKEDITOR.instances.contect_text;
    // var selection = editor.getSelection();//获取选中对象
    // var content = editor.document.getBody().getText();//获取纯文本
    // var content_selected = selection.getNative();//获取选中的文本
    // var content_with_tag = editor.getData();//获取标签+文本
    initData();//初始化数据-
    submitData();//提交数据
})
/*---------------初始化数据-----------------------*/
function initData(){
    $.ajax({
        url: "../php/cp_article_edit.php?ope=init",
        type: 'post',
        cache: false,
        async:false,
        dataType: "json",
        success: function (res) {
          // console.log(res);
           var list=getListName(res.arr);
            $('#cidList').append(list);
        }
    });

}
/*---------------获取栏目-----------------------*/
function getListName(arr,level = 0){
   var html="";
    for (var i=0; i<arr.length; i++) {
        // array_push($html,[$item['name'],$item['p_id']]);//查看输出的顺序
        if ( arr[i].hasOwnProperty("_child") ) {
            html +="<option value='"+ arr[i]['id']+"'>"+ arr[i]['name']+"</option>";
            html += getListName( arr[i]['_child'],level+1);
        }else{
            for ($i=0;$i<level;$i++){
                html +="<option value='"+ arr[i]['id']+"'>------"+ arr[i]['name']+"</option>";
            }
            if(level==0 && !arr[i].hasOwnProperty("_child")) {
                html += "<option value='" + arr[i]['id'] + "'>" + arr[i]['name'] + "</option>";
            }
        }
    }
    return html;
}



/*---------------提交数据-----------------------*/
function submitData(){
    $(".tj").click(function () {
        var mark=1;
        if( $(this).val()== "保存草稿") mark=0;
        var   content = CKEDITOR.instances.contect_text.getData();
        var format=new FormData($('#uploadForm')[0]);
        format.append("content",content);
        $.ajax({
            url: '../php/cp_article_edit.php?ope=publish&state='+mark,
            type: 'POST',
            cache: false,
            data: format,
            dataType:"json",
            processData: false,
            contentType: false,
            success: function (res) {
                //console.log(res);
                if( res.statu==0 ){
                    layer.msg(res.message);
                }else if(res.statu==1 && res.mark=='amend'){
                    layer.msg(res.message);
                }else if(res.statu==1 && res.mark=='add'){//成功
                    layer.msg(res.message);
                     $('#uploadForm')[0].reset();
                }
            }
        });
    });
}
//阻止表单提交
function exitSubmit(){
    return false;
}








