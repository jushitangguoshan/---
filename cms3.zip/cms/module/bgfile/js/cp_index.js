$(function(){
    judgeIsLogin();//判断是否登录
    init();//--------------初始化
    //单击链接，按钮高亮
    $(".jq-nav").click(function () {
        $(this).addClass("curr").siblings().removeClass("curr");
    });
    $('#exitLogin').click(function(){ exisLogin() });
})
/*-------------------------初始化------------*/
function init(){

    $.ajax({
        url:'../php/indexHeadle.php?ope=init',
        type:'post',
        dataType:'json',
        cache:false,
        async:false,
        success:function(res){
            console.log(res);
            giveValue(res);
        }
    });
}
function judgeIsLogin(){
    $.ajax({
        url:'../php/indexHeadle.php?ope=isLogin',
        type:'post',
        dataType:'json',
        success:function(res){
           // console.log(res);
            if( res.state === 1 ){
                window.location.href=("http://www.anniluohaixing.xyz/cms/module/login/login.html");
            }
        }
    });
}
/*-*------------------退出--------------------*/
function exisLogin(){
    $.ajax({
        url:'../php/indexHeadle.php?ope=exitLogin',
        dataType:'json',
        success:function(res){
            console.log(res);
            if( res.state===1 ){
                window.location.href=("http://www.anniluohaixing.xyz/admin.php");
            }
        }
    });
}
/*------------------初始化---（赋值）+(权限)------------*/
function giveValue(obj){
    $('#username').html(obj.user);
    $('.icon-admin').html( obj.user );
    if( obj.root === "普通用户" ){
        $('.root100').remove();
;    }else if( obj.root==="超级管理员" ){
        $('.root').remove();
    }
}