$(function() {
    init();//初始化
});
/*----------------------------修改用户信息*/
function editMess(data){
    layui.use(['form'], function () {
        var form = layui.form;
        $('[name="id"]').val(data.id);
        $('[name="name"]').val(data.name);
        $('[name="email"]').val(data.email);
        $('[name="phone"]').val(data.phone);
        $('[name="state"]').children().each(function (i, item) {
            if ( data.state == $(item).val()) {
                $(this).attr('selected', true);
            }
        });
        $('[name="root"]').children().each(function (i, item) {
            if (data.roots  == $(item).val()) {
                $(this).attr('selected', true);
            }
        });
        form.render('select');
        layui.layer.open({
            title: "修改用户",
            type: 1,
            content: $('#child_edit'),//弹出层页面
            shadeClose: false,
            shade: 0.5,
            area: ['600px', '520px'],
            cancel: function(){//关闭按钮的回调函数
                $('#child_edit').css('display','none');

            },
            btn: ["提交修改", "取消修改"],
            btn1: function () { altAjax(); },
            btn2: function (index) {
                layer.close(index);
                $('#child_edit').hide();
            }//隐藏表单
         });
    });
}
/*----------------------------修改的ajax请求*/
function altAjax(){
    $.ajax({
        url: "../php/cp_user_manage.php?ope=amend",
        type: 'post',
        data: $('form').serialize(),
        dataType: 'json',
        success: function (res) {
            console.log(res);
            if ( res.statu === 1 ) {
                layer.confirm('修改成功', {
                    btn: ['关闭所有页面', '继续修改'] //可以无限个按钮
                    ,yes: function () {
                        location.reload();//重载页面
                        layer.closeAll();//关闭所有弹层
                        $('#child_edit').hide();//隐藏表单
                    }
                    ,function(index) {
                        location.reload();//重载页面
                        layer.close(index);
                        $('#child_edit').hide();//隐藏表单
                      //
                    }
                });
            }else if(  res.statu === 0 ){
                layer.alert(res.message, {icon: 5});
              //  $('#child_edit').hide();//隐藏表单
            }

        }
    });
}
/*----------------------------增加的ajax请求*/
function addAjax(){
    $.ajax({
        url:"../php/cp_user_manage.php?ope=add",
        type:'post',
        data:$('form').serialize(),
        dataType:'json',
        success:function(res) {
            console.log(res);
            if (res.statu == 1) {
                layer.confirm('添加成功', {
                    btn: ['关闭所有页面', '继续添加'] //可以无限个按钮
                    ,yes:function () {
                        location.reload();
                        layer.closeAll();
                        $('#child_edit').hide();
                    }
                    ,function(index){
                        layer.close(index);
                    }
                });
                $('#child_edit').hide();
            }else{
                layer.alert(res.message, {icon: 5});
            }
        }
    });
}
/*----------------------------增加用户*/
function addUser(){
    layui.use(['form','table'], function(){
        var form = layui.form;
        $('[name="state"]').val("");
        $('[name="root"]').val("");
        form.render('select');
        layui.layer.open({
            title : "增加用户",
            type : 1,
            content : $('#child_edit'),//弹出层页面
            shadeClose: false,
            shade: 0.5,
            area: ['600px', '520px'],
            btn: ['保存','取消'],
            cancel: function(){//关闭按钮的回调函数
                $('#child_edit').css('display','none');
            },
            yes : function() {
                addAjax();
            }
        });
    });
}
/*----------------------------初始化*/
function init(){
    layui.use('table', function(){
        var table = layui.table;
        table.render({
            elem: '#userTable',
            url:'../php/cp_user_manage.php?ope=getCount',
            title: '用户数据表',

            cols: [[
                {field:'id', title:'用户ID', width:80,fixed: 'left', unresize: true, sort: true},
                {field:'name', title:'用户名', width:120, },
                {field:'email', title:'邮箱', width:150,  templet: function(res){
                        return '<em>'+ res.email +'</em>'
                    }},
                {field:'phone', title:'电话',width:150},
                {field:'state', title:'状态', width:80, sort: true},
                {field:'roots', title:'权限', width:80},
                {field:'create_time', title:'注册时间', width:200, templet:"<div>{{layui.util.toDateString(d.userRegisterTime,'yyyy-MM-dd HH:mm:ss')}}</div>"},
                {field:'login_time', title:'最后登录时间', width:200,templet:"<div>{{layui.util.toDateString(d.userRegisterTime,'yyyy-MM-dd HH:mm:ss')}}</div>"},
                {fixed: 'right', title:'操作', toolbar: '#barDemo', width:150,fixed: 'right'},
            ]],
            page:true
        });
        //监听行工具事件
        table.on('tool(test)', function(obj){
            if(obj.event === 'add'){
                addUser();
            } else if(obj.event === 'edit'){
                // console.log(  obj.data );
                editMess(  obj.data );
            }
        });
    });
}
//--------------初始化界面
/*
function init(){
    $.ajax({
        url:"../php/cp_user_manage.php?ope=init",
        type:"post",
        cache:false,
        dataType:"json",
        success:function(res){
        console.log(res);
            var temp_s="";
            var temp_r="";
            var html="";
            for(var i=0; i<res.arr.length; i++){
                if( res.arr[i]['state']==1) temp_s='正常';
                else if( res.arr[i]['state']==-1) temp_s='冻结';
                if( res.arr[i]['roots']==1)  temp_r='普通用户';
                else if( res.arr[i]['roots']>100) temp_r='超级管理员';
                html +="<tr>\
                        <td>"+res.arr[i]['id']+"</td>\
                        <td>"+res.arr[i]['name']+"</td>\
                        <td>"+res.arr[i]['pwd']+"</td>\
                        <td>"+res.arr[i]['phone']+"</td>\
                        <td>"+temp_s+"</td>\
                        <td>"+temp_r+"</td>\
                            <td>"+getLocalTime(res.arr[i]['login_time'])+"</td>\
                            <td>"+getLocalTime(res.arr[i]['create_time'])+"</td>\
                        <td>\
                            <button class='manageAdd'>增加</button>\
                            <button class='manageAmend'>修改</button>\
                        </td>\
                        </tr>";

            }
            $('#mybody').html(html);
            cpAdd();//增加用户
            cpAmend();//修改用户信息
        }
    });
}
//修改用户
function cpAmend(){
    $('body').on('click','.manageAmend',function(){
        var tdArr=$(this).parents('tr').children();
        showInput("修改用户",tdArr.eq(1).text(),'',tdArr.eq(3).text(),"正常",'普通用户','amend');
        $('#tj').click(function(){
            $.getJSON("../php/cp_user_manage.php?ope=amend",{
                'id':tdArr.eq(0).text(),
                'name':$("[name='name']").val(),
                'phone':$("[name='phone']").val(),
                'pwd':$("[name='pwd']").val(),
                'email':$("[name='email']").val(),
                'state':$("[name='state']").val(),
                'root':$("[name='root']").val()
            },function(res){
                console.log(res);
                if(res.statu==0){
                    $('.ts').css('color','red').html("<h3>"+res.message+"</h3>");
                }else if(res.statu==1){
                    $('#userList').html("<h3>"+res.message+"</h3>");
                }
            });
        });
    });
}
//增加用户
function cpAdd(){
    $('body').on('click','.manageAdd',function(){
        showInput("增加用户",'','','','','',"正常",'普通用户','add');
        $('#tj').click(function(){
            $.getJSON("../php/cp_user_manage.php?ope=add",{
                'name':$("[name='name']").val(),
                'phone':$("[name='phone']").val(),
                'pwd':$("[name='pwd']").val(),
                'email':$("[name='email']").val(),
                'state':$("[name='state']").val(),
                'root':$("[name='root']").val()
            },function(res){
                console.log(res);
                if(res.statu==0){
                    $('.ts').css('color','red').html(res.message);
                }else if(res.statu==1){
                    $('#userList').html("<h3>添加成功</h3>");
                }
            });
        });
    });
}
function showInput(content,name,pwd,phone,state,root,mark){
    var html="<h1>"+content+"</h1>" +  "<table>" +
        "<tr>";
    var tr1= "<td>姓名</td><td><input type='text' name='name'  value='"+name+"' readonly></td></tr>";
    var tr2="<td>姓名</td><td><input type='text' name='name'  value='"+name+"' ></td></tr>";
    if(mark=='amend'){
        html +=tr1;
    }else{
        html +=tr2;
    }
    html+="<tr>" +
             "<td>密码</td><td><input type='password' name='pwd' value='"+pwd+"' placeholder='必填' ></td>" +
        "</tr>" +
        "<tr>" +
            "<td>电话</td><td><input type='text' name='phone' value='"+phone+"'></td>" +
        "</tr>" +
        "<tr>" +
            "<td>状态</td>"+
        " <td>" +
            "<select name='state' value='"+state+"'>" +
                "<option value=1>正常</option>"+
                "<option value=-1>冻结</option>"+
            "</select>"+
        "</td>" +
        "</tr>" +
        "<tr>" +
            "<td> 权限</td>"+
            "<td>" +
                "<select name='root' value='"+root+"'>" +
                    "<option value=1>普通用户</option>"+
                    "<option value=100>管理员</option>"+
                "</select>"+
            "</td>" +
        "</tr>" +
        "<tr><td><button id='tj'>提交</button></td>" + "</tr>" +
        "</table>" +
        "<span class='ts'></span>";
    $('.box-body').html(html);
}
function getLocalTime(nS) {
    return new Date(parseInt(nS) * 1000).toLocaleString().replace(/:\d{1,2}$/,' ');
}
*/
