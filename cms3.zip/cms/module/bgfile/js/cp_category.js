var add_id = 0; //保存ID计数
var add_child=0;
$(function () {
    init();//初始化
    addPCol();//添加父栏目
    addSCol();//添加子栏目
    concelAdd();//取消添加
    delCol();//删除栏目
    tj();//提交
    editCol();//编辑
});

//初始化列表请求
function init(){
    $.ajax({
        url:"../php/cp_category.php?ope=init",
        dataType:'json',
        cache:false,
        success:function(res){
            console.log(res);
            $('.jq-column-list').html( getList(res.arr,$level = 0) ) ;
        }
    });
}
//得到显示列表
function getList(arr,$level = 0){
    var $html = '';
    for(var i=0; i<arr.length; i++){
        var num=i+1;
        //$html .= $item['name'].'<br>';//查看输出的顺序
        if( arr[i].hasOwnProperty("_child") ){
            $html +="<tr class = 'hover' >\
                <td class = 'center'>\
                <input type = 'text' class = 's-num' name = 'save[1][sort]' value = '"+num+"'>\
                </td>\
                <td>\
                <input type = 'text' name = 'save[1][name]' value = '"+arr[i]['name']+"'>\
            </td>\
            <td class = 'center'>\
                <a href = '#' class='jq-cp-edit'>编辑</a>\
                <a href = '#' class = 'jq-del'>删除</a>\
                </td>\
                <td class = 'jq-column-id_p' style='display:none'>"+arr[i]['p_id']+"</td>\
                <td class = 'jq-column-id' style='display:none'>"+arr[i]['id']+"</td>\
                </tr>";
            $html += getList(arr[i]['_child'],$level+1);
            $html +=" <tr>\
                <td colspan='3'>\
                <i class='icon-sub-add'></i>\
                <span class='jq-sub-add s-add' data-id='1'>\
                <i class='icon-cross'></i><b>添加子栏目</b>\
            </span>\
            </td>\
            </tr>";
        }else{
            for (var $i=0;$i<$level;$i++){
                // $html .= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nsbsp;';
                $html +="<tr class='hover'>\
                    <td class='center'>\
                    <input type='text' class='s-num' name='save[13][sort]' value='"+arr[i]['show_sort']+"'>\
                </td>\
                <td>\
                <i class='icon-sub'></i>\
                    <input type='text' name='save[13][name]' value='"+arr[i]['name']+"'>\
                </td>\
                <td class='center'>\
                    <a href='#' class='jq-cp-edit'>编辑</a>\
                    <a href='#' class='jq-del'>删除</a>\
                    </td>\
                    <td class = 'jq-column-id' style='display:none'>"+arr[i]['id']+"</td>\
                    <td class = 'jq-column-id_p' style='display:none'>"+arr[i]['p_id']+"</td>\
                    </tr>";
            }
            if( $level == 0 ){
                $html +="<tr class = 'hover'>\
                            <td class = 'center'>\
                                <input type = 'text' class = 's-num' name = 'save[1][sort]' value = '"+num+"'>\
                            </td>\
                            <td>\
                                <input type = 'text' name = 'save[1][name]' value = '"+arr[i]['name']+"'>\
                            </td>\
                            <td class = 'center'>\
                                <a href = '#' class='jq-cp-edit'>编辑</a>\
                                <a href = '#' class = 'jq-del'>删除</a>\
                            </td>\
                            <td class = 'jq-column-id' style='display:none'>"+arr[i]['p_id']+"</td>\
                            <td class = 'jq-column-id_p' style='display:none'>"+arr[i]['id']+"</td>\
                        </tr>\
                        <tr>\
                            <td colspan='3'>\
                            <i class='icon-sub-add'></i>\
                            <span class='jq-sub-add s-add' data-id='1'>\
                            <i class='icon-cross'></i><b>添加子栏目</b>\
                            </span>\
                            </td>\
                        </tr>";
            }
        }
    }
    return $html;
}
//添加父栏目
function addPCol(){
    $(".jq-add").click(function () {
        $(this).parents("tr").before(
            '<tr class="hover">\
                    <td class="center">\
                       <input type="text" class="s-num" name="add[' + add_id + '][sort]">\
                     </td>\
                    <td colspan="2">\
                         <input type="text" name="add[' + add_id + '][name]">\
                         <b class="jq-cancel">取消</b>\
                    </td>\
                     <td>\
                         <input type="hidden" name="add[' + add_id + '][name]" value="0">\
                    </td>\
                </tr>'
        );
        ++add_id;
    });
}
//取消添加
function concelAdd(){
    $(document).on("click", ".jq-cancel", function () {
        $(this).parents("tr").remove();
    });
}
//删除栏目
function delCol(){
    $(document).on("click", ".jq-del", function () {
        var obj=this;
        var mark=false;
        if( $(obj).parents('tr').children().last().prev().text()==0 ){
            if(parseInt($(obj).parents('tr').next().children().last().text())==parseInt($(obj).parents('tr').children().last().text()) ){
                alert("该栏目存在子栏目，无法删除");return;
            }else{
                mark=true;
            }
        }
        var columnId=$(this).parents("tr").children('td.jq-column-id').html();
        $.ajax({
            url:"./php/cp_category.php?ope=delCol",
            type:'post',
            cache:false,
            data:{delId:columnId},
            dataType:'json',
            success: function (res){
                // console.log(res);
                console.log( res.arr);
                if(res.statu==0){
                    alert(res.message);
                }else if(res.statu==1){
                    $(obj).parents("tr").remove();
                    if(mark){
                        $(obj).parents("tr").next().remove();
                    }
                    alert(res.message);
                }
            }
        });
    });
}
// 添加子栏目
function addSCol(){
    $(document).on("click", ".jq-sub-add", function () {
        if(add_child>0){
            var textOne=$(this).parents('tr').prev().children().find('input').last().val();
            var textTwo=$(this).parents('tr').prev().children().last().text();
            if(parseInt(textOne)>=0 ){
                var p_id=textOne;
            }else if(parseInt(textTwo)>=0  ){
                var p_id=textTwo;
            }
        }else{
            var p_id=$(this).parents('tr').prev().children().last().text();
            add_child=10;
        }
        $(this).parents("tr").before(
            '<tr class="hover">\
                  <td class="center">\
                         <input type="text" class="s-num" name="add[' + add_id + '][sort]">\
                    </td>\
                    <td colspan="2">\
                         <i class="icon-sub"></i>\
                         <input type="text" name="add[' + add_id + '][name]">\
                         <b class="jq-cancel">取消</b>\
                    </td>\
                    <td>\
                         <input type="hidden" name="add[' + add_id + '][name]" value="'+p_id+'">\
                     </td>\
                 </tr>');
        ++add_id;
    });
}
// 修改编辑
function editCol(){
    $(document).on("click", ".jq-cp-edit", function () {
        var columnId=$(this).parents("tr").children( '.jq-column-id').text();
        $.cookie("editColId",columnId);
        window.location.href="./cp_category_edit.html";
    });
}
//     遍历所有添加的栏目---------//提交
function tj(){
    $('#tj-category').click(function(){
        //console.log($("input[name^='add']"));
        var arr=new Array();
        var temp=new Array();
        var addInputArr=$("input[name^='add']");
        for(var i=0; i<addInputArr.length; i++){
            //  $.each(addInputArr,function(i,obj){
            if(addInputArr[i].value==""){
                alert("添加的栏目顺序、名字均不能为空");return;
            }
            if( (i!=0) && (i+1)%3==0 ){
                temp.push(parseInt(addInputArr[i].value));
                arr.push(temp);
                temp=new Array();
            }else{
                temp.push(addInputArr[i].value);
            }
        };
        console.log(arr);
        $.ajax({
            url: "./php/cp_category.php?ope=addCol",
            type : 'POST',
            data : {arr},
            dataType:'json',
            success: function (res) {
                console.log(res);
                if(res.statu==0){
                    alert(res.message);
                }else if(res.statu==1){
                    window.location.href="../php/cp_category.html";
                    alert(res.message);
                }
            }
        });

    });
}