// $(function() {
//     CKEDITOR.config.height = 400;
//     CKEDITOR.config.width = "100%";
//     CKEDITOR.replace("content");
//     var ckEditor = CKEDITOR.instances.contect_text;
//     init(ckEditor);//初始化
//     //提交后
//     $(".tj").click(function () { publish(this); });
// })
// /*----------------------初始化----------------------*/
// function init(ckEditor){
//    var id=$.cookie("editArticleId");
//    $.ajax({
//        url:"../php/cp_article_edit_2.php?ope=init",
//        type:'post',
//        dataType:'json',
//        data:"id="+id,
//        cache:false,
//        success:function(res){
//            console.log(res);
//            giveValue(ckEditor,res.arr[0]);  //form表单初始化
//            var html = getListName(res.colArr,level = 0);//栏目初始化
//            $('[name="cid"]').html(html);
//        }
//    });
// }
// /*---------------------获取初始值-----------------------------*/
// function giveValue(ckEditor,obj){
//     $('[name="title"]').val(obj.title);
//     $('[name="author"]').val(obj.author_name);
//     $('[name="keywords"]').val(obj.keywords);
//     $('[name="description"]').val(obj.description);
//     var html='';
//     if(obj.img_path==null){
//        html="<span> <i>你未上传背景图片 </i></span>";
//     }else{
//        html ="<img src='"+obj.img_path+"' alt='封面图' id='image'>";
//     }
//     $('#imageTs').before(html);
//     ckEditor.setData(obj.content);
// }
// /*---------------------提交表单-----------------------------*/
// function publish(obj){
//     var id=$.cookie("editArticleId");
//     var mark=1;
//     if( $(obj).val()== "保存草稿") mark=0;
//     var   content = CKEDITOR.instances.contect_text.getData();
//     //console.log(content);
//     var format=new FormData($('#editForm')[0]);
//     format.append("content",content);
//     format.append("id",id);
//     //.log(format);
//     $.ajax({
//         url: '../php/cp_article_edit_2.php?ope=edit_2&state='+mark,
//         type: 'POST',
//         cache: false,
//         data: format,
//         dataType:"json",
//         processData: false,
//         contentType: false,
//         success: function (res) {
//             console.log(res);
//             if( res.statu==0 ){
//                 alert(res.message);
//             }else if(res.statu==1){
//                 alert(res.message);
//             }
//         }
//     });
// }
//
//
// /*---------------打印栏目列表-----------------------*/
// function getListName(arr,level = 0){
//     var html="";
//     for (var i=0; i<arr.length; i++) {
//         // array_push($html,[$item['name'],$item['p_id']]);//查看输出的顺序
//         if ( arr[i].hasOwnProperty("_child") ) {
//             html +="<option value='"+ arr[i]['id']+"'>"+ arr[i]['name']+"</option>";
//             html += getListName( arr[i]['_child'],level+1);
//             continue;
//         }
//         for ($i=0;$i<level;$i++){
//             html +="<option value='"+ arr[i]['id']+"'>------"+ arr[i]['name']+"</option>";
//         }
//         if(level==0 && !arr[i].hasOwnProperty("_child")) {
//             html += "<option value='" + arr[i]['id'] + "'>" + arr[i]['name'] + "</option>";
//         }
//
//     }
//     return html;
// }