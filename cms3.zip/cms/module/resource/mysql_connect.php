<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2018/12/21 0021
     * Time: 上午 10:26
     */
    // defined( 'HOST') or define('HOST',"/");
     //var_dump(HOST);die;
    $link=@mysqli_connect("sqld-gz.bcehost.com","ca3a0c72c0d14d02960577145c3d0afc","fd11bb6cd7a44fbb9715029b7b66687b","uZVZRQAaEbNHAesVVUwd");
    if( !$link ){
        file_put_contents("../log/mysql_error.log",date("Y-m-d H:i:s")."文件：" .__FILE__.",第". __LINE__ ."行附近"."\n"."报错内容：".mysqli_connect_error(),FILE_APPEND);
        die;
    }
    if(!mysqli_set_charset($link,"utf8")){//检查 ——设置字符集
        file_put_contents('../log/mysql_error.log',date('Y/m/d H:i:s').'文件：'. __FILE__ .'，第'. __LINE__ .'行附近'."\n".'报错内容：'.mysqli_error($link),FILE_APPEND);
        die;
    }


    /*<?php

	数据库连接文件

    require_once 'config.php';
    $log_name = 'mysql_error.log';
    $link = @mysqli_connect(DB_HOST,DB_USER,DB_PWD,DB_NAME);
    if( !$link ){
        $message = date('Y/m/d H:i:s') . '   数据库连接失败，错误信息为：' .mysqli_connect_error() . "\n";
        file_put_contents(LOG_PATH . '/'.$log_name, $message,FILE_APPEND);
    }
    if( !mysqli_set_charset($link,'utf8') ){
        $message = date('Y/m/d H:i:s') . '   数据库设置字符集失败，错误信息为：' .mysqli_error($link) . "\n";
        file_put_contents(LOG_PATH . '/'.$log_name, $message,FILE_APPEND);
    }


      	数据库的增删改操作，超过两条sql自动执行事务

    function addDelAlt(){
        global $link;
        $num = func_num_args();
        if( $num > 1 ){
            $arr = func_get_args();
            mysqli_query($link,'START TRANSACTION');
            foreach ($arr as $key => $value) {
                $res = mysqli_query($link,$value);
                if( !$res && mysqli_affected_rows($link) < 1 ){
                    mysqli_query($link,'rollback');
                    return false;
                }
            }
            mysqli_query($link,'commit');
            return true;
        }else if( $num == 0 ){
            return false;
        }else{
            $res = mysqli_query($link,func_get_arg(0));
        }

        if( $res && mysqli_affected_rows($link) >= 1 ){
            return true;
        }
        return false;
    }

     	数据库查询操作，返回结果，失败返回false

    function Select($sql){
        global $link;
        $res = mysqli_query($link,$sql);
        if( !$res ||  mysqli_affected_rows($link) <= 0  ){
            return false;
        }
        $arr = mysqli_fetch_all($res,MYSQLI_ASSOC);
        if( empty($arr) ){
            return false;
        }
        return $arr;
    }
*/


