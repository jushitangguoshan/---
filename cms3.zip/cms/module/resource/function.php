<?php
    header("content-type:text/html;charset=utf-8");

    $time=time();
//    $dl_name=$_SESSION['username'];
    $ip=$_SERVER['SERVER_ADDR'];
//    $login_id=$_SESSION['dl_id'];

    //判断用户状态
    function queryUserState($str){
        if($str===1){
            return "正常";
        }
        return "冻结";
    }
    //判断用户权限
    function queryUserRoot($str){
        if($str<100){
            return "普通用户";
        }else if( $str>=100 ){
            return "超级管理员";
        }
        return "无权限";
    }
    //判断是否是ajax请求
    function isAjax(){
        if( !(isset($_SERVER["HTTP_X_REQUESTED_WITH"]) && $_SERVER["HTTP_X_REQUESTED_WITH"]=='$_SERVER["HTTP_X_REQUESTED_WITH"]') ){
            return false;
        }
        return true;
    }

    //返回日志sql语句
    function putLogs($name,$id,$ope){//返回日志sql
        global $link;
        global $time;
        global $ip;
        $filePath=$_SERVER['SCRIPT_FILENAME'];//获取当前文件的绝对路径
        $message="ip:{$ip},用户名：{$name}在".date('Y-m-d H:i:s')."时{$ope},发生所在文件{$filePath}";
        $sql="insert into logs(message,`time`,user_id,opeteat,ip) values('{$message}','{$time}','{$id}','{$ope}','{$ip}')";
        mysqli_query($link,"set names utf8");//连接时设置写入数据编码
        return $sql;
    }
    /*-------------------------获取sql 查询到的数组-------------------*/
    function getMysqlArr($sql){//得到通过mysql查询的数组
        global $link;
        $res=mysqli_query($link,$sql);
        $arr=mysqli_fetch_all($res,MYSQLI_ASSOC);
        return $arr;
    }
    /*----------------------执行sql语句-（一条或多条:【多条则开启事务】）---------------------*/
    function addDelAlt(){//执行sql
        global $link;
        $num=func_num_args();//参数个数
        if( $num>1 ){
            $arr=func_get_args();//参数数组
            mysqli_query($link,"begin");//开启事务
            foreach ($arr as $key =>$value){
                $res=mysqli_query($link,$value);
                if(!$res || mysqli_affected_rows($link)<1){
                    mysqli_query($link,"collback");
                    return false;
                }
            }
            mysqli_query($link,"commit");
            return true;
        }else if($num==0){
            return false;
        }else{
            $res=mysqli_query($link,func_get_arg(0));
        }
        if(!$res || mysqli_affected_rows($link)<1){
            return false;
        }
        return true;
    }
    /*----------------------转义字符-----------------------------------*/
    function returnStr($str,$mark){//
        global $link;
        if($mark=='m'){//mysql转义字符
            $str= mysqli_real_escape_string($link,$str);
        }else if ($mark=='h'){//html
            $str=htmlspecialchars($str);
        }
        return $str;
    }
    /*--------------------查询变量是否存在空值------------------------------*/
    function isExistEmpty(){//
        $arr=func_get_args();//获取参数数组
        foreach ( $arr as $key => $value ){
            if( empty($value) ){
                return true;
            }
        }
        return false;
    }
    /*----------------------------图片处理------------------------------*/
    function headleImgArticle($img){
        $imgPath=$img['tmp_name'];
        $imgCont=imagecreatefromstring(file_get_contents($imgPath));
        $size=getimagesize($imgPath);
        $newImage=imagecreatetruecolor(780,220);//调整图片缩放
        $color=imagecolorallocatealpha($imgCont,0,250,0,0);
        imagefttext($imgCont,50,20,10,150,$color,"../../resource/fontchiness.ttf","远东水印");
        imagecopyresampled($newImage,$imgCont,0,0,0,0,780,220,$size[0],$size[1]);
        //判断文件存在

        $path="../../../uploads/".date('Y/m/d');
       // echo $path;die;
        if( !file_exists($path) ){
            mkdir($path,0777,true); //true:递归创建
        }
        $ti=time();
       // echo $path;die;
        imagejpeg($newImage,$path."/".$ti."_780x220.jpg");

        return $path."/".$ti."_780x220.jpg";
        //  imagejpeg($newImage);
    }
    /*---------------------------判断是否是图片格式*------------------*/
    function isImgArticle($img){
        if( in_array($img['type'],['image/jpeg','image/png']) ){
            return ture;
        }else{
            return false;
        }
    }
    /*---------------------------获取分类栏目(二维数组)----------------------*/
    function getColumnTree($list,$pk='id',$pid='p_id',$child='_child',$root=0){
        $tree=array();
        foreach($list as $key=> $val){
            if($val[$pid]==$root){  //获取当前$pid所有子类
                unset( $list[$key] );
                if( !empty($list) ){
                    $child=getColumnTree($list,$pk,$pid,$child,$val[$pk]);
                    if(!empty($child)){
                        $val['_child']=$child;
                    }
                }
                $tree[]=$val;
            }
        }
        return $tree;
    }


    /*--------------------------导入文章解析csv----------------*/
    function input_csv($handle) {
        $out = array ();
        $n = 0;
        while ($data = fgetcsv($handle, 10000)) {
            $num = count($data);
            for ($i = 0; $i < $num; $i++) {
                $out[$n][$i] = $data[$i];
            }
            $n++;
        }
        return $out;
    }
    /*--------------------------导出错误日志csv--------------*/
    function export_csv($filename,$data) {
        header("Content-type:text/csv");
        header("Content-Disposition:attachment;filename=".$filename);
        header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
        header('Expires:0');
        header('Pragma:public');
        echo $data;
    }


    //保存浏览历史记录
    function saveRecord(){
        if( isset( $_COOKIE['hist'] ) ){
            $url=$_COOKIE['hist'];//读取cookie
            $arr=unserialize($url);//将字符串内容转为数组
            $arr[]= $_POST['id'];;//获取当前url放到数组中
            $arr=array_unique($arr);//数组去重
            if( count($arr)>3 ){
                array_shift($arr);//移除数组第一个值
            }
            $krr=$arr;//-----------------临时存放数组--------------
            $url=serialize($arr);
            setcookie('hist',$url);
        }else{
            $url= $_POST['id'];;//将字符串内容转为数组
            $arr[]=$url;//获取当前url放到数组中
            $krr=$arr;//-----------------临时存放数组-----------------
            $url=serialize($arr);
            setcookie('hist',$url);
        }
        return $krr;
    }
//get到浏览历史数组
    function getHistArr($krr){
        if( count($krr)<1 ){
            return $mkk=[];
        }else if( count($krr)<2 ){
            $sql="select article_id,title from articles where article_id={$krr[0]}";
        }else if( count($krr)<3 ){
            $sql="select article_id,title from articles where article_id={$krr[0]} or article_id={$krr[1]}";
        }else{
            $sql="select article_id,title from articles where article_id={$krr[0]} or article_id={$krr[1]} or article_id={$krr[2]}";
        }
        $mkk=getMysqlArr($sql);
        return $mkk;
    }




































    //显示列表处理
    //    function showList($name,$geshu){//showList(表名,显示个数)
    //        global $link;
    //        $tableName=$name;
    //        $page=isset($_GET['page']) ? $_GET['page'] : 1;//当前页数
    //        $star=($page-1)*$geshu;//第一行开始的
    //        $res=mysqli_query($link,"SELECT * FROM  $tableName limit {$star},{$geshu}");
    //        $arr=mysqli_fetch_all($res,MYSQLI_ASSOC);//取出所以数据--array=【】
    //        return $arr;
    //    }
    //    //页码显示模块
    //    function showPage($sum,$showListNum,$pageGeshu){//showPage(总数，每页显示列表个数,显示的页码个数)
    //        $pageSum=ceil($sum/$showListNum);//总页数
    //        $page=isset($_GET['page']) ? $_GET['page'] : 1;//当前页数
    //        $html="";
    //        if($page<=1){
    //            $html .=" <span>首页</span> <span>上一页</span>";
    //        }else if($page>$pageGeshu){//当前页码大于页码个数
    //            $html .="  <a href='?page=1'>首页</a> <a href='?page=".($page-1)."'>上一页</a>";
    //            $html .=" <span>....</span>";
    //        }else{
    //            $html .="  <a href='?page=1'>首页</a> <a href='?page=".($page-1)."'>上一页</a>";
    //        }
    //
    //        if($pageSum<=$pageGeshu){//总页码小于 显示的页码个数)
    //            $start=1;
    //            $end=$pageSum;
    //        }else if($page<=$pageGeshu){//当前页数 小于 显示页码的个数
    //            $start=1;
    //            $end=$pageGeshu;
    //        }else{
    //            $start=$page-$pageGeshu+1;
    //            $end=$page;
    //        }
    //
    //        for($i=$start;$i<=$end;$i++){
    //            $temp=($i==$page)? 'curr' :'xxx';
    //            $html .= "<a href='?page={$i}' class='{$temp}' >{$i}</a>";
    //        }
    //
    //        if($page>=$pageSum ){//当前页码大于等于页码总数
    //            $html .=" <span>下一页</span> <span>尾页</span>";
    //        }else if($page<$pageSum &&  $pageSum>=$pageGeshu){ //当前页码小于等于页码总数 并 页码总数小于等于页码个数
    //            $html .=" <span>....</span>";
    //            $html .=" <a href='?page=".($page+1)."'>下一页</a>  <a href='?page={$pageSum}'>尾页</a> ";
    //        }else{
    //            $html .=" <a href='?page=".($page+1)."'>下一页</a>  <a href='?page={$pageSum}'>尾页</a> ";
    //        }
    //
    //        $html .= " <span><b>总页数【{$pageSum}】</b></span>";
    //        echo $html;
    //    }



    //获取栏目名字和id
    //    function getListName($arr,$level = 0){
    //        //$html = [];
    //        $html="";
    //        foreach ($arr as $key => $item) {
    //           // array_push($html,[$item['name'],$item['p_id']]);//查看输出的顺序
    //            if (isset($item['_child'])) {
    //                $html .="<option value='".$item['id']."'>{$item['name']}</option>";
    //                //array_push($html,getListName($item['_child'], $level + 1));
    //                $html .= getListName($item['_child'],$level+1);
    //            }else{
    //                for ($i=0;$i<$level;$i++){
    //                    $html .="<option value='".$item['id']."'>------{$item['name']}</option>";
    //                }
    //                if($level==0 && !isset($item['_child'])){
    //                    $html .="<option value='".$item['id']."'>{$item['name']}</option>";
    //                }
    //            }
    //        }
    //        return $html;
    //    }
    //获取栏目列表
    //    function getList($arr,$level = 0){
    //        $html = '';
    //        foreach ($arr as $key=>$item){
    //            $s=$key+1;
    //            //$html .= $item['name'].'<br>';//查看输出的顺序
    //            if( isset($item['_child']) ){
    //                $html .="<tr class = 'hover' >
    //                       <td class = 'center'>
    //                            <input type = 'text' class = 's-num' name = 'save[1][sort]' value = '{$s}'>
    //                       </td>
    //                       <td>
    //                            <input type = 'text' name = 'save[1][name]' value = '{$item['name']}'>
    //                       </td>
    //                       <td class = 'center'>
    //                            <a href = '#' class='jq-cp-edit'>编辑</a>
    //                            <a href = '#' class = 'jq-del'>删除</a>
    //                       </td>
    //                         <td class = 'jq-column-id_p' style='display:'>
    //                            {$item['p_id']}
    //                       </td>
    //                        <td class = 'jq-column-id' style='display:'>{$item['id']}</td>
    //                  </tr>";
    //                $html .= getList($item['_child'],$level+1);
    //                $html.=" <tr>
    //                              <td colspan='3'>
    //                                <i class='icon-sub-add'></i>
    //                                   <span class='jq-sub-add s-add' data-id='1'>
    //                                       <i class='icon-cross'></i><b>添加子栏目</b>
    //                                </span>
    //                            </td>
    //                         </tr>";
    //
    //            }else{
    //                for ($i=0;$i<$level;$i++){
    //                     // $html .= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nsbsp;';
    //                    $html .="<tr class='hover'>
    //                           <td class='center'>
    //                                <input type='text' class='s-num' name='save[13][sort]' value='<{$item['show_sort']}>'>
    //                           </td>
    //                           <td>
    //                                <i class='icon-sub'></i>
    //                                <input type='text' name='save[13][name]' value='{$item['name']}'>
    //                           </td>
    //                           <td class='center'>
    //                                <a href='#' class='jq-cp-edit'>编辑</a>
    //                                <a href='#' class='jq-del'>删除</a>
    //                           </td>
    //                              <td class = 'jq-column-id' style='display:'>
    //                                {$item['id']}
    //                           </td>
    //                             <td class = 'jq-column-id_p' style='display:'>{$item['p_id']}</td>
    //                           </tr>";
    //
    //
    //                }
    //
    //                if( $level == 0 ){
    //                    $html .="<tr class = 'hover'>
    //                            <td class = 'center'>
    //                                 <input type = 'text' class = 's-num' name = 'save[1][sort]' value = '{$s}'>
    //                            </td>
    //                            <td>
    //                                 <input type = 'text' name = 'save[1][name]' value = '{$item['name']}'>
    //                            </td>
    //                            <td class = 'center'>
    //                                 <a href = '#' class='jq-cp-edit'>编辑</a>
    //                                 <a href = '#' class = 'jq-del'>删除</a>
    //                            </td>
    //                               <td class = 'jq-column-id' style='display:'>
    //                                    {$item['p_id']}
    //                               </td>
    //                              <td class = 'jq-column-id_p' style='display:'>
    //                                    {$item['id']}
    //                              </td>
    //                       </tr>
    //                       <tr>
    //                          <td colspan='3'>
    //                            <i class='icon-sub-add'></i>
    //                               <span class='jq-sub-add s-add' data-id='1'>
    //                                   <i class='icon-cross'></i><b>添加子栏目</b>
    //                            </span>
    //                        </td>
    //                     </tr>";
    //                }
    //
    //            }
    //        }
    //        return $html;
    //    }
    //得到文章所属栏目
    //    function getArticBelongName($arr,$colId){
    //        foreach($arr as $key=>$value){
    //            if( $value['id'] == $colId){
    //                return $value['name'];
    //            }
    //        }
    //    }