<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:67:"D:\thinkphp5\mydemo1\public/../application/front\view\news\add.html";i:1551517442;s:63:"D:\thinkphp5\mydemo1\application\front\view\include\header.html";i:1551420331;s:63:"D:\thinkphp5\mydemo1\application\front\view\include\footer.html";i:1551420350;}*/ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>新闻发布系统</title>
<link rel="stylesheet" href="/static/front/css/style.css" />
</head>
<body>
<div class="box">
	<div class="top">
		<div class="title">新闻发布系统</div>
		<div class="nav">
			<a href="http://www.tp5demo1.com/index.php/front/home/index">返回列表</a>
		</div>
	</div>
	<div class="main">
		<form action="<?php echo url('news/addNews'); ?>" method="post">
			<table class="news-edit">
				<tr>
					<th>新闻标题：</th>
					<td><input type="text" name="bbs_title" placeholder="填写新闻标题..." /></td>
				</tr>
				<tr>
					<th>新闻内容：</th>
					<td><textarea name="bbs_content" placeholder="填写新闻内容..."></textarea></td>
				</tr>
				<tr>
					<th>验证码：</th>
					<td> ><img src="<?php echo captcha_src(); ?>" alt="captcha" onclick="(this).src=(this).src"/> <input type="text" name="yzm" style="width:100px;" /></td>
				</tr>
				<tr>
					<th></th>
					<td><input type="submit" value="发布新闻" /></td>
				</tr>
			</table>
		</form>
	</div>
<div class="footer">
		页面底部 
	</div>
</div>
</body>
</html>
