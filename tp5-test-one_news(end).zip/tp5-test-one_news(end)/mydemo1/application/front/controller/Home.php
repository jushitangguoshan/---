<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/1 0001
     * Time: 上午 10:50
     */
    namespace app\front\controller;

    class Home extends \think\Controller
    {
        public function index()
        {
            #动态修改 页码配置 本页面临时调用
            \think\Config::set('paginate',[
                'type'      => 'mypage',
                'var_page'  => 'page',
                'list_rows' => 15]);
            #查询列表数据
            $data = \think\Db::name('news')->where('status',1)->paginate(5);
            // 获取分页显示
            $page = $data->render();
            // 模板变量赋值
            $this->assign('list', $data);
            $this->assign('page', $page);
            return $this->fetch();
        }
    }