<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/1 0001
     * Time: 上午 11:19
     */

    namespace app\front\controller;
    use think\Controller;
    class News extends Controller
    {
        #发布新闻
        public function add()
        {
            return $this->fetch('add');
        }
        #编辑新闻
        public function edit()
        {
            #获取id
            $id=input()['id'];
            #通过  --id--  数据库查询
            $data=\think\Db::name('news')->where('id',$id)->find();
            #页面设置变量 list
            $this->assign('list', $data);
            return $this->fetch('edit');
        }
        #浏览新闻
        public function show()
        {
            #获取id
            $id=input()['id'];
            #通过  --id--  数据库查询
            $data=\think\Db::name('news')->where('id',$id)->find();
            $this->assign('list', $data);
            return $this->fetch('show');
        }
        #------------发布新闻
        public function addNews()
        {
            #判断是否是正确的请求类型
            if( !(\think\Request::instance()->isPost()) )exit;
            #过滤非数据库字段数据 并且获取有用其他数据
            $data = \think\Request::instance()->except('yzm','post');
            #数据校验  title》2个字 & 《6个字 content/title 不能为空
            $validata = new \app\front\newsValidate\NewsValidate();
            if(  !$validata->check($data) ){
                $this->error('新增失败--->'.$validata->getError());
            }
            #判断验证码
            if(!captcha_check($_POST['yzm'])){
                $this->error('验证码输入错误');
            };
            #添加数据到数据库
            $res= \think\Db::name('news')->insert($data);
            #获取sql语句 \think\Db::name('news')->fetchSql()->insert($data);
            if( !$res ){
                $this->error('新增失败');
            }
            $this->success('新增成功','News/add');
        }
        #-----------编辑新闻
        public function editNews()
        {
            #判断是否是正确的请求类型
            if( !(\think\Request::instance()->isPost()) )exit;
            #获取数据
            $data = \think\Request::instance()->post();
            #更新数据到数据库
            $res= \think\Db::name('news')->update($data);
            #获取sql语句 \think\Db::name('news')->fetchSql()->insert($data);
            if( !$res ){
                $this->error('修改失败');
            }
            $this->success('修改成功','home/index');
        }
        #-----------删除一条新闻
        public function delNew()
        {
            #获取删除的新闻 id
            $id=input()['id'];
            #数据库删除操作  -[获取删除sql]-$sql=\think\Db::name('news')->where('id',$id)->fetchSql->delete();
            $res = \think\Db::name('news')->where('id',$id)->delete();
            #结果判断
            if( !$res ){
                $this->error('删除失败');
            }
            $this->success('删除成功',"home/index");
        }
        #----------批量删除新闻
        public function delNews()
        {
            #请求判断
            if( !(\think\Request::instance()->isPost()) ) exit;
            #获取一组数据
            $idArr=\think\Request::instance()->post();
            #数据库操作----删除
            $res = \think\Db::name('news')->delete($idArr['id']);
            #结果判断
            if( !$res ){
                $this->error("批量删除失败");
            }
            $this->success("批量删除成功","home/index");
        }
    }