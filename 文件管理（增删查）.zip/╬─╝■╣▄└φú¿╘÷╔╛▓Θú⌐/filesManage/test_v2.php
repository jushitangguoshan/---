<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>test_v2_php</title>
</head>
<body>
	<?php
		$dir="C:\Users\Administrator\Desktop\xxxx/";
		$dh=opendir($dir);
	?>
	<table border=1>
		<tr>
			<td>文件名</td>
			<td>文件大小</td>
			<td>文件类型</td>
			<td>创建时间</td>
		</tr>
		<?php	while( ($fileName=readdir($dh)) !== false){	if($fileName=="."||$fileName=="..")continue;?>
		<tr>
			<td><?php echo iconv("GBK","UTF-8",$fileName); ?></td>
			<td><?php echo filesize($dir.$fileName);?></td>
			<td><?php echo  iconv("gb2312","UTF-8",filetype($dir.$fileName))?></td>
			<td><?php echo date("Y-m-d H:i:s",filemtime($dir.$fileName))?></td>
			
			<td><?php 
				if( is_dir($dir.$fileName) ){
					echo "<a href=?>打开</a>";
				}else if(is_writable($dir.$fileName)){
					echo "<a href=?>编辑</a>";
				}
			?></td>
		</tr>
		<?php	}   ?>
		
	</table>
</body>
</html>