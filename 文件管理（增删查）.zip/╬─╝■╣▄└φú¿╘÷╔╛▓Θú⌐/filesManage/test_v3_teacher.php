<?php
	header("content-type:text/html;charset=utf-8");
	judge();
	function judge(){
		$path=(isset($_GET['path'])) ? $_GET['path'] :__DIR__;//判断path 是否存在                当前路径
	    if(isset($_GET['ope']) && $_GET['ope']=='del'){
	     	delFile($_GET['path']);
	     	$path=dirname($_GET['path']);
	     }  
	    if(isset($_POST['ope']) && $_POST['ope']=='Cfile'){
	     	createFile($path);
	     }  
	     display($path);
	}
    function display($path){
		$fileArr=scandir($path);//获取当前路径下的目录(返回数组方式)
		$html='
			<h1>当前文件路径：'.$path.'</h1>
			<h3><a href=?path='.dirname($path).'>返回上一目录</a></h3>
			<table border=1>
			<tr>	<td>文件名字</td>
					<td>文件大小</td>
					<td>文件类型</td>
					<td>文件创建时间</td>
					<td>操作</td>  		</tr>';//dirname($path)返回当前路径的上一级路径下的目录
		foreach($fileArr as $fileName){
			if(in_array($fileName,['.','..']))continue;
			$filePath=$path."/".$fileName;
			$html .='
					<tr>
					<td>'.$fileName.'</td>
					<td>'.getSize(returnSize($filePath)).'</td>
					<td>'.isFile($filePath).'</td>
					<td>'.date("Y-m-d H:i:s",filectime($filePath)).'</td>
					<td>'.opeat($filePath).'</td>
				</tr>
			';
		}
		$html .='</table>';
		$html .='
			<form action="?path='.$path.'" method="post">
				新建文件：<input type="text" name="fileName">
						<input type="hidden" name="ope" value="Cfile">
				<button>确定提交</button>
			</form>
		';
		echo $html;
    }    
    //新建文件
	function createFile($path){
	    	$fileName=$_POST['fileName'];
	    	if(!isset(pathinfo($fileName)['extension'])) echo  "文件名后缀输入错误！";
	    	else if( !(in_array( strtolower(pathinfo($fileName)['extension']),['html','txt','php'])) ){
	    		echo  "文件名输入错误！";
	    	}else fopen($path."/".$fileName,"w");
	}   
	//判断文件类型
	function isFile($filePath){
		$type=filetype($filePath);
		if($type=='dir')return "文件夹";
		if($type=='file'){
			if(!isset(pathinfo($filePath)['extension']))return "文件";
			//pathinfo($filePath)['extension']获取当前路径文件后缀
			if(in_array(strtolower(pathinfo($filePath)['extension']),['jpg','png','gif','bmp']))return "图片";
			else return "文件";
		}
	}
	//获取大小
	function returnSize($path){
		$sum=0;
		if( !(file_exists($path)) )return "文件名错误";
		if(is_dir($path)){
			$fileArr=scandir($path);
			foreach($fileArr as $value){
				if(in_array($value,['.','..']))continue;
				if(is_dir($path."/".$value)) $sum+=returnSize($path."/".$value);
				else $sum+=filesize($path."/".$value);
			}
		}else{
			$sum +=filesize($path);
		}
		return $sum;
	}
	//转换大小单位
	function getSize($size){
		$k='';
		if($size<pow(2,10)) $k= ($size).'b';
		else if($size<pow(2,20)) $k= round(($size/pow(2,10)),2).'kb';
		else if($size<pow(2,30)) $k= round(($size/pow(2,20)),2).'mb';
		else if($size<pow(2,40)) $k= round(($size/pow(2,30)),2).'gb';
		return $k;
	}
	//操作
	function opeat($filePath){
		$html='';
		$type=isFile($filePath);
		switch($type){
			case '文件夹':
				$html .= '<a href="?path='.$filePath.'">打开 </a>';
				break;
			case '文件':
				$html .= '<a href="test_v3_teacher_alt.php?path='.$filePath.'">编辑 </a>';
				break;
			case '图片':
				$html .= '<a href="test_v3_teacher_img.php?path='.$filePath.'">查看 </a>';
				break;
		}
		$html .= '<a href="?ope=del&path='.$filePath.'">删除</a>';
		return $html;
	}
	//删除文件
	function delFile($path){
		if(!file_exists($path)) return "文件不存在";
		if(is_dir($path)){
			$fileKrr=scandir($path);
			foreach($fileKrr as $file){
				if($file=="." || $file=="..") continue;
				if(is_dir($path.'/'.$file)) delFile($path.'/'.$file);
				else unlink($path.'/'.$file);
			}
			rmdir($path);
		}else unlink($path);
	}





