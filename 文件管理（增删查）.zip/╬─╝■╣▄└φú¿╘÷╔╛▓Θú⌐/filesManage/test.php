<?php
	header('content-type:image/jpeg');
	$path='D:\wamp\www\filesManage/pict_two.jpg';
	$file=fopen($path,"r");
	$cont=fread($file,filesize($path));
	fclose($file);
	echo $cont;
	echo "<button>fanhui</button>";
