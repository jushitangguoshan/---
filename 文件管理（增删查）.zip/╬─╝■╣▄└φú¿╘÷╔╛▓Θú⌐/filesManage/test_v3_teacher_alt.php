<?php 
	if(isset($_POST['text'])){
		//file_put_contents($_GET['path'],$_POST['text']);
		$path=$_GET['path'];
		$handl=fopen($path,'w');
		fwrite($handl,$_POST['text']);
		fclose($handl);
		header("location:test_v3_teacher.php?path=".dirname($_GET['path']));
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<form action="?path=<?php echo $_GET['path'];?>" method='post'>
		<textarea name="text"  cols="30" rows="10"><?=htmlentities(iconv("GBK","UTF-8",file_get_contents($_GET['path'])))?></textarea>
		<button>确定</button>
	</form>
	
</body>
</html>