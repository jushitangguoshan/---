<?php

	opeate();
	function opeate(){
		if(isset($_GET['fileLj'])){//保存
			$cont=$_GET['fileLj'];
			$filename=$_GET['ope'];
			file_put_contents($filename,$cont);
			$directoyr=dirname($filename);
			display($directoyr);
		}else if( !isset($_GET['name']) && !isset($_GET['ope']) ){
			display(__DIR__);
		}else if(isset($_GET['name']) && $_GET['ope']=='see'){//查看
			$name=$_GET['name'];
			echo $name;
			echo "<br>";
			echo "<img src='".$name."'>";
		}else if(isset($_GET['name']) && $_GET['ope']=='open'){//打开文件
			$name=$_GET['name'];
			display($name);
		}else if(isset($_GET['name']) && $_GET['ope']=='edit'){//编辑
			$name=$_GET['name'];
			$conts=file_get_contents($name);
			echo "<form action=''><textarea rows=10 cols=100 name='fileLj'>";
			echo $conts;
			echo "</textarea><br>";
			echo "<input type='submit' >";
			echo "<input type='hidden' name='ope' value=$name>";
			echo "</form>";
			//$handle = fopen($name, "r"); while (!feof($handle)){ $text = fgets($handle); echo $text;}
		}else if(isset($_GET['name']) && $_GET['ope']=='del'){//删除
			$name=$_GET['name'];
			$directoyr=dirname($name);
			if(is_dir($name)){
				rmdir($name);
			}else{
				unlink($name);
			}
			display($directoyr);
		}
	}
	function display($posi){
		$dh=opendir($posi);
		echo "<h1>当前文件路径".$posi."</h1>";
		echo "<table border=1>";
		while( ($fileName=readdir($dh)) !== false){
			if($fileName=="." || $fileName=="..")continue;
			echo  "<tr>";
			echo "<td>".iconv("GBK","UTF-8",$fileName)."</td>";
			echo "<td>".filesize($posi."/".$fileName)."</td>";
			echo "<td>".iconv("UTF-8","GB2312",filetype($posi."/".$fileName))."</td>";
			echo "<td>".date("Y-m-d H:i:s", filemtime($posi."/".$fileName))."</td>";
			if(ISimgs($posi."/".$fileName)){
				echo "<td><a href='?ope=see&name=$posi\\$fileName'>查看</td>";
			}else if(filetype($posi."/".$fileName)=='dir'){
				echo "<td><a href='?ope=open&name=$posi\\$fileName'>打开</td>";
			}else{
				echo "<td><a href='?ope=edit&name=$posi\\$fileName'>编辑</td>";
			}
			echo "<td><a href='?ope=del&name=$posi\\$fileName'>删除</td>";
			echo  "</tr>";
		}
		echo "</table>";
	}
	function ISimgs($name){
		$get= pathinfo($name);
		@$last=$get['extension'];
		$pictArr=['jpg','png','JPG','PNG','gif','GIF'];
		if(in_array($last,$pictArr)){
			return true;
		}else{
			return false;
		}
		
	}
?>