<?php
	header('content-type:image/jpeg');
	$path=$_GET['path'];
	$file=fopen($path,"w+");
	$cont=fread($file,filesize($path));
	fclose($file);
	echo $cont;
