<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/27 0027
     * Time: 上午 10:34
     */
    namespace application\frontend\controller;
    class Home extends \framework\Controller
    {
        public function index()
        {
            $this->render();
        }
        public function lists()
        {
            $this->render();
        }
    }
