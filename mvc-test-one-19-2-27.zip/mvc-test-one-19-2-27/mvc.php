<?/*
# 一、完成目录结构
 - application
   - frontend(项目前台)
        - controller
			- Message.php
			- Home.php
		- view	
	        - message
				- index.html
				- add.html
			- home
				- index.html
				- aboutus.html
   - backend(项目后台)
 - framework
    - Loading.php
    - Error.php
 - index.php

# 二、定义主入口
1、定义编码格式
2、引入框架核心文件Loading
3、运行Loading中的静态方法start

# 三、错误处理、异常处理
添加Error.php在framework 定义 错误处理 shutdown处理 以及异常处理


# 四、Loading 里定义自动加载 load
   - 注意命名空间
   - 注意Unix兼容
   
# 五、框架初始化配置 init
   - 定义时区
   - 定义默认控制器 命名空间
   - 处理请求参数  param
   - 请求分发 dispatch
   
# 六、准备控制器测试
http://www.study.com/index.php?m=frontend&c=home&a=index

输出：'hello world!'

# 七、准备视图文件 
给index方法 添加视图文件index.html、list.html
分别渲染render视图index.html、list.html



