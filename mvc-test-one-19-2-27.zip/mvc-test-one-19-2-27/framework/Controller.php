<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/27 0027
     * Time: 上午 10:57
     */
    namespace framework;
    class Controller
    {
        private $_view;
        public function __construct()
        {
            $this->_view = new View();
        }
        public function __call($method,$args)
        {
            if( is_callable([$this->_view,$method]) ){
                return call_user_func([$this->_view,$method],$args);
            }
        }
    }