<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/27 0027
     * Time: 上午 10:32
     */
    namespace framework;
    class Loading
    {
        //echo test--->index.php?m=frontend&c=Message&a=index;
        public static function start()
        {
            #自动加载
            spl_autoload_register([__CLASS__,"load"]);

            #错误异常处理
            ini_set("display_errors",1);
            error_reporting(E_ALL);
            \framework\Error::start();

            #自定义常量
            self::initConst();
            #获取get参数分发页面
            self::distribute();
        }
        public static function load($fileName)
        {
            $fileName=$fileName.".php";
            $fileName=str_replace("\\","/",$fileName);
            //echo $fileName,'<hr>';
            require_once $fileName;
        }
        #分发页面
        private static function distribute()
        {
            $c=CONTROLLER."\\".Request::getinstance()->class;
            $a=Request::getinstance()->method;
            //echo "1---->",$c,"--->",$a,"<hr>";
            if( !class_exists($c) ){
                echo ("没有该类"),"<hr>";
                throw new \framework\ErrorException("没有该类");
            }
            if( !is_callable([$c,$a]) ){
                echo ("该类无法被调用"),"<hr>";
                throw new \framework\ErrorException("该类无法被调用");
            }
          //  echo "2---->",$c,"--->",$a,"<hr>";
            return ( new $c() )->$a();
        }
        #初始化常量
        private static function initConst()
        {
            define("ROOT_PATH","\\");
            define("DS",DIRECTORY_SEPARATOR);
            define("APPLICATION",ROOT_PATH."application");
            define("FRONTEND",APPLICATION.DS."frontend");
            define("CONTROLLER",FRONTEND.DS."controller");
            define("VIEW",FRONTEND.DS."view");
            define("HOME",VIEW.DS."home");
            define("MESSAGE",VIEW.DS."message");
        }
    }