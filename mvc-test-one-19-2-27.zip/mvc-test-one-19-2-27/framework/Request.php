<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/27 0027
     * Time: 上午 10:57
     */
    namespace framework;
    class Request
    {
        private static $_instance=null;

        public $pageType;#前台还是后台--frontend or backend
        public $class;#哪个具体类型---类名 ...
        public $method;#具体html 页面方法名字
        private function __clone(){}
        private function __construct()
        {
            $this->pageType = isset($_GET['m']) && !empty($_GET['m']) ? $_GET['m'] : "frontend" ;
            $this->class = isset($_GET['c']) && !empty($_GET['c']) ? ucfirst(strtolower($_GET['c'])) : "Home" ;
            $this->method = isset($_GET['a'])  && !empty($_GET['a']) ? $_GET['a'] : 'index';
        }
        public static function getinstance()
        {
            if( self::$_instance==null ){
                self::$_instance = new self();
            }
            return self::$_instance;
        }
    }