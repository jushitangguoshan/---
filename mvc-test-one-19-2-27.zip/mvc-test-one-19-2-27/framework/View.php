<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/27 0027
     * Time: 上午 10:57
     */
    namespace framework;
    class View
    {
        public function render()
        {
            $file=APPLICATION.DS.Request::getinstance()->pageType.DS."view".DS.Request::getinstance()->class.DS.Request::getinstance()->method.".html";
            $file=str_replace("\\","/",$file);
           // echo $file;die;
            include_once  $file;
        }
    }