<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/27 0027
     * Time: 上午 10:32
     */
    header("content-type:text/html;charset=utf-8");
    require_once "framework/Loading.php";
    \framework\Loading::start();