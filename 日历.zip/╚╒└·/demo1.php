<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<style type="text/css">
		.box{
			margin: 7px;
			background-color: pink;
		}
		.mark{
			background-color: yellow;
		}
		div{
			border: 1px solid #000;
			width: 240px;
			height: 450px;
			margin: 0 auto;
			padding: 25px;
		}
		h2{
			color:red;
			margin-left: 80px;
		}
		pre{
			font-size: 13px;
			margin-left: 10px;
		}
	</style>
</head>
<body>
	<div>
		<h2>万年历</h2>
		<p>标准时间：<?php echo date("Y-m-d H:t:s")?></p>
		<pre>日   一   二   三   四   五   六</pre>	
		<?php
			function show($date){
				$year = date_format($date,"Y"); //获取年份
				$month = date_format($date,"m");//获取月分
				$day = date_format($date,"d");//获取日期
				$countDay = date_format($date,"t");//获取该月总天数
				date_date_set($date,$year,$month,1);//设置成一号
				$fristDay = date_format($date,"w");//获取该月一号是星期几
				$mark = false;
				for($i = 1; $i <= $countDay+$fristDay; $i++){
					if($day == $i){
						echo "<span class='mark box'>".($i-$fristDay)."</span>";
						continue;
					}
					if($i <= $fristDay){
						echo "<span>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>";
						continue;
					}
					if($i-$fristDay <= 9){
						echo "<span class='box'>0".($i-$fristDay)."</span>";
					}else{
						echo "<span class='box'>".($i-$fristDay)."</span>";
					}
					if($i%7 == 0){
						echo "<br><br>";
					}
				}
				date_date_set($date,$year,$month,$day); //重新设置时间
			}
			function operat(){
				$pair = pair();
				if(isset($_GET["act"])){
					$nowDate = $_GET["act"];
				}else{
					$nowDate = null;
				}
				$date = date_create($nowDate);
				$year = date_format($date,"Y"); //获取年份
				$month = date_format($date,"m");//获取月分
				$day = date_format($date,"d");//获取日期
				switch ($pair) {
					case 'ageYear':
						date_date_set($date,$year-1,$month,$day);
						break;
					case 'ageMonth':
						date_date_set($date,$year,$month-1,$day);
						break;
					case 'ageDay':
						date_date_set($date,$year,$month,$day-1);
						break;
					case 'nextYear':
						date_date_set($date,$year+1,$month,$day);
						break;
					case 'nextMonth':
						date_date_set($date,$year,$month+1,$day);
						break;
					case 'nextDay':
						date_date_set($date,$year,$month,$day+1);	
						break;					
				}
				show($date);
				return date_format($date,"Y-m-d");			
			}
			function pair(){
				$name = "";
				if(isset($_GET["ageYear"])) $name = "ageYear";
				if(isset($_GET["ageMonth"])) $name = "ageMonth";
				if(isset($_GET["ageDay"])) $name = "ageDay";
				if(isset($_GET["nextYear"])) $name = "nextYear";
				if(isset($_GET["nextMonth"])) $name = "nextMonth";
				if(isset($_GET["nextDay"])) $name = "nextDay";
				return $name;
			}
			$aa = operat();
		?>	
		<p>当前时间：<?php echo $aa?></p>
		<form action="">
			<input type="submit" value="上一年" name="ageYear">
			<input type="submit" value="上一月" name="ageMonth">
			<input type="submit" value="上一日" name="ageDay"><br>
			<input type="submit" value="下一年" name="nextYear">
			<input type="submit" value="下一月" name="nextMonth">
			<input type="submit" value="下一日" name="nextDay">
			<input type="hidden" name="act" value="<?php echo $aa?>">
		</form>
	</div>
</body>
</html>