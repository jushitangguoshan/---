<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/6 0006
     * Time: 下午 3:02
     */

    namespace app\common\module;


    use think\Model;

    class ArticleKeywordRelation extends Model
    {
        protected $autoWriteTimestamp=false;
    }