<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/6 0006
     * Time: 下午 7:32
     */

    namespace paginate;
    use think\Paginator;

    class BackendPage extends Paginator
    {
        public function render(){

            ' <span>首页</span><span>上一页</span>-->
          <a href="?page=1" class="curr">1</a>-->
          <a href="?page=2">2</a><a href="?page=2">下一页</a>
          <a href="?page=2">尾页</a>';


            $frist='<a href="?page=1">首页</a>';
            if( $this->currentPage() <= 1){
                $frist="<span>首页</span>";
            }
            $end='<a href="?page='.$this->lastPage().'">尾页</a>';
            if( !$this->hasMore ){
                $end="<span>尾页</span>";
            }
            //          [1/3] 首页 上btns下  尾页
            $str="当前为 %s/%s  %s  %s %s %s  %s";
            return sprintf($str,
                $this->currentPage(),
                $this->lastPage,
                $frist,
                $this->getPreviousButton(),
                $this->getPageBtn(),
                $this->getNextButton(),
                $end
            );
        }
       // 获取中间的数字页码按钮
        protected function getPageBtn()
        {
            $start=1;//---循环开始
            $last=$start+2;//----循环结束-----总共显示3个页码按钮
            #当前页
            $page = $this->currentPage();
            #最后一页
            $end = $this->lastPage;

            if($page-1<=0){//----显示的第一个的页码数
                $start=1;
            }else{
                $start=$page-1;
            }
            if($end<=3){//-----显示的最后一个页码数
                $last=$end;
            }else if($page+1>=$end){//--当前页+1 》= 最后一页
                $last=$end;
                $start=$end-2;
            }else{
                $last=$start+2;
            }
            $html='';
            if($start>1) $html.='....';
            for( $i=$start ;$i<=$last ;$i++ ){
                $html .=($i===$page)
                    ? '<a href="?page='.$i.'" class="curr">'.$i.'</a>'
                    : '<a href="?page='.$i.'" class="">'.$i.'</a>';

            }
            if($last<$end) $html .='....';
            return $html;
        }





        /**
         * 首页按钮
         * @param string $text
         * @return string
         */
        protected function getFristButton($text = "<span>尾页</span>")
        {
            if ($this->currentPage() <= 1) {
                return $text;
            }
            $url = $this->url($this->currentPage() - 1);
            return "<a href='". htmlentities($url) . "'>". $text ."</a>";
        }
        /**
         * 上一页按钮
         * @param string $text
         * @return string
         */
        protected function getPreviousButton($text = "上一页")
        {
            if ($this->currentPage() <= 1) {
                return $text;
            }
            $url = $this->url($this->currentPage() - 1);
            return "<a href='". htmlentities($url) . "'>". $text ."</a>";
        }
        /**
         * 下一页按钮
         * @param string $text
         * @return string
         */
        protected function getNextButton($text = '下一页')
        {
            if (!$this->hasMore) {
                return $text;
            }
            $url = $this->url($this->currentPage() + 1);
            return "<a href='". htmlentities($url) . "'>". $text ."</a>";
        }


    }