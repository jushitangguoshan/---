<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/22 0022
     * Time: 下午 3:09
     */
    namespace error;

    class DaseException extends \Exception
    {
        public function __construct($msg="",$code="")
        {
            $this->message= empty($msg) ? $this->message : $msg;
            $this->errCode= empty($code) ? $this->errCode : $code;
        }
        public function JsonHandle()
        {
            header("HTTP/1.1 200 OK");
            header("content-type:application/json;charset=utf-8");
            return json_encode(['errCode'=>$this->errCode,'message'=>$this->message]);
        }
    }