<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:68:"D:\thinkphp5\mydemo1\public/../application/front\view\news\show.html";i:1551488659;s:63:"D:\thinkphp5\mydemo1\application\front\view\include\header.html";i:1551420331;s:63:"D:\thinkphp5\mydemo1\application\front\view\include\footer.html";i:1551420350;}*/ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>新闻发布系统</title>
<link rel="stylesheet" href="/static/front/css/style.css" />
</head>
<body>
<div class="box">
	<div class="top">
		<div class="title">新闻发布系统</div>
		<div class="nav">
			<a href="http://www.tp5demo1.com/index.php/front/home/index">返回列表</a>
		</div>
	</div>
	<div class="main">
		<!-- 新闻标题 -->
		<div class="news-title"><?php echo $list['bbs_title']; ?></div>
		<!-- 发布时间 -->
		<div class="news-time"><?php echo date("Y-m-d H:i:s",$list['add_time']); ?></div>
		<!-- 新闻内容 -->
		<div class="news-content"><?php echo $list['bbs_content']; ?></div>
	</div>
<div class="footer">
		页面底部 
	</div>
</div>
</body>
</html>
