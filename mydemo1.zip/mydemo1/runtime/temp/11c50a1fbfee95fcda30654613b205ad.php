<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:68:"D:\thinkphp5\mydemo1\public/../application/front\view\news\edit.html";i:1551489444;s:63:"D:\thinkphp5\mydemo1\application\front\view\include\header.html";i:1551420331;s:63:"D:\thinkphp5\mydemo1\application\front\view\include\footer.html";i:1551420350;}*/ ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>新闻发布系统</title>
<link rel="stylesheet" href="/static/front/css/style.css" />
</head>
<body>
<div class="box">
	<div class="top">
		<div class="title">新闻发布系统</div>
		<div class="nav">
			<a href="http://www.tp5demo1.com/index.php/front/home/index">返回列表</a>
		</div>
	</div>
	<div class="main">
		<form method="post" action="<?php echo url('news/editNews'); ?>">
			<table class="news-edit">
				<input type = "hidden" name = "id" value="<?php echo $list['id']; ?>">
				<tr>
					<th>新闻标题：</th>
					<td><input type="text" name="bbs_title" value="<?php echo $list['bbs_title']; ?>" /></td>
				</tr>
				<tr>
					<th>新闻内容：</th>
					<td><textarea name="bbs_content"><?php echo $list['bbs_content']; ?></textarea></td>
				</tr>
				<tr>
					<th></th>
					<td><input type="submit" value="修改新闻" /></td>
				</tr>
			</table>
		</form>
	</div>
<div class="footer">
		页面底部 
	</div>
</div>
</body>
</html>
