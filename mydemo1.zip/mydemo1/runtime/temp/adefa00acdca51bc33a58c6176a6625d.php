<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:69:"D:\thinkphp5\mydemo1\public/../application/front\view\home\index.html";i:1551535940;s:63:"D:\thinkphp5\mydemo1\application\front\view\include\footer.html";i:1551420350;}*/ ?>
<!doctype html>
<html>
<head>
	<meta charset="utf-8">
	<title>新闻发布系统</title>
	<link rel="stylesheet" href="/static/front/css/style.css" /><!--/static/front/bootstrap/css/bootstrap.css-->
	<link rel="stylesheet" href="" />
</head>
<body>
<div class="box">
	<div class="top">
		<div class="title">新闻发布系统</div>
		<div class="nav">
			<a href="<?php echo url('news/add'); ?>">发表新闻</a>
		</div>
	</div>
	<div class="main">
		<form method="post" action="<?php echo url('news/delNews'); ?>">
			<table class="news-list" >
				<tr id="new-list-th">
					<th ">新闻标题</th>
					<th width="250" >发布时间</th>
					<th width="200" >操作</th>
				</tr>
				<?php foreach($list as $val): ?>
				<tr>
					<td class="news-list-title">
						<input type="checkbox" name="id[]" value="<?php echo $val['id']; ?>" />
						<a href="<?php echo url('news/show',['id'=>$val['id']]); ?>"  target="_blank"><?php echo $val['bbs_title']; ?></a>
					</td>
					<td class="center"><?php echo date("Y-m-d H:i:s",$val['add_time']); ?></td>
					<td class="center">
						<a href="<?php echo url('news/edit',['id'=>$val['id']]); ?>">编辑</a>　
						<a href="<?php echo url('news/delNew',['id'=>$val['id']]); ?>" onclick="return confirm('确定要删除该新闻吗？');">删除</a>
					</td>
				</tr>
				<?php endforeach; ?>
			</table>
			<div class="action">
				<button id="checkAll">全选</button>
				<button id="checkReverse">反选</button>
				<input type="submit" value="批量删除" />
			</div>
		</form>
		<!-- 输出分页链接-->
		<div class="pagelist"><?php echo $page; ?></div>
	</div>
</div>
	<div class="footer">
		页面底部 
	</div>
</div>
</body>
</html>

<script>


//全选
document.getElementById("checkAll").onclick = function(){
	var ids = document.getElementsByName("id[]");
	for(var i in ids){
		ids[i].checked = true;
	}
	return false;
};
//反选
document.getElementById("checkReverse").onclick = function(){
	var ids = document.getElementsByName("id[]");
	for(var i in ids){
		ids[i].checked = !ids[i].checked;
	}
	return false;
};
</script>
