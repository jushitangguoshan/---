<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/2 0002
     * Time: 上午 10:35
     */

    namespace app\front\newsValidate;


    class NewsValidate extends \think\Validate
    {
        protected $rule=[//定义规则和提示
            ['bbs_title',"require|min:2|max:20|checkName",
              "新闻标题不能为空 | 新闻标题最少2个字|新闻标题最多不超过6个字|标题不能包含敏感词汇"],
            ['bbs_content',"require",
                "新闻内容不能为空"]
            ];
        // 自定义验证规则
        protected function checkName($value)
        {
            $rule=['毒品','台独'];
            foreach($rule as $val ){
                if( preg_match_all("/$val/",$value) ){
                    return false;
                }
            }
            return true;
        }
    }