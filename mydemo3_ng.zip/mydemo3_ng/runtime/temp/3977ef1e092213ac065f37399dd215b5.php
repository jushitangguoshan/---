<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:76:"D:\thinkphp5\mydemo2\public/../application/admin\view\module\cp_article.html";i:1551784269;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>后台</title>
		<link rel="stylesheet" href="/static/admin/css/dashicons.css">
		<link rel="stylesheet" href="/static/admin/css/style.css">
		<script src="/static/admin/js/jquery.js"></script>
	</head>
	<body>
	<div class="wrap wrap-article">
		<h1>文章管理</h1>
		<div class="s-nav">
			<div><form method="post" action="<?php echo url('module/screening'); ?>">
				<select name="art_classId">
					<option value="0">所有栏目</option>
					<?php if(is_array($colList) || $colList instanceof \think\Collection || $colList instanceof \think\Paginator): $i = 0; $__LIST__ = $colList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$col): $mod = ($i % 2 );++$i;?>
					<option value="<?php echo $col['id']; ?>" ><?php echo $col['col_name']; ?></option>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</select>
				<input type="submit" value="筛选">
			</form></div>
			<div><form method="post" action="<?php echo url('module/timeScreen'); ?>">
				<select name="order">
					<option value="time-asc"  >时间升序</option>
					<option value="time-desc"  >时间降序</option>
					<option value="show-desc"  >发布状态</option>
				</select>
				<input type="submit" value="排序">
			</form></div>
			<div><form method="post" action="<?php echo url('module/likeScreen'); ?>">
				<input type="text" name="search" value="" placeholder="输入关键字"><input type="submit" value="搜索文章">
			</form></div>
		</div>
		<div class="tips"></div>
		<div class="box">
			<div class="box-body">
				<table>
					<tr>
						<th width="80">状态</th><th>文章标题</th><th width="120">所属栏目</th><th width="100">作者</th><th width="150">创建时间</th><th width="100">操作</th>
					</tr>
					<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$art): $mod = ($i % 2 );++$i;?>
						<tr>
						<td class="s-show"><i class="icon-yes">已发布</i></td>
						<td class="s-title"><a href="../show.php?id=<?php echo $art['id']; ?>" target="_blank"><?php echo $art['art_title']; ?></a></td>
						<td>
							<?php if(is_array($art['art_classId']) || $art['art_classId'] instanceof \think\Collection || $art['art_classId'] instanceof \think\Paginator): $i = 0; $__LIST__ = $art['art_classId'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$val): $mod = ($i % 2 );++$i;?>
							<a href="?cid=<?php echo $i; ?>"><?php echo $val; ?></a>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</td>
						<td><?php echo $art['art_author_id']; ?></td>
						<td><?php echo date('Y-m-d H:i:s',$art['art_addtime'] ); ?></td>
						<td class="s-act">
							<a href="<?php echo url('module/cp_article_edit_2',['id'=>$art['id']]); ?>">编辑</a>
							<a href="<?php echo url('module/delArticle',['id'=>$art['id']]); ?>" class="jq-del">删除</a>
						</td>
						</tr>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</table>

			</div>
		</div>
		<div class="pagelist">
			<?php echo $page; ?>
			<!--<span>首页</span><span>上一页</span>-->
			<!--<a href="?page=1" class="curr">1</a>-->
			<!--<a href="?page=2">2</a>-->
			<!--<a href="?page=2">下一页</a>-->
			<!--<a href="?page=2">尾页</a>-->
		</div>
	</div>
	<script>
	    (function () {
		   //删除前提示
		   $(".jq-del").click(function () {
			  return confirm("您确定要删除此文章？");
		   });
	    })();
	</script>
	</body>
</html>