<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"D:\thinkphp5\mydemo3_ng\public/../application/admin\view\home\login.html";i:1551598526;}*/ ?>
<!DOCTYPE html >
<html >
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>登录后台</title>
	<link rel="stylesheet" href="/static/admin/login/css/font-awesome.min.css"/>
	<link rel="stylesheet" href="/static/admin/login/css/loginMy.css"/>
	<script src="/static/admin/js/jquery.js"></script>
</head>
<body>
<div class="main">
	<div class="center">
		<form id="formOne" method="post" onsubmit="return false; " >
			<i class="fa fa-user Cone">  | </i>
			<input type="text" name="user_name" id="user" placeholder="用户名" onblur="//checkUser()"/>
			<span id="user_pass"></span><br/>

			<i class="fa fa-key Cone">  | </i>
			<input type="password" name="user_pwd" id="pwd" placeholder="密码"onblur="//checkUser1()"/>
			<span id="pwd_pass"></span><br/>
			<div id="showYzm" style="display:">
				<i class="fa fa-folder-open Cone">  | </i>
				<input type="text" name="yzm" id="surePwd" placeholder="验证码"onblur="//checkUser2()"/>
				<span id="surePwd_pass" ></span><br/>
				<br/>
				<i style="margin-left: 23.6%;">  </i>
				<img src = "<?php echo captcha_src(); ?>" alt = "captcha" onclick="(this).src=(this).src" >
			</div>
			<input type="button" value="登录" id="submit" style="">
		</form>
	</div>
	<script>
	    $(function(){
		   $('#submit').click(function(){
		       	//判断数据是否为空
			  if( !isNull() ){
				 alert("数据不能为空");
				 return;
			  }
			  $.ajax({
				     url:"<?php echo url('admin/module/loginHandle'); ?>?",
				     type:'post',
				     data:$('form').serialize(),
				     dataType:'json',
					success:function(res){
                             console.log(res);
						if(res.code){
						    alert('登录成功，点击确定跳转后台')
						    window.location.href=res.url;
						}
                         }
				})
		   })
	    })
		//显示验证按
	    function showCode(){
	        $('#showYzm').css('display',"");
	    }
	    //判断数据是否为空
		function isNull(){
	        if( $('showYzm').css('dispaly') == ""){
                 if( $('[name="user_name"]').val()=="" || $('[name="user_pwd"]').val()=="" ||$('[name="yzm"]').val()==""){
                     return false;
                 }
                 return true;
		   }
              if( $('[name="user_name"]').val()=="" || $('[name="user_pwd"]').val()=="" ){
                  return false;
              }
		   return true;
		}
	</script>
</div>
<script type="text/javascript" src="">///static/admin/login/js/loginMy.js</script>
</body>
</html>