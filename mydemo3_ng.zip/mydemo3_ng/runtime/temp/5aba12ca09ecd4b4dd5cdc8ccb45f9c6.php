<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:83:"D:\thinkphp5\mydemo2\public/../application/admin\view\module\cp_article_edit_2.html";i:1551776938;}*/ ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>后台</title>
		<link rel="stylesheet" href="/static/admin/css/style.css">
		<script src="/static/admin/js/ckeditor/ckeditor.js"></script>
     </head>
	<body>
		<div class="wrap wrap-article-edit">
			<h1>文章管理</h1>
			<div class="tips"></div>
			<div class="box">
				<div class="box-title">添加/编辑文章</div>
				<div class="box-body">
					<form method="post" action="<?php echo url('module/cp_article_edit_2Handle'); ?>" enctype="multipart/form-data">
						<table>
							<tr><th width="80">标题：</th><td>
								<input type="text" name="art_title" value="<?php echo $data['art_title']; ?>">
							</td></tr>
							<tr><th>栏目：</th><td>
								<select name="art_classId_one" class="art_col">
									<option value="0">选择一</option>
									<?php if(is_array($data['colArr']) || $data['colArr'] instanceof \think\Collection || $data['colArr'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['colArr'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$col): $mod = ($i % 2 );++$i;if($col['id'] == $data['art_classId']['0']): ?>
											<option value="<?php echo $col['id']; ?>" selected><?php echo $col['col_name']; ?></option>
										<?php else: ?>
											 <option value="<?php echo $col['id']; ?>" ><?php echo $col['col_name']; ?></option>
										<?php endif; endforeach; endif; else: echo "" ;endif; ?>
								</select>
								<select name="art_classId_two" class="art_col">
									<option value="0">选择二</option>
									<?php if(is_array($data['colArr']) || $data['colArr'] instanceof \think\Collection || $data['colArr'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['colArr'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$col): $mod = ($i % 2 );++$i;if($col['id'] == $data['art_classId']['1']): ?>
											<option value="<?php echo $col['id']; ?>" selected><?php echo $col['col_name']; ?></option>
										<?php else: ?>
											 <option value="<?php echo $col['id']; ?>" ><?php echo $col['col_name']; ?></option>
										<?php endif; endforeach; endif; else: echo "" ;endif; ?>
								</select>
								<select name="art_classId_three" class="art_col">
									<option value="0">选择三</option>
									<?php if(is_array($data['colArr']) || $data['colArr'] instanceof \think\Collection || $data['colArr'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['colArr'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$col): $mod = ($i % 2 );++$i;if($col['id'] == $data['art_classId']['2']): ?>
											<option value="<?php echo $col['id']; ?>" selected><?php echo $col['col_name']; ?></option>
										<?php else: ?>
											 <option value="<?php echo $col['id']; ?>" ><?php echo $col['col_name']; ?></option>
										<?php endif; endforeach; endif; else: echo "" ;endif; ?>
								</select>
							</td>
							</tr>
							<tr class="s-author"><th>作者：</th><td>
								<select name="art_author_id">
									<?php if(is_array($data['art_authorArr']) || $data['art_authorArr'] instanceof \think\Collection || $data['art_authorArr'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['art_authorArr'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$author): $mod = ($i % 2 );++$i;if($author['id'] == $data['art_author_id']): ?>
											<option value="<?php echo $author['id']; ?>" selected><?php echo $author['user_name']; ?></option>
										<?php else: ?>
											 <option value="<?php echo $author['id']; ?>" ><?php echo $author['user_name']; ?></option>
										<?php endif; endforeach; endif; else: echo "" ;endif; ?>
								</select>
							</td></tr>
							<tr class="s-keywords"><th>关键字：</th><td>
								<input type="text" name="art_keywords" value="<?php echo $data['art_keywords']; ?>"><span>多个关键字 请用英文逗号（,）分开</span>
							</td></tr>
							<tr class="s-description"><th>内容提要：</th><td>
								<textarea name="art_abs"><?php echo $data['art_abs']; ?></textarea><span>（内容提要请在 200 个字以内）</span>
							</td></tr>
							<tr class="s-thumb"><th>封面图片：</th><td>
								<input type="file" name="art_img"><span>（超过 780*220 图片将被缩小）</span>
								<img src="/static/admin/uploads/<?php echo $data['art_img']; ?>" alt="封面图"></td>
							</tr>
							<tr class="s-editor">
								<th>编辑内容：</th><td><textarea id="content" name="content"><?php echo $data['art_content']; ?></textarea></td>
							</tr>
							<tr class="s-act"><th></th><td>
								<input type = "hidden" name = "id" value="<?php echo $artId; ?>">
								<input type="submit" name="editSubmit" value="立即发布"><input type="submit" value="保存草稿" name="save"></td>
							</tr>
						</table>
					</form>
				</div>
			</div>
		</div>
		<script src="./js/article.config.js"></script>
<script>
	CKEDITOR.config.height = 400;
	CKEDITOR.config.width = "100%";
	CKEDITOR.replace("content");
</script>
</body>
</html>