<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/6 0006
     * Time: 下午 2:10
     */

    namespace app\admin\controller;


    use app\admin\dateValidate\ArticleData;
    use app\common\module\Article;
    use app\common\module\ArticleInfo;
    use app\common\module\Category;
    use app\service\ArticleService;
    use app\service\BaseController;
    use think\Db;
    use think\Exception;
    use think\Request;


    class Module extends BaseController
    {
        public function cp_article_edit()
        {
            return $this->fetch();
        }
        //发布文章处理
        public function addArticleHandle()
        {
            $data=Request::instance()->post();//
            //数据验证
            $validate=new ArticleData();
            if( !$validate->check($data) ){
                $this->error('操作失败'.$validate->getError());
            }
            //开启事务
            Db::startTrans();
            try{
                //判断状态
                $data['status'] = $data['opeate']=="立即发布" ? 1 : 0;
                //----插入文章 主表
                $article=new Article();
                //过滤非表字段数据，然后插入数据+判断是否插入成功
                if(!$article->allowField(true)->save($data)){
                    throw new Exception($article->getError());
                }
                //---副表  ArticleInfo-插入aid+content
                $articleInfo=new ArticleInfo();
                $articleInfo->aid=$article->id;//aid 字段赋值
                $articleInfo->content=$article->content;//content 字段赋值
                //然后插入数据+判断是否插入成功
                if( !$articleInfo->save() ){
                    throw new Exception($articleInfo->getError());
                }
                //--自增文章数量-------栏目表字段total_rows-
                Db::name('category')->where('id',$data['category_id'])->setInc('total_rows');
                //处理关键字 -》 判断有没有该关键字--没有-则追加在关键字表中  有 --则在文章、关键字关系表中加上该关键字和文章的关系
                ArticleService::addKeyword($articleInfo->aid,$data['keyword']);
               //
                Db::commit();
                $this->success('发布成功');
            }catch(Exception $e){
                Db::rollback();
                $this->error($e->getMessage());
            }
        }

        public function cp_index()
        {
            return $this->fetch();
        }
        public function index()
        {
            return $this->fetch();
        }







        //无限极递归
        public function getTree($data,$pid=0,$level=0){
            static $arr=array();
            foreach($data as $key=>$value){
                if($value['parent_id'] == $pid){
                    $value['level']=$level;     //用来作为在模版进行层级的区分
                    $arr[] = $value;            //把内容存进去
                    $this->getTree($data,$value['id'],$level+1);    //回调进行无线递归
                }
            }
            return $arr;

        }



        public function cp_category()
        {
            $category = Category::all();
            $arr=[];
            foreach($category as $val ){
                $arr[]=$val['parent_id'];
            }
            $krr=$this->getTree($category);
            //dump($krr);die;
            $this->assign(['list'=>$krr ]);
            return $this->fetch();
        }
        #文章列表
        public function cp_article()
        {
            $article = new Article();
            //通过模型获取文章所有数据
            $articleArr=$article->paginate(3);//调用扩展文件extend\paginate\BackendPage--自定义config文件
            $this->assign(['list'=>$articleArr]);
            return $this->fetch();
        }
        #编辑文章
        public function cp_article_edit_2()
        {
            $article =Article::get(input('id'));
            $this->assign(['art'=>$article]);
            return $this->fetch();
        }

    }