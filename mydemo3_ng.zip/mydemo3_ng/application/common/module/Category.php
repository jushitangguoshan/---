<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/6 0006
     * Time: 下午 3:03
     */

    namespace app\common\module;
    use think\Model;
    class Category extends  Model
    {
        //关联文章表
        public function article()
        {
            return $this->hasMany('Article','id','category_id');
        }


    }