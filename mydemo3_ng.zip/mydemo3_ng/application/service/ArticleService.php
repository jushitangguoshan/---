<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/3/6 0006
     * Time: 下午 4:48
     */

    namespace app\service;


    use app\common\module\Keywords;
    use think\Db;

    class ArticleService
    {
        //添加文章关键字数据
        public static function addKeyword($aid,$keywords)
        {
            //将关键字字符串进行处理---》最终得到关键字数组
            $arrKeywords = strpos($keywords,',')===false ? (array)$keywords : explode(',',$keywords);
            foreach( $arrKeywords as $v ){
                if($v=='')break;//关键字为空--结束本次循环
                //获取Keywords表中字段Keyword=$v的数据
                $row=Keywords::get(['keyword'=>$v]);
                ///先判断是否有关键字表中是否有该文章的关键字-》如果没有该关键字--则追加一个
                if(!$row){
                    Keywords::create(['keyword'=>$v]);//插入一个关键字
                }//此时的$row=['id'=>$a,'keyword'=>$b];
                //获取该关键字的id
                $addId=Keywords::where('keyword',$v)->value('id');
                //插入关键字与文章的关系----
                Db::name('Article_keyword_relation')->insert(['article_id'=>$aid,'keyword_id'=>$addId]);
            }
            return true;
        }
    }