<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
	<script src="jquery_all.js"></script>
	<style>
		li{
			list-style: none;
		}
		ul{
			padding:0px;
		}
		img{
			width: 30px;
			height: 30px;
		}
		.message_board_list{
			border: 1px solid pink;
			width: 700px;
			margin: 2px auto;
			background-color: wheat;
		}
		.form_list{
			width: 700px;
			height: 200px;
			margin: 2px auto;
			border: 1px solid pink;
		}
	</style>
</head>
<body>
	<form action="">
		<table class='form_list'>
			<tr>
				<td>用户名：</td>
				<td><input id='userName' type="text" name='userName'></td>
			</tr>
			<tr>
				<td>留言：</td>
				<td><textarea id='conts' name="conts" id="" cols="30" rows="10"></textarea></td>
			</tr>
			<tr>
				<td>此刻心情：</td>
				<td>
					<?php echo initImgs();?>
				</td>
			</tr>
			<tr>
				<td><input type="submit" name='go' value="提交留言"></td>
				<td><input type="reset" value="重置"></td>
			</tr>
		</table>
	</form>
		<?php
			$file=file_get_contents("conts.txt");
			$arr=unserialize($file);
			if(!$arr)$arr=[];
			if( isset($_GET['go'])){
				$userName=$_GET['userName'];
				$conts=$_GET['conts'];
				$imgs=$_GET['imgs'];
				date_default_timezone_set('PRC');
				$time=date("Y-m-d h:i:s");
				array_push($arr,[$userName,$conts,$imgs,$time] );
				file_put_contents("conts.txt",serialize($arr) );
			}
			function getImg($imgArr){//输出图片
				$html='';
				foreach($imgArr as $value){
					$html .='<img src='.$value.'>';
				}
				echo $html;
			}
			function initImgs(){
				$html='';
				$imgsCount=9;
				for($i=1; $i<=$imgsCount; $i++){
					$html .='<input type="checkbox" name="imgs[]" value="'.$i.'.jpg">
							<img src="'.$i.'.jpg">
							';
				}
				echo $html;
			}
		?>
			<?php  foreach($arr as $value){  ?>
			<div class='message_board_list'>
			<ul>
				<li><?php echo "用户名：".$value[0]."&nbsp&nbsp".$value[3];?></li>
				<li><?php echo $value[1];echo getImg($value[2]);?></li>
			</ul>
			</div>
		<?php }?>
		<script>
			$(function(){
				$("input:submit").click(function(){
					if( $("#userName").val()==''){
						alert('用户名为空！');
						return false;
					}
					if( $("#conts").val()==''){
						alert('留言为空！');
						return false;
					}
					var i=0;
					$(":checkbox").each(function(){
						if($(this).is(":checked")){
							i++;
						}
					});
					if(i==0){
						alert('表情为空！');
						return false;
					}
				});
			});
		</script>	
</body>
</html>