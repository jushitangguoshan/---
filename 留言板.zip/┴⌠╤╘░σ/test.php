<?php
	$content = file_get_contents("content.txt");
	$arr = unserialize($content);
	if(!$arr) $arr = [];
	if(isset($_GET["act"])){
		$userName = $_GET["userName"];
		$text = $_GET["text"];
		$xinqing = $_GET["xinqing"];
		array_push($arr,[$userName,$text,$xinqing]);
		file_put_contents("content.txt", serialize($arr));
	}
	function showImg(){
		$imgStr = "";
		for($i = 1; $i <= 12; $i++){
			$imgStr .= '<input type="checkbox" name="xinqing[]" value='.$i.'><img src="img/'.$i.'.JPG" alt="">';
		}
		return $imgStr;
	}
	function getImg($xinqing){
		$img = "";
		foreach ($xinqing as $value) {
			$img .= "<img src=img/".$value.".JPG>";
		}
		return $img;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>留言板</title>
	<style>
		table{
			width: 80%;
			height: 400px;
			margin: 0 auto;
		}
		li{
			list-style-type: none;
			border:1px solid;
			width: 85%;
			margin: 0 auto;
			background-color: pink;
		}
	</style>
</head>
<body>
	<form action="">
		<table border="1">
			<tr>
				<td>用户名</td>
				<td>
					<input type="text" name="userName">
				</td>
			</tr>
			<tr>
				<td>留言</td>
				<td>
					<textarea name="text" id="" cols="30" rows="10"></textarea>
				</td>
			</tr>
			<tr>
				<td>此刻心情</td>
				<td>
					<?php echo showImg()?>
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="submit" value="提交留言">
					<input type="hidden" name="act">
					<input type="reset" value="重置">
				</td>
			</tr>
		</table>
	</form>	
	<ul>
		<?php 
			for($i = 0; $i < count($arr); $i++){
		?>
			<li>
			<span><?php echo $arr[$i][0]?></span>
			<span>2018-11-20</span>
			<span><?php echo $arr[$i][1]?></span>
			<span><?php echo getImg($arr[$i][2])?></span>
			</li>
		<?php } ?>
	</ul>
</body>
</html>