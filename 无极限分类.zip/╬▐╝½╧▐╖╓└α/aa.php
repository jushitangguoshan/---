<?php

   public function getColumnTree($list,$pk='id',$pid='parent_id',$child='_child',$root=0){
            $tree=array();
            foreach($list as $key=> $val){
                if($val[$pid]==$root){  //获取当前$pid所有子类
                    unset( $list[$key] );
                    if( !empty($list) ){
                        $child=$this->getColumnTree($list,$pk,$pid,$child,$val[$pk]);
                        if(!empty($child))  $val['_child']=$child;
                    }
                    $tree[]=$val;
                }
            }
            return $tree;
        }
        public function getListHtml($arr,$level = 0)
        {
           $html = '';
           foreach($arr as $key=>$val){
                if( array_key_exists('_child',$val) ){
                    $html .=
                        "<tr class = 'hover' >
                            <td class = 'center'>
                              <input type = 'text' class = 's-num' name = 'save[1][sort]' value = '".$key."'>
                            </td>
                            <td>
                                <input type = 'text' name = 'save[1][name]' value = '".$val['category_name']."'>
                            </td>
                            <td class = 'center'>
                                <a href = '#' class='jq-cp-edit'>编辑</a>
                                <a href = '#' class = 'jq-del'>删除</a>
                            </td>
                        </tr>";
                    $html .= $this->getListHtml($val['_child'],$level+1);
                    $html .=
                        "<tr>
                            <td colspan='3'>
                                <i class='icon-sub-add'></i>
                                <span class='jq-sub-add s-add' data-id='1'>
                                <i class='icon-cross'></i><b>添加子栏目</b>
                                </span>
                            </td>
                        </tr>";
                }else{
                    for ($i=0;$i<$level;$i++){
                        $html .=
                            "<tr class='hover'>
                                <td class='center'>
                                   <input type='text' class='s-num' name='save[13][sort]' value='".$val['id']."'>
                                </td>
                                <td>
                                    <i class='icon-sub'></i>
                                    <input type='text' name='save[13][name]' value='".$val['category_name']."'>
                                </td>
                                <td class='center'>
                                    <a href='#' class='jq-cp-edit'>编辑</a>
                                    <a href='#' class='jq-del'>删除</a>
                                </td>
                            </tr>";

                    }
                    if( $level == 0 ){
                        $html .="<tr class = 'hover'>
                            <td class = 'center'>
                                <input type = 'text' class = 's-num' name = 'save[1][sort]' value = '".$key."'>
                            </td>
                            <td>
                                <input type = 'text' name = 'save[1][name]' value = '".$val['category_name']."'>
                            </td>
                            <td class = 'center'>
                                <a href = '#' class='jq-cp-edit'>编辑</a>
                                <a href = '#' class = 'jq-del'>删除</a>
                            </td>
                            </tr>
                            <tr>
                                <td colspan='3'>
                                <i class='icon-sub-add'></i>
                                <span class='jq-sub-add s-add' data-id='1'>
                                <i class='icon-cross'></i><b>添加子栏目</b>
                                </span>
                                </td>
                            </tr>";
                    }
                }
            }
            return $html;
        }
        //获取排序好的列表
        public function getList($data,$level = 0)
        {
            $html = '';
            foreach ($data as $item){
                for ($i=0;$i<$level;$i++){
                    $html .= '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
                }
                $html .= $item['category_name'].'<br>';
                if( isset($item['_child']) ){
                    $html .= $this->getList($item['_child'],$level+1);
                }
            }
            return $html;
        }