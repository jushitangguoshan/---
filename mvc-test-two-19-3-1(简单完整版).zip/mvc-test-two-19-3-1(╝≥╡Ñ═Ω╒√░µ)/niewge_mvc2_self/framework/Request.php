<?php
/**
 * 请求对象
 * User: Jack<376927050@qq.com>
 * Date: 2018/10/27
 * Time: 11:21
 */

namespace framework;


class Request
{
    // 模块
    public $module;
    // 控制器
    public $controller;
    // 方法
    public $action;

    private static $_instance;

    //初始化 处理请求参数
    private function __construct()
    {
        $this->module = isset($_GET['p']) ? strtolower(trim($_GET['p'])) : C('defaultModule','front');
        $this->controller = isset($_GET['c']) ? ucfirst(strtolower(trim($_GET['c']))) : C('defaultController','Home');
        $this->action = isset($_GET['a']) ? strtolower(trim($_GET['a'])) : C('defaultAction','index');
    }

    // 获取对象实例
    public static function getInstance()
    {
        if( self::$_instance == null ){
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * 获取需要的控制器方法
     * @return array
     */
    public function getControllerAction()
    {
        return ["\application\\{$this->module}\controller\\{$this->controller}",$this->action];
    }

    //判断是否是ajax
    public function isAjax()
    {
        return isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest' ? true : false;
    }

    //判断是不是get请求
    public function isGet()
    {
        return ($_SERVER['REQUEST_METHOD'] == 'GET')? true : false;
    }

    //判断是不是post请求
    public function isPost()
    {
        return ($_SERVER['REQUEST_METHOD'] == 'POST')? true : false;
    }

    /**
     * 获取post数据
     * @param string $key
     * @return mixed
     */
    public function post($key = '',$safety = ['trim','htmlspecialchars'])
    {
        if(!empty($_POST) && !empty($safety) ){
            foreach ($safety as $func){
                $_POST = array_map($func,$_POST);
            }
        }

        if( !empty($key)  ){
            return isset($_POST[$key]) ? trim($_POST[$key]) : null;
        }
        return $_POST;
    }

    /**
     * 获取post数据
     * @param string $key
     * @return mixed
     */
    public function get($key = '',$safety = ['trim','htmlspecialchars'])
    {
        if(!empty($_GET) && !empty($safety) ){
            foreach ($safety as $func){
                $_GET = array_map($func,$_GET);
            }
        }
        if( !empty($key)  ){
            return isset($_GET[$key]) ? trim($_GET[$key]) : null;
        }
        return $_GET;
    }

    /**
     * 获取不存在的属性
     * @param $name
     */
    public function __get($name)
    {
        if( method_exists($this,$name) ){
            return $this->$name();
        }
    }

    // 私有化克隆
    private function __clone(){}
}