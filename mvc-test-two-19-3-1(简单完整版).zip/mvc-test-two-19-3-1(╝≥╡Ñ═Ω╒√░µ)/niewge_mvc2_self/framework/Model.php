<?php
/**
 * 数据表模型基类
 *  get_called_class  （实例的谁）  和 __CLASS__ （在哪个类里面） 区别
 *  static   self
 * User: Jack<376927050@qq.com>
 * Date: 2018/10/23
 * Time: 16:53
 */
namespace framework;

use framework\db\Sql;

class Model
{
    // 数据模型对应的表名
    protected $tableName;
    // SQL组合对象
    private $_sql;

    protected $primaryId = 'id';

    public function __construct()
    {
        # 获取表名
        $arrTemp = explode('\\',get_called_class());
        $this->tableName = $arrTemp[count($arrTemp)-1];
        # 生成SQL组合对象
        $this->_sql = (new Sql())->table($this->tableName);
    }

    /**
     * 单条记录查询
     * @param $id
     * @return array
     */
    public function find($pkId)
    {
        $result = $this->_sql->where($this->primaryId,$pkId)->select();
        if( isset($result[0]) )
            return $result[0];
    }

    public function __call($name, $arguments)
    {
        if( is_callable([$this->_sql,$name]) ){
            return call_user_func_array([$this->_sql,$name],$arguments);
        }
    }
    /**
     * 分页
     */
    public function paginate($limit = 1)
    {
        $total = $this->_sql->count();
        $pager = new \framework\libs\Page($total,$limit);
        $condition = $pager->getDbFetchCondition();
        $list = $this->_sql->limit($condition)->select();
        return ['data'=>$list,'html'=>$pager->showPage()];
    }

}