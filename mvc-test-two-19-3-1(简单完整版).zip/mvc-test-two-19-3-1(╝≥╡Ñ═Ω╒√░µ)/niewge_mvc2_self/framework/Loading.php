<?php
namespace framework;

class Loading
{
    public static function start()
    {
        # 自动加载
        spl_autoload_register([__CLASS__,'autoload']);
        # 框架初始化配置
        self::init();
        # 请求分发
        self::dispatch();
    }

    /**
     * 请求分发
     */
    public static function dispatch()
    {
        list($controller,$method) = self::handleParams();
        $objCtrl = new $controller();
        if( !is_callable([$objCtrl,$method]) ){
            throw new \Exception('无效的请求');
        }
        call_user_func([$objCtrl,$method]);
    }

    /**
     * 框架初始化
     */
    public static function init()
    {
        # 定义时区
        date_default_timezone_set('PRC');

        define('DS',DIRECTORY_SEPARATOR);
        define('ROOT',dirname(__DIR__));
        define('APP', ROOT . DS . 'application');
        define('FW_PATH', ROOT . DS . 'framework');
        define('LIBRARY_PATH',FW_PATH . DS . 'libs');

        # 定义错误处理
        Error::register();

        # 读取应用里的配置文件
        $confFile = APP . DS . 'config.php';
        Config::getInstance()->read($confFile);

        # 引用核心公共函数
        require_once FW_PATH .DS .'functions.php';

        # 开启session
        session_start();

    }

    /**
     * 定义自动加载
     * @param $classname
     * @throws \Exception
     */
    protected static function autoload($classname)
    {
        // 兼容Unix操作系统
        $classfile = str_replace('\\','/',$classname) . '.php';
        if( !file_exists($classfile) ){
            throw new \Exception($classfile.'文件不存在');
        }
        require_once $classfile;
    }

    /**
     * 处理请求的参数 获取 c 参数 和 a 参数
     */
    protected static function handleParams()
    {
        return Request::getInstance()->getControllerAction();
    }
}