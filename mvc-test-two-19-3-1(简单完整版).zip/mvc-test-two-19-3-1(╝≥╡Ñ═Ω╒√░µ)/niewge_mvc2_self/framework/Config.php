<?php
/**
 * 配置类
 * 1、读取配置文件 读取多个
 * 2、获取配置项
 * 3、动态的添加配置项
 * User: Jack<376927050@qq.com>
 * Date: 2018/10/24
 * Time: 17:34
 */

namespace framework;

class Config
{
    private static $instance;
    private static $_config = [];
    private function __construct()
    {
        # 可以在框架内部 放置一个默认配置文件
    }

    public static function getInstance()
    {
        if( self::$instance == null ){
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * 读取应用里的配置文件
     * @param $filePath
     */
    public function read($filePath)
    {
        if( file_exists($filePath) ){
            $appConfig = require_once $filePath;
            self::$_config = array_merge(self::$_config,$appConfig);
        }
    }

    /**
     * 获取配置项  $key  db.dbhost
     * @param $key
     * @param string $default
     */
    public function get($key,$default = '')
    {
        if( strpos($key,'.') !== false ){
            $arrTemp = explode('.',$key);
            $index1 = $arrTemp[0];
            $index2 = $arrTemp[1];
            if( isset(self::$_config[$index1][$index2]) ){
                return self::$_config[$index1][$index2];
            }
        }
        if( key_exists($key,self::$_config) ){
            return self::$_config[$key];
        }
        return $default;
    }
}