<?php
namespace framework;

class Error
{
    public static function register()
    {
        set_exception_handler([__CLASS__,'appException']);
        set_error_handler([__CLASS__,'appError']);
        register_shutdown_function([__CLASS__,'shutdown']);
    }

    public static function appException(\Exception $e)
    {
        var_dump($e);
    }

    public static function appError($errno,$errstr,$errfile,$errline)
    {
        var_dump($errno,$errstr,$errfile,$errline);
    }

    public static function shutdown()
    {
        if( ($error = error_get_last()) !== null ){
            var_dump($error);
        }
    }
}