<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/28 0028
     * Time: 上午 10:44
     */

    $arr=['sss',123,false,23.23,array(1,2,3,)];
    list($a,$b,$c,$d,$e,$d)=$arr;
    var_dump($a,$b,$c,$d,$e,$d);

    echo "<script>alert('ssssssssss');location.href='?';</script>";