
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>新闻发布系统</title>
<link rel="stylesheet" href="./css/style.css" />
</head>
<body>
<div class="box">
	<div class="top">
		<div class="title">新闻发布系统</div>
		<div class="nav">
			<a href="./add.php">发表新闻</a>
		</div>
	</div>
	<div class="main">
		<form method="post" action="delMutil.php">
			<table class="news-list">
				<tr><th>新闻标题</th><th width="250">发布时间</th><th width="200">操作</th></tr>
									<tr>
						<td class="news-list-title">
							<input type="checkbox" name="id[]" value="3" />
							<a href="./show.php?id=3" target="_blank">新闻标题3</a>
						</td>
						<td class="center">2015-11-11 10:05:08</td>
						<td class="center"><a href="./edit.php?id=3">编辑</a>　<a href="./del.php?id=3" onclick="return confirm('确定要删除该新闻吗？');">删除</a></td>
					</tr>
									<tr>
						<td class="news-list-title">
							<input type="checkbox" name="id[]" value="2" />
							<a href="./show.php?id=2" target="_blank">新闻标题2</a>
						</td>
						<td class="center">2015-10-11 12:06:56</td>
						<td class="center"><a href="./edit.php?id=2">编辑</a>　<a href="./del.php?id=2" onclick="return confirm('确定要删除该新闻吗？');">删除</a></td>
					</tr>
									<tr>
						<td class="news-list-title">
							<input type="checkbox" name="id[]" value="1" />
							<a href="./show.php?id=1" target="_blank">新闻标题1</a>
						</td>
						<td class="center">2015-10-09 17:07:58</td>
						<td class="center"><a href="./edit.php?id=1">编辑</a>　<a href="./del.php?id=1" onclick="return confirm('确定要删除该新闻吗？');">删除</a></td>
					</tr>
							</table>
			<div class="action">
				<button id="checkAll">全选</button>
				<button id="checkReverse">反选</button>
				<input type="submit" value="批量删除" />
			</div>
		</form>
          <!-- 输出分页链接 -->
		<div class="pagelist">当前为 1/3　<a href="?page=1">[首页]</a>　[上一页]　<a href="?page=2">[下一页]</a>　<a href="?page=3">[尾页]</a></div>

	</div>
	<div class="footer">
		页面底部
	</div>
</div>
<script>
//全选
document.getElementById("checkAll").onclick = function(){
    var ids = document.getElementsByName("id[]");
    for(var i in ids){
        ids[i].checked = true;
    }
    return false;
};
//反选
document.getElementById("checkReverse").onclick = function(){
    var ids = document.getElementsByName("id[]");
    for(var i in ids){
        ids[i].checked = !ids[i].checked;
    }
    return false;
};
</script>
</body>
</html>