<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/27 0027
     * Time: 下午 8:11
     */
    namespace application\admin\controller;
    class Home
    {
        public function index()
        {
            echo __FILE__;
        }
    }