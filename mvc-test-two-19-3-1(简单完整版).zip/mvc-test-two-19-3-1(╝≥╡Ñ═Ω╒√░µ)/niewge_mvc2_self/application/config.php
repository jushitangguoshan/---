<?php
/**
 * 我们需要一个对象 来读取这些配置，并且能很多地方 获取配置
 * User: Jack<376927050@qq.com>
 * Date: 2018/10/24
 * Time: 17:27
 */
return [
    'db'=> [
        'dbhost'=> 'localhost',
        'dbname'=> 'forum',
        'user'=> 'root',
        'pwd'=> 'root',
        'charset'=> 'utf8',
    ],
    'defaultModule' => 'front',
    'defaultController' => 'Home',
    'defaultAction' => 'index',
    "setTitle"=>'我才是标题！！'//标题常量
];