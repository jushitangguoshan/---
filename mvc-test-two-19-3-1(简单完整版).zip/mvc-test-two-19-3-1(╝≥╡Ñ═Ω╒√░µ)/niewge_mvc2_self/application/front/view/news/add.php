
<!doctype html>
<html>
<head>
     <meta charset="utf-8">
     <title><?=C("setTitle")?></title>
     <link rel="stylesheet" href="http://www.study.com/public/front/css/style.css" />
     <script src="http://www.study.com/public/front/js/jquery.js"></script>
</head>
<body>
<div class="box">
     <div class="top">
          <div class="title">新闻发布系统--->发布新闻</div>
          <div class="nav">
               <a href="<?=\framework\helper\Url::to('home/index')?>">返回列表</a>
          </div>
     </div>
	<div class="main">
		<form action="" onsubmit="return false;">
			<table class="news-edit">
				<tr>
					<th>新闻标题：</th>
					<td><input type="text" name="title" placeholder="填写新闻标题..." /></td>
				</tr>
				<tr>
					<th>新闻内容：</th>
					<td><textarea name="content" placeholder="填写新闻内容..."></textarea></td>
				</tr>
				<tr>
					<th>验证码：</th>
					<td> <img src="<?=\framework\helper\Url::to('news/showImg')?>" id="yzm" style="cursor:pointer;"> <input type="text" name="yzm" style="width:100px;" /></td>
				</tr>
				<tr>
					<th></th>
					<td><input type="submit" name='submit' value="立即发布新闻" /></td>
				</tr>
			</table>
		</form>
	</div>
	<div class="footer">
		页面底部 
	</div>
</div>
<script>
     $(function (){
          //增加提交表单
         $('[name="submit"]').click(function(){
             $.ajax({
                 url:'?c=news&a=addNews',
                 type:'post',
                 data:$('form').serialize(),
                 dataType:'json',
                 success:function(res){
                    alert(res.message);
                     if(res.code){
                         $('form')[0].reset();
                     }
                 }
             })
         })
         //验证码点击事件
         $('#yzm').click(function(){
             $(this).attr('src','http://www.study.com/index.php?p=front&c=news&a=showImg&'+Math.random());
         })
     })
</script>
</body>
</html>