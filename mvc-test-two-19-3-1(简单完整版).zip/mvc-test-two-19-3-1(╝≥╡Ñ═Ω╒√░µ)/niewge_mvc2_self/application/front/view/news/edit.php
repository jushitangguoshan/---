
<!doctype html>
<html>
<head>
     <meta charset="utf-8">
     <title><?=C("setTitle")?></title>
     <link rel="stylesheet" href="http://www.study.com/public/front/css/style.css" />
     <script src="http://www.study.com/public/front/js/jquery.js"></script>
</head>
<body>
<div class="box">
     <div class="top">
          <div class="title">新闻发布系统--->编辑新闻</div>
		<div class="nav">
			<a href="<?=\framework\helper\Url::to('home/index')?>">返回列表</a>
		</div>
	</div>
	<div class="main">
		<form action="" onsubmit="return false;">
			<table class="news-edit">
                    <input type="text" style="display: none;"  name="id" value="<?=$list['id']?>" />
				<tr>
					<th>新闻标题：</th>
					<td><input type="text" name="title" value="<?=$list['bbs_title']?>" /></td>
				</tr>
				<tr>
					<th>新闻内容：</th>
					<td><textarea name="content"><?=$list['bbs_content']?></textarea></td>
				</tr>
				<tr>
					<th></th>
					<td><input type="button" name='submit' value="修改新闻" /></td>
				</tr>
			</table>
		</form>
	</div>
	<div class="footer">
		页面底部 
	</div>
</div><script>
     $(function (){
         //编辑提交表单
         $('[name="submit"]').click(function(){
            // var data = $.param({ "id" : $('[name="id"]').val()}) + "&" + $("form").serialize();
             $.ajax({
                 url:'?c=news&a=editNews',
                 type:'post',
                 data:$("form").serialize(),
                 dataType:'json',
                 success:function(res){
                     alert(res.message);
                 }
             })
         })
     })
</script>

</body>
</html>