
<!doctype html>
<html>
<head>
     <meta charset="utf-8">
     <title><?=C("setTitle")?></title>
     <link rel="stylesheet" href="http://www.study.com/public/front/css/style.css" />
     <script src="http://www.study.com/public/front/js/jquery.js"></script>
</head>
<body>
<div class="box">
     <div class="top">
          <div class="title">新闻发布系统</div>
          <div class="nav">
               <a href="<?=\framework\helper\Url::to('news/add')?>">发表新闻</a>
          </div>
     </div>
     <div class="main">
		<form action="" onsubmit="return false;">
               <table class="news-list">
                    <tr><th>新闻标题</th><th width="250">发布时间</th><th width="200">操作</th></tr>

                   <?php foreach ($list['data'] as $news): ?>
                    <tr>
                         <td class="news-list-title">
                              <input type="checkbox" name="id[]" value="<?=$news['id']?>" />
                              <a href="http://www.study.com/?c=news&a=show&id=<?=$news['id']?>" target="_blank"><?=$news['bbs_title']?></a>
                         </td>
                         <td class="center"><?=date("Y-m-d H:i:s",$news['add_time'])?></td>
                         <td class="center">
                              <a href="http://www.study.com/?c=news&a=edit&id=<?=$news['id']?>">编辑</a>　
                              <a href="#" class="delNews" data-index="<?=$news['id']?>" >删除</a>
                         </td>
                    </tr>
                    <?php endforeach;?>

               </table>
               <div class="action">
                    <button id="checkAll">全选</button>
                    <button id="checkReverse">反选</button>
                    <input type="submit" name="submit" value="批量删除" />
               </div>
          </form>
          <div class="pagelist"> <?=$list['html']?> </div>

     </div>
     <div class="footer">
          页面底部
     </div>
</div>
<script>

     $(function (){
        // 单个删除
          $('.delNews').click(function(){
               if( confirm('确定要删除该新闻吗？') ){
                   var _this=this;
                    $.ajax({
                        url:'?c=news&a=delNews',
                        data:{id:$(_this).data('index')},
                        dataType:'json',
                        success:function(res){
                            if(!res.code){
                                alert(res.message);return;
                            }
                            $(_this).parents('tr').remove();
                        }
                    })
               }
          })
         //批量删除
         $('[name="submit"]').click(function(){
               var arr=[];
               var checkbox=$(':checkbox');
               $.each(checkbox,function(i,obj){
                   if($(obj).is(':checked')){
                       arr.push(obj.defaultValue);
                   }
               })
             $.ajax({
                 url:'?c=news&a=delNewsBatch',
                 type:'post',
                 data:{data:arr},
                 dataType:'json',
                 success:function(res){
                     if(!res.code){
                         alert(res.message);return;
                     }
                     $.each(checkbox,function(i,obj){
                         if($(obj).is(':checked')){
                            $(obj).parents('tr').remove();
                         }
                     })
                 }
             })
         })
     })
//全选
document.getElementById("checkAll").onclick = function(){
    var ids = document.getElementsByName("id[]");
    for(var i in ids){
        ids[i].checked = true;
    }
    return false;
};
//反选
document.getElementById("checkReverse").onclick = function(){
    var ids = document.getElementsByName("id[]");
    for(var i in ids){
        ids[i].checked = !ids[i].checked;
    }
    return false;
};
</script>
</body>
</html>