<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/28 0028
     * Time: 上午 10:55
     */

    namespace application\front\model;
    use framework\Model;
    class News extends Model
    {

    }