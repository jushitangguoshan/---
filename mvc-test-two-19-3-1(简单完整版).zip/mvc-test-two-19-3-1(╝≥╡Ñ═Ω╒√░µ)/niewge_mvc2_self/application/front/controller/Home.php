<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/27 0027
     * Time: 下午 8:10
     */
    namespace application\front\controller;
    use framework\Controller;
    use framework\View;
///?p=front&c=news&a=show
    class Home extends Controller
    {
        public function index()
        {
            $data=(new \application\front\model\News())->paginate(4);
            return $this->render("index",['list'=>$data]);
        }
    }
