<?php
    /**
     * Created by PhpStorm.
     * User: Administrator
     * Date: 2019/2/27 0027
     * Time: 下午 8:46
     */
    namespace application\front\controller;
    use framework\Controller;
    use framework\libs\Captcha;

    class News extends Controller
    {
        #----------发布新闻
        public function addNews()
        {
            #验证码判断
            if( !Captcha::verify($_POST['yzm']) ){
                exit( json_encode(['code'=>0,'message'=>"验证码错误"]) ) ;
            }
            #数据库操作
            $res=(new \application\front\model\News())->insert(['bbs_title'=>$_POST['title'],'bbs_content'=>$_POST['content']]);
            #结果判断
            $this->returnJson($res,"发布");
        }
        #----------编辑新闻
        public function editNews()
        {
            $id= $_POST['id'];
            $title= $_POST['title'];
            $content= $_POST['content'];
            #数据库操作
            $res=(new \application\front\model\News())->where('id',"=",$id)->update(['bbs_title'=>$title,'bbs_content'=>$content]);
            #结果判断
            $this->returnJson($res,"修改");
        }
        #----------删除一条新闻
        public function delNews()
        {
            #数据库操作
            $res = (new \application\front\model\News())->where('id',"=",$_GET['id'])->delete();
            #结果判断
            $this->returnJson($res,"删除");
        }
        #----------批量删除新闻
        public function delNewsBatch()
        {
            $inArr=$_POST['data'];
            #数据库操作
            $res=(new \application\front\model\News())->where('id',"in",$inArr)->delete();
            #结果判断
            $this->returnJson($res,"批量删除");
        }

        #增加页面渲染
        public function add()
        {
            $this->render();
        }
        #编辑页面渲染
        public function edit()
        {
            $data=(new \application\front\model\News())->find($_GET['id']);
            return $this->render("edit",['list'=>$data]);
        }
        #渲染页面显示
        public function show()
        {
            $this->render();
        }
        #$引入验证码
        public function showImg()
        {
            return Captcha::show();
        }
        private function returnJson($res,$ope)
        {
            if( $res ){
                exit( json_encode(['code'=>1,'message'=>$ope."成功"]) ) ;
            }
            exit( json_encode(['code'=>0,'message'=>$ope."失败"]) ) ;
        }

    }