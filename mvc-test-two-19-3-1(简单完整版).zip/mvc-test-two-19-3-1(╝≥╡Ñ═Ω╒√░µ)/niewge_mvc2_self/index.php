<?php
header('content-type:text/html;charset=utf-8');
require_once 'framework\Loading.php';
\framework\Loading::start();